
  # Whistle Blowing System App

  This is a code bundle for Whistle Blowing System App. The original project is available at https://www.figma.com/design/XtsPLD6DKNnhBLD7U3AAS8/Whistle-Blowing-System-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  