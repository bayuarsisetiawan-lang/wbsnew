import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { SettingsProvider } from './utils/settings';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { BuatAduan } from './pages/BuatAduan';
import { PantauAduan } from './pages/PantauAduan';
import { TentangWBS } from './pages/TentangWBS';
import { FAQ } from './pages/FAQ';
import { SyaratKetentuan } from './pages/SyaratKetentuan';
import { Login } from './pages/Login';
import { Setup } from './pages/Setup';
import { Dashboard } from './pages/admin/Dashboard';
import { Pengaduan } from './pages/admin/Pengaduan';
import { DetailPengaduan } from './pages/admin/DetailPengaduan';
import { Kategori } from './pages/admin/Kategori';
import { Users } from './pages/admin/Users';
import { Settings } from './pages/admin/Settings';
import { DisplayDashboard } from './pages/display/DisplayDashboard';
import { Toaster } from './components/ui/sonner';
import { analytics } from './utils/analytics';
import { ENV, logger } from './utils/environment';
import { APP_CONFIG, safeLogger } from './utils/config';
import { useEffect } from 'react';

export default function App() {
  useEffect(() => {
    try {
      // Initialize application
      logger.info('WBS Application started', {
        version: ENV.APP_VERSION || APP_CONFIG.version,
        environment: ENV.NODE_ENV || 'development'
      });

      // Track application start
      try {
        if (ENV.FEATURES && ENV.FEATURES.ANALYTICS) {
          analytics.trackPageView({
            page: window.location.pathname,
            title: document.title
          });
        }
      } catch (analyticsError) {
        // Analytics failure shouldn't break the app
        safeLogger.warn('Analytics initialization failed', analyticsError);
      }
    } catch (error) {
      // Fallback initialization
      safeLogger.info('WBS Application started (fallback mode)', {
        version: APP_CONFIG.version,
        environment: 'development'
      });
    }

    // Set up global error handlers
    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      try {
        logger.error('Unhandled promise rejection', event.reason);
      } catch (e) {
        safeLogger.error('Unhandled promise rejection', event.reason);
      }
      event.preventDefault();
    };

    const handleError = (event: ErrorEvent) => {
      try {
        logger.error('Global error handler', {
          message: event.message,
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno
        });
      } catch (e) {
        safeLogger.error('Global error handler', {
          message: event.message,
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno
        });
      }
    };

    window.addEventListener('unhandledrejection', handleUnhandledRejection);
    window.addEventListener('error', handleError);

    return () => {
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
      window.removeEventListener('error', handleError);
    };
  }, []);

  return (
    <ErrorBoundary>
      <SettingsProvider>
        <BrowserRouter>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<Layout><Home /></Layout>} />
            <Route path="/buat-aduan" element={<Layout><BuatAduan /></Layout>} />
            <Route path="/pantau-aduan" element={<Layout><PantauAduan /></Layout>} />
            <Route path="/tentang-wbs" element={<Layout><TentangWBS /></Layout>} />
            <Route path="/faq" element={<Layout><FAQ /></Layout>} />
            <Route path="/syarat-ketentuan" element={<Layout><SyaratKetentuan /></Layout>} />
            
            {/* Auth */}
            <Route path="/setup" element={<Setup />} />
            <Route path="/login" element={<Login />} />
            
            {/* Admin Routes */}
            <Route path="/admin/dashboard" element={<Dashboard />} />
            <Route path="/admin/pengaduan" element={<Pengaduan />} />
            <Route path="/admin/pengaduan/:id" element={<DetailPengaduan />} />
            <Route path="/admin/kategori" element={<Kategori />} />
            <Route path="/admin/users" element={<Users />} />
            <Route path="/admin/settings" element={<Settings />} />
            
            {/* Display Route */}
            <Route path="/display/dashboard" element={<DisplayDashboard />} />
            
            {/* Catch-all route */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
          <Toaster />
        </BrowserRouter>
      </SettingsProvider>
    </ErrorBoundary>
  );
}