// Simple configuration with safe defaults
// This ensures the app works even without environment variables

export const APP_CONFIG = {
  // App Information
  name: 'WBS Dinas PMPTSP Kab.Tegal',
  version: '1.0.0',
  description: 'Sistem Pengaduan Whistleblowing Dinas PMPTSP Kabupaten Tegal',
  
  // Environment
  isDevelopment: true, // Safe default
  isProduction: false,
  
  // Features (disabled by default for safety)
  features: {
    analytics: false,
    errorReporting: false,
    performanceMonitoring: false,
    debugMode: true
  },
  
  // Supabase (using KV store defaults)
  supabase: {
    url: 'https://placeholder.supabase.co',
    anonKey: 'placeholder-key'
  },
  
  // File upload
  upload: {
    maxFileSize: 10 * 1024 * 1024, // 10MB
    allowedTypes: [
      'image/jpeg',
      'image/jpg', 
      'image/png',
      'image/gif',
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain'
    ]
  },
  
  // UI
  ui: {
    toastDuration: 5000,
    loadingTimeout: 30000,
    paginationSize: 10
  },
  
  // Security
  security: {
    sessionTimeout: 8 * 60 * 60 * 1000, // 8 hours
    maxLoginAttempts: 5,
    lockoutDuration: 15 * 60 * 1000 // 15 minutes
  }
} as const;

// Simple logger that works everywhere
export const safeLogger = {
  info: (message: string, data?: any) => {
    console.log(`[INFO] ${message}`, data);
  },
  error: (message: string, error?: any) => {
    console.error(`[ERROR] ${message}`, error);
  },
  warn: (message: string, data?: any) => {
    console.warn(`[WARN] ${message}`, data);
  },
  debug: (message: string, data?: any) => {
    if (APP_CONFIG.features.debugMode) {
      console.debug(`[DEBUG] ${message}`, data);
    }
  }
};

export default APP_CONFIG;