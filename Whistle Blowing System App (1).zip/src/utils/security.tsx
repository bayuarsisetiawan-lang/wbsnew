import { ENV, logger } from './environment';

// Security utilities untuk WBS
export class SecurityManager {
  private static instance: SecurityManager;
  private loginAttempts: Map<string, number> = new Map();
  private lockedUsers: Map<string, number> = new Map();

  static getInstance(): SecurityManager {
    if (!SecurityManager.instance) {
      SecurityManager.instance = new SecurityManager();
    }
    return SecurityManager.instance;
  }

  // File upload security
  validateFile(file: File): { isValid: boolean; error?: string } {
    // Check file size
    if (file.size > ENV.UPLOAD.MAX_FILE_SIZE) {
      return {
        isValid: false,
        error: `File terlalu besar. Maksimal ${Math.round(ENV.UPLOAD.MAX_FILE_SIZE / 1024 / 1024)}MB`
      };
    }

    // Check file type
    if (!ENV.UPLOAD.ALLOWED_TYPES.includes(file.type)) {
      return {
        isValid: false,
        error: 'Tipe file tidak diizinkan'
      };
    }

    // Check file extension
    const extension = '.' + file.name.split('.').pop()?.toLowerCase();
    if (!ENV.UPLOAD.ALLOWED_EXTENSIONS.includes(extension)) {
      return {
        isValid: false,
        error: 'Ekstensi file tidak diizinkan'
      };
    }

    // Additional security checks
    if (this.isExecutableFile(file)) {
      return {
        isValid: false,
        error: 'File executable tidak diizinkan'
      };
    }

    if (this.hasSuspiciousContent(file.name)) {
      return {
        isValid: false,
        error: 'Nama file mengandung karakter yang tidak diizinkan'
      };
    }

    return { isValid: true };
  }

  private isExecutableFile(file: File): boolean {
    const executableExtensions = [
      '.exe', '.bat', '.cmd', '.com', '.pif', '.scr', '.vbs', '.js', '.jar',
      '.php', '.asp', '.aspx', '.jsp', '.sh', '.ps1', '.py', '.rb'
    ];
    
    const extension = '.' + file.name.split('.').pop()?.toLowerCase();
    return executableExtensions.includes(extension);
  }

  private hasSuspiciousContent(fileName: string): boolean {
    const suspiciousPatterns = [
      /\.\./,  // Directory traversal
      /[<>:"|?*]/,  // Windows forbidden characters
      /^\./,  // Hidden files
      /\x00/,  // Null bytes
      /%00/   // URL encoded null bytes
    ];

    return suspiciousPatterns.some(pattern => pattern.test(fileName));
  }

  // Login attempt tracking
  recordLoginAttempt(identifier: string, success: boolean): boolean {
    const key = this.hashIdentifier(identifier);
    
    if (success) {
      // Reset attempts on successful login
      this.loginAttempts.delete(key);
      this.lockedUsers.delete(key);
      return true;
    }

    // Increment failed attempts
    const attempts = (this.loginAttempts.get(key) || 0) + 1;
    this.loginAttempts.set(key, attempts);

    // Lock user if max attempts reached
    if (attempts >= ENV.SECURITY.MAX_LOGIN_ATTEMPTS) {
      const lockoutTime = Date.now() + ENV.SECURITY.LOCKOUT_DURATION;
      this.lockedUsers.set(key, lockoutTime);
      
      logger.warn(`User locked due to failed login attempts`, { 
        identifier: key.substring(0, 8),
        attempts 
      });
      
      return false;
    }

    return true;
  }

  isUserLocked(identifier: string): boolean {
    const key = this.hashIdentifier(identifier);
    const lockoutTime = this.lockedUsers.get(key);
    
    if (!lockoutTime) return false;
    
    if (Date.now() > lockoutTime) {
      // Lockout expired
      this.lockedUsers.delete(key);
      this.loginAttempts.delete(key);
      return false;
    }
    
    return true;
  }

  getRemainingLockoutTime(identifier: string): number {
    const key = this.hashIdentifier(identifier);
    const lockoutTime = this.lockedUsers.get(key);
    
    if (!lockoutTime) return 0;
    
    const remaining = lockoutTime - Date.now();
    return Math.max(0, remaining);
  }

  private hashIdentifier(identifier: string): string {
    // Simple hash untuk privacy (di production sebaiknya pakai crypto)
    let hash = 0;
    for (let i = 0; i < identifier.length; i++) {
      const char = identifier.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return hash.toString(36);
  }

  // Input sanitization
  sanitizeInput(input: string): string {
    if (!input) return '';
    
    return input
      .trim()
      .replace(/[<>]/g, '') // Remove potential HTML tags
      .replace(/javascript:/gi, '') // Remove javascript: protocol
      .replace(/on\w+=/gi, '') // Remove event handlers
      .substring(0, 1000); // Limit length
  }

  sanitizeFileName(fileName: string): string {
    if (!fileName) return '';
    
    return fileName
      .replace(/[^a-zA-Z0-9.-_]/g, '_') // Replace invalid characters
      .replace(/^\.+/, '') // Remove leading dots
      .replace(/\.+$/, '') // Remove trailing dots
      .substring(0, 255); // Limit length
  }

  // Content validation
  validateReportContent(content: string): { isValid: boolean; error?: string } {
    if (!content || content.trim().length === 0) {
      return { isValid: false, error: 'Konten laporan tidak boleh kosong' };
    }

    if (content.length > 10000) {
      return { isValid: false, error: 'Konten laporan terlalu panjang (maksimal 10.000 karakter)' };
    }

    // Check for potential spam patterns
    if (this.containsSpamPattern(content)) {
      return { isValid: false, error: 'Konten terdeteksi sebagai spam' };
    }

    return { isValid: true };
  }

  private containsSpamPattern(content: string): boolean {
    const spamPatterns = [
      /(.)\1{20,}/, // Repeated characters
      /(https?:\/\/[^\s]+){5,}/, // Multiple URLs
      /\b(URGENT|SEGERA|PENTING|GRATIS|FREE|PROMO)\b.*\b(URGENT|SEGERA|PENTING|GRATIS|FREE|PROMO)\b/i,
      /(WA|WHATSAPP|CALL|SMS|TELEPON)\s*[\d\s\-\+\(\)]{10,}/i // Phone numbers with marketing terms
    ];

    return spamPatterns.some(pattern => pattern.test(content));
  }

  // Rate limiting
  private rateLimitMap: Map<string, number[]> = new Map();

  checkRateLimit(identifier: string, maxRequests: number = 10, windowMs: number = 60000): boolean {
    const key = this.hashIdentifier(identifier);
    const now = Date.now();
    const windowStart = now - windowMs;

    // Get or create request log for this identifier
    let requests = this.rateLimitMap.get(key) || [];
    
    // Remove old requests outside the window
    requests = requests.filter(timestamp => timestamp > windowStart);
    
    // Check if limit exceeded
    if (requests.length >= maxRequests) {
      logger.warn(`Rate limit exceeded`, { 
        identifier: key.substring(0, 8),
        requests: requests.length 
      });
      return false;
    }

    // Add current request
    requests.push(now);
    this.rateLimitMap.set(key, requests);

    return true;
  }

  // Content Security Policy helper
  generateCSPNonce(): string {
    const array = new Uint8Array(16);
    crypto.getRandomValues(array);
    return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
  }

  // Session security
  validateSession(sessionData: any): boolean {
    if (!sessionData || typeof sessionData !== 'object') {
      return false;
    }

    // Check session expiry
    if (sessionData.expires_at) {
      const expiryTime = new Date(sessionData.expires_at).getTime();
      if (Date.now() > expiryTime) {
        return false;
      }
    }

    // Check required fields
    const requiredFields = ['user', 'access_token'];
    for (const field of requiredFields) {
      if (!sessionData[field]) {
        return false;
      }
    }

    return true;
  }

  // URL validation
  isValidUrl(url: string): boolean {
    try {
      const urlObj = new URL(url);
      // Allow only http and https protocols
      return ['http:', 'https:'].includes(urlObj.protocol);
    } catch {
      return false;
    }
  }

  // Clean up old data periodically
  cleanup(): void {
    const now = Date.now();
    
    // Clean up expired lockouts
    for (const [key, lockoutTime] of this.lockedUsers.entries()) {
      if (now > lockoutTime) {
        this.lockedUsers.delete(key);
        this.loginAttempts.delete(key);
      }
    }

    // Clean up old rate limit data
    const windowMs = 60000; // 1 minute
    const windowStart = now - windowMs;
    
    for (const [key, requests] of this.rateLimitMap.entries()) {
      const validRequests = requests.filter(timestamp => timestamp > windowStart);
      if (validRequests.length === 0) {
        this.rateLimitMap.delete(key);
      } else {
        this.rateLimitMap.set(key, validRequests);
      }
    }
  }
}

// Export singleton instance
export const security = SecurityManager.getInstance();

// Cleanup every 5 minutes
if (typeof window !== 'undefined') {
  setInterval(() => {
    security.cleanup();
  }, 5 * 60 * 1000);
}

// React hooks untuk security
export const useSecurity = () => {
  return {
    validateFile: security.validateFile.bind(security),
    sanitizeInput: security.sanitizeInput.bind(security),
    sanitizeFileName: security.sanitizeFileName.bind(security),
    validateReportContent: security.validateReportContent.bind(security),
    checkRateLimit: security.checkRateLimit.bind(security),
    isValidUrl: security.isValidUrl.bind(security)
  };
};

export default security;