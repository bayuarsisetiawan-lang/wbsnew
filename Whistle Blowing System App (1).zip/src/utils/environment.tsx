import { APP_CONFIG, safeLogger } from './config';
import { FALLBACK_ENV, fallbackLogger } from './env-fallback';

// Safe environment variable access
const getEnvVar = (key: string, defaultValue: string = ''): string => {
  try {
    if (typeof window !== 'undefined' && typeof import.meta !== 'undefined' && import.meta.env) {
      return import.meta.env[key] || defaultValue;
    }
    return defaultValue;
  } catch (error) {
    return defaultValue;
  }
};

const getMode = (): string => {
  try {
    if (typeof window !== 'undefined' && typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.MODE) {
      return import.meta.env.MODE;
    }
    return 'development';
  } catch (error) {
    return 'development';
  }
};

// Environment Configuration
export const ENV = {
  // Environment
  NODE_ENV: getMode(),
  
  // App Info
  APP_NAME: 'WBS Dinas PMPTSP Kab.Tegal',
  APP_VERSION: '1.0.0',
  APP_DESCRIPTION: 'Sistem Pengaduan Whistleblowing Dinas PMPTSP Kabupaten Tegal',
  
  // Supabase Configuration
  SUPABASE_URL: getEnvVar('VITE_SUPABASE_URL', 'https://your-project.supabase.co'),
  SUPABASE_ANON_KEY: getEnvVar('VITE_SUPABASE_ANON_KEY', 'your-anon-key'),
  
  // Feature Flags
  FEATURES: {
    ANALYTICS: getEnvVar('VITE_ENABLE_ANALYTICS', 'false') === 'true',
    ERROR_REPORTING: getEnvVar('VITE_ENABLE_ERROR_REPORTING', 'false') === 'true',
    PERFORMANCE_MONITORING: getEnvVar('VITE_ENABLE_PERFORMANCE', 'false') === 'true',
    DEBUG_MODE: getMode() === 'development',
  },
  
  // API Configuration
  API: {
    TIMEOUT: 30000, // 30 seconds
    RETRY_ATTEMPTS: 3,
    RETRY_DELAY: 1000, // 1 second
  },
  
  // File Upload Configuration
  UPLOAD: {
    MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
    ALLOWED_TYPES: [
      'image/jpeg',
      'image/jpg', 
      'image/png',
      'image/gif',
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain'
    ],
    ALLOWED_EXTENSIONS: ['.jpg', '.jpeg', '.png', '.gif', '.pdf', '.doc', '.docx', '.txt']
  },
  
  // UI Configuration
  UI: {
    TOAST_DURATION: 5000,
    LOADING_TIMEOUT: 30000,
    PAGINATION_SIZE: 10,
    MAX_SEARCH_RESULTS: 100
  },
  
  // Security Configuration
  SECURITY: {
    SESSION_TIMEOUT: 8 * 60 * 60 * 1000, // 8 hours
    MAX_LOGIN_ATTEMPTS: 5,
    LOCKOUT_DURATION: 15 * 60 * 1000, // 15 minutes
    PASSWORD_MIN_LENGTH: 8
  }
};

// Utility functions
export const isProduction = (): boolean => {
  try {
    return ENV.NODE_ENV === 'production';
  } catch (error) {
    return false;
  }
};

export const isDevelopment = (): boolean => {
  try {
    return ENV.NODE_ENV === 'development';
  } catch (error) {
    return true; // Safe default
  }
};

export const isStaging = (): boolean => {
  try {
    return ENV.NODE_ENV === 'staging';
  } catch (error) {
    return false;
  }
};

// Environment-specific configurations
export const getEnvironmentConfig = () => {
  try {
    switch (ENV.NODE_ENV) {
      case 'production':
        return {
          ...ENV,
          API: {
            ...ENV.API,
            TIMEOUT: 60000, // Longer timeout for production
          },
          FEATURES: {
            ...ENV.FEATURES,
            DEBUG_MODE: false,
            ANALYTICS: true,
            ERROR_REPORTING: true,
            PERFORMANCE_MONITORING: true
          }
        };
        
      case 'staging':
        return {
          ...ENV,
          FEATURES: {
            ...ENV.FEATURES,
            DEBUG_MODE: true,
            ANALYTICS: false,
            ERROR_REPORTING: true,
            PERFORMANCE_MONITORING: false
          }
        };
        
      case 'development':
      default:
        return {
          ...ENV,
          FEATURES: {
            ...ENV.FEATURES,
            DEBUG_MODE: true,
            ANALYTICS: false,
            ERROR_REPORTING: false,
            PERFORMANCE_MONITORING: false
          }
        };
    }
  } catch (error) {
    // Return safe defaults
    return FALLBACK_ENV;
  }
};

// Console logging helper for different environments
export const logger = {
  info: (message: string, data?: any) => {
    try {
      if (isDevelopment() || isStaging()) {
        console.log(`[INFO] ${message}`, data);
      }
    } catch (error) {
      fallbackLogger.info(message, data);
    }
  },
  error: (message: string, error?: any) => {
    try {
      console.error(`[ERROR] ${message}`, error);
      
      // Send to error reporting service in production
      if (isProduction() && ENV.FEATURES && ENV.FEATURES.ERROR_REPORTING) {
        // window.Sentry?.captureException(error, {
        //   tags: { component: 'logger' },
        //   extra: { message }
        // });
      }
    } catch (e) {
      fallbackLogger.error(message, error);
    }
  },
  debug: (message: string, data?: any) => {
    try {
      if (ENV.FEATURES && ENV.FEATURES.DEBUG_MODE) {
        console.debug(`[DEBUG] ${message}`, data);
      }
    } catch (error) {
      fallbackLogger.debug(message, data);
    }
  },
  warn: (message: string, data?: any) => {
    try {
      console.warn(`[WARN] ${message}`, data);
    } catch (error) {
      fallbackLogger.warn(message, data);
    }
  }
};

// Performance monitoring helper
export const performanceMonitor = {
  mark: (name: string) => {
    try {
      if (ENV.FEATURES && ENV.FEATURES.PERFORMANCE_MONITORING && typeof window !== 'undefined' && 'performance' in window) {
        performance.mark(name);
      }
    } catch (error) {
      // Silently fail
    }
  },
  measure: (name: string, startMark: string, endMark?: string) => {
    try {
      if (ENV.FEATURES && ENV.FEATURES.PERFORMANCE_MONITORING && typeof window !== 'undefined' && 'performance' in window) {
        if (endMark) {
          performance.measure(name, startMark, endMark);
        } else {
          performance.measure(name, startMark);
        }
        
        const entries = performance.getEntriesByName(name, 'measure');
        if (entries.length > 0) {
          const duration = entries[entries.length - 1].duration;
          logger.debug(`Performance: ${name} took ${duration.toFixed(2)}ms`);
          
          // Send to analytics in production
          if (isProduction() && ENV.FEATURES && ENV.FEATURES.ANALYTICS) {
            // Send performance data to analytics service
          }
        }
      }
    } catch (error) {
      logger.error('Performance measurement failed', error);
    }
  }
};

export default getEnvironmentConfig();