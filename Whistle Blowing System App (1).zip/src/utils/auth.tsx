import { createClient } from './supabase/client';
import type { UserRole, UserMetadata } from './supabase/types';

const supabase = createClient();

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  
  if (error) throw error;
  return data;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getCurrentUser() {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error) throw error;
  return user;
}

export async function getSession() {
  const { data: { session }, error } = await supabase.auth.getSession();
  if (error) throw error;
  return session;
}

export async function getAccessToken(): Promise<string> {
  const session = await getSession();
  if (!session?.access_token) {
    throw new Error('No access token available');
  }
  return session.access_token;
}

export function getUserRole(user: any): UserRole {
  return user?.user_metadata?.role || 'public';
}

export function getUserName(user: any): string {
  return user?.user_metadata?.name || user?.email || 'User';
}

export async function isAdmin(user: any): Promise<boolean> {
  return getUserRole(user) === 'admin';
}

export async function isDisplay(user: any): Promise<boolean> {
  return getUserRole(user) === 'display';
}