import { ENV, logger } from './environment';

// Safe environment variable access helper
const getGAMeasurementId = (): string => {
  try {
    if (typeof window !== 'undefined' && typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_GA_MEASUREMENT_ID) {
      return import.meta.env.VITE_GA_MEASUREMENT_ID;
    }
    return '';
  } catch (error) {
    return '';
  }
};

// Analytics interface untuk tracking user behavior
interface AnalyticsEvent {
  event: string;
  category: string;
  action: string;
  label?: string;
  value?: number;
  userId?: string;
  properties?: Record<string, any>;
}

interface PageView {
  page: string;
  title: string;
  userId?: string;
  properties?: Record<string, any>;
}

class Analytics {
  private isInitialized = false;
  private userId: string | null = null;

  constructor() {
    this.init();
  }

  private init() {
    if (!ENV.FEATURES || !ENV.FEATURES.ANALYTICS || this.isInitialized) {
      return;
    }

    try {
      // Initialize analytics service (Google Analytics, Mixpanel, etc.)
      if (typeof window !== 'undefined') {
        this.setupGoogleAnalytics();
        this.isInitialized = true;
        logger.info('Analytics initialized');
      }
    } catch (error) {
      logger.error('Failed to initialize analytics', error);
    }
  }

  private setupGoogleAnalytics() {
    // Setup Google Analytics 4
    const GA_MEASUREMENT_ID = getGAMeasurementId();
    
    if (GA_MEASUREMENT_ID) {
      // Load gtag script
      const script = document.createElement('script');
      script.async = true;
      script.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;
      document.head.appendChild(script);

      // Initialize gtag
      window.dataLayer = window.dataLayer || [];
      function gtag(...args: any[]) {
        window.dataLayer.push(arguments);
      }
      
      gtag('js', new Date());
      gtag('config', GA_MEASUREMENT_ID, {
        // Privacy-friendly settings
        anonymize_ip: true,
        cookie_expires: 7776000, // 90 days
        send_page_view: false // We'll handle page views manually
      });

      // Make gtag available globally
      (window as any).gtag = gtag;
    }
  }

  setUserId(userId: string) {
    this.userId = userId;
    
    if (this.isInitialized && typeof window !== 'undefined') {
      // Set user ID in analytics service
      if ((window as any).gtag) {
        const measurementId = getGAMeasurementId();
        
        if (measurementId) {
          (window as any).gtag('config', measurementId, {
            user_id: userId
          });
        }
      }
    }
  }

  trackPageView(pageView: PageView) {
    if (!ENV.FEATURES || !ENV.FEATURES.ANALYTICS || !this.isInitialized) {
      return;
    }

    try {
      const data = {
        ...pageView,
        userId: pageView.userId || this.userId,
        timestamp: new Date().toISOString(),
        url: window.location.href,
        referrer: document.referrer
      };

      // Google Analytics
      if ((window as any).gtag) {
        (window as any).gtag('event', 'page_view', {
          page_title: data.title,
          page_location: data.url,
          custom_map: {
            user_id: data.userId
          }
        });
      }

      logger.debug('Page view tracked', data);
    } catch (error) {
      logger.error('Failed to track page view', error);
    }
  }

  trackEvent(event: AnalyticsEvent) {
    if (!ENV.FEATURES || !ENV.FEATURES.ANALYTICS || !this.isInitialized) {
      return;
    }

    try {
      const data = {
        ...event,
        userId: event.userId || this.userId,
        timestamp: new Date().toISOString(),
        url: window.location.href
      };

      // Google Analytics
      if ((window as any).gtag) {
        (window as any).gtag('event', event.action, {
          event_category: event.category,
          event_label: event.label,
          value: event.value,
          custom_parameters: event.properties
        });
      }

      logger.debug('Event tracked', data);
    } catch (error) {
      logger.error('Failed to track event', error);
    }
  }

  // Predefined tracking methods untuk WBS
  trackReportSubmitted(reportId: string, category: string) {
    this.trackEvent({
      event: 'report_submitted',
      category: 'Reports',
      action: 'Submit',
      label: category,
      properties: {
        report_id: reportId
      }
    });
  }

  trackReportViewed(reportId: string) {
    this.trackEvent({
      event: 'report_viewed',
      category: 'Reports',
      action: 'View',
      properties: {
        report_id: reportId
      }
    });
  }

  trackReportStatusChanged(reportId: string, newStatus: string, oldStatus: string) {
    this.trackEvent({
      event: 'report_status_changed',
      category: 'Reports',
      action: 'Status Change',
      label: `${oldStatus} -> ${newStatus}`,
      properties: {
        report_id: reportId,
        new_status: newStatus,
        old_status: oldStatus
      }
    });
  }

  trackUserLogin(role: string) {
    this.trackEvent({
      event: 'user_login',
      category: 'Authentication',
      action: 'Login',
      label: role
    });
  }

  trackUserLogout() {
    this.trackEvent({
      event: 'user_logout',
      category: 'Authentication',
      action: 'Logout'
    });
  }

  trackFileUpload(fileType: string, fileSize: number) {
    this.trackEvent({
      event: 'file_upload',
      category: 'File',
      action: 'Upload',
      label: fileType,
      value: Math.round(fileSize / 1024), // KB
      properties: {
        file_size_bytes: fileSize
      }
    });
  }

  trackSearchPerformed(query: string, resultCount: number) {
    this.trackEvent({
      event: 'search_performed',
      category: 'Search',
      action: 'Query',
      label: query,
      value: resultCount
    });
  }

  trackError(errorMessage: string, errorType: string, page: string) {
    this.trackEvent({
      event: 'error_occurred',
      category: 'Error',
      action: errorType,
      label: errorMessage,
      properties: {
        page,
        error_message: errorMessage
      }
    });
  }

  trackPerformance(metricName: string, value: number, unit: string = 'ms') {
    this.trackEvent({
      event: 'performance_metric',
      category: 'Performance',
      action: metricName,
      value: Math.round(value),
      properties: {
        unit,
        metric_name: metricName
      }
    });
  }
}

// Singleton instance
export const analytics = new Analytics();

// React hooks untuk analytics
export const useAnalytics = () => {
  return {
    trackPageView: (page: string, title: string, properties?: Record<string, any>) => {
      analytics.trackPageView({ page, title, properties });
    },
    trackEvent: (event: AnalyticsEvent) => {
      analytics.trackEvent(event);
    },
    trackReportSubmitted: analytics.trackReportSubmitted.bind(analytics),
    trackReportViewed: analytics.trackReportViewed.bind(analytics),
    trackReportStatusChanged: analytics.trackReportStatusChanged.bind(analytics),
    trackUserLogin: analytics.trackUserLogin.bind(analytics),
    trackUserLogout: analytics.trackUserLogout.bind(analytics),
    trackFileUpload: analytics.trackFileUpload.bind(analytics),
    trackSearchPerformed: analytics.trackSearchPerformed.bind(analytics),
    trackError: analytics.trackError.bind(analytics),
    setUserId: analytics.setUserId.bind(analytics)
  };
};

// Simple page tracking function (use in components with useEffect)
export const trackCurrentPage = () => {
  const pageName = window.location.pathname;
  const pageTitle = document.title;
  analytics.trackPageView({ page: pageName, title: pageTitle });
};

export default analytics;