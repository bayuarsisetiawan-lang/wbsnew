import { projectId, publicAnonKey } from './supabase/info';

/**
 * SIMPLE DATA STORE using KV Store
 * Tidak perlu setup database - langsung jalan!
 */

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-7bc260f6`;

// ============================================
// CATEGORIES
// ============================================

export interface Category {
  id: string;
  name: string;
  description: string;
}

export async function getCategories(): Promise<Category[]> {
  try {
    const response = await fetch(`${API_BASE}/categories`, {
      headers: { 'Authorization': `Bearer ${publicAnonKey}` },
    });
    
    if (!response.ok) {
      console.error('Failed to fetch categories');
      return getDefaultCategories();
    }
    
    const data = await response.json();
    return data.categories || getDefaultCategories();
  } catch (error) {
    console.error('Error fetching categories:', error);
    return getDefaultCategories();
  }
}

export async function createCategory(name: string, description: string): Promise<Category> {
  const response = await fetch(`${API_BASE}/categories`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
    },
    body: JSON.stringify({ name, description }),
  });
  
  if (!response.ok) {
    throw new Error('Failed to create category');
  }
  
  const data = await response.json();
  return data.category;
}

export async function updateCategory(id: string, name: string, description: string): Promise<Category> {
  const response = await fetch(`${API_BASE}/categories/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
    },
    body: JSON.stringify({ name, description }),
  });
  
  if (!response.ok) {
    throw new Error('Failed to update category');
  }
  
  const data = await response.json();
  return data.category;
}

export async function deleteCategory(id: string): Promise<void> {
  const response = await fetch(`${API_BASE}/categories/${id}`, {
    method: 'DELETE',
    headers: {
      'Authorization': `Bearer ${publicAnonKey}`,
    },
  });
  
  if (!response.ok) {
    throw new Error('Failed to delete category');
  }
}

function getDefaultCategories(): Category[] {
  return [
    { id: '1', name: 'Korupsi', description: 'Tindakan korupsi, gratifikasi, atau penyalahgunaan dana' },
    { id: '2', name: 'Penyalahgunaan Wewenang', description: 'Penyalahgunaan jabatan atau kewenangan' },
    { id: '3', name: 'Pelanggaran Disiplin', description: 'Pelanggaran disiplin pegawai atau aturan internal' },
    { id: '4', name: 'Pelanggaran Kode Etik', description: 'Pelanggaran kode etik dan norma perilaku' },
    { id: '5', name: 'Diskriminasi', description: 'Tindakan diskriminasi atau pelecehan' },
    { id: '6', name: 'Fraud', description: 'Penipuan atau kecurangan dalam proses kerja' },
    { id: '7', name: 'Lainnya', description: 'Pengaduan lainnya yang tidak termasuk kategori di atas' },
  ];
}

// ============================================
// REPORTS
// ============================================

export type ReportStatus = 'baru' | 'diproses' | 'selesai' | 'ditolak';

export interface Report {
  id: string;
  ticket_number: string;
  reporter_name: string | null;
  reporter_contact: string | null;
  reporter_anonymous: boolean;
  reported_entity: string | null;
  category_id: string;
  category_name?: string;
  description: string;
  location: string | null;
  incident_date: string | null;
  file_urls: string[] | null;
  status: ReportStatus;
  created_at: string;
  updated_at: string;
  status_history: StatusLog[];
}

export interface StatusLog {
  status: ReportStatus;
  comment: string;
  updated_by: string;
  timestamp: string;
}

function generateTicketNumber(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  
  return `WBS-${year}${month}${day}-${random}`;
}

export async function createReport(reportData: {
  reporter_name: string | null;
  reporter_contact: string | null;
  reporter_anonymous: boolean;
  reported_entity: string | null;
  category_id: string;
  description: string;
  location: string | null;
  incident_date: string | null;
}): Promise<Report> {
  const response = await fetch(`${API_BASE}/reports`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
    },
    body: JSON.stringify(reportData),
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to create report');
  }
  
  const data = await response.json();
  return data.report;
}

export async function getReports(options?: {
  status?: ReportStatus;
  limit?: number;
  category_id?: string;
}): Promise<Report[]> {
  const params = new URLSearchParams();
  if (options?.status) params.append('status', options.status);
  if (options?.limit) params.append('limit', String(options.limit));
  if (options?.category_id) params.append('category_id', options.category_id);
  
  const response = await fetch(`${API_BASE}/reports?${params}`, {
    headers: { 'Authorization': `Bearer ${publicAnonKey}` },
  });
  
  if (!response.ok) {
    console.error('Failed to fetch reports');
    return [];
  }
  
  const data = await response.json();
  return data.reports || [];
}

export async function getReportByTicket(ticketNumber: string): Promise<Report | null> {
  const response = await fetch(`${API_BASE}/reports/${ticketNumber}`, {
    headers: { 'Authorization': `Bearer ${publicAnonKey}` },
  });
  
  if (!response.ok) {
    return null;
  }
  
  const data = await response.json();
  return data.report || null;
}

export async function updateReportStatus(
  ticketNumber: string,
  status: ReportStatus,
  comment: string = '',
  updatedBy: string = 'Admin',
  accessToken?: string
): Promise<Report> {
  const response = await fetch(`${API_BASE}/reports/${ticketNumber}/status`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken || publicAnonKey}`,
    },
    body: JSON.stringify({ status, comment, updated_by: updatedBy }),
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to update report status');
  }
  
  const data = await response.json();
  return data.report;
}

export async function deleteReport(ticketNumber: string, accessToken: string): Promise<void> {
  const response = await fetch(`${API_BASE}/reports/${ticketNumber}`, {
    method: 'DELETE',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
    },
  });
  
  if (!response.ok) {
    throw new Error('Failed to delete report');
  }
}

export async function getReportStats(): Promise<{
  total: number;
  baru: number;
  diproses: number;
  selesai: number;
  ditolak: number;
}> {
  const response = await fetch(`${API_BASE}/reports/stats`, {
    headers: { 'Authorization': `Bearer ${publicAnonKey}` },
  });
  
  if (!response.ok) {
    return { total: 0, baru: 0, diproses: 0, selesai: 0, ditolak: 0 };
  }
  
  const data = await response.json();
  return data.stats;
}

// ============================================
// FILE UPLOAD
// ============================================

export async function uploadFile(file: File, reportId: string): Promise<string> {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('reportId', reportId);
  
  const response = await fetch(`${API_BASE}/upload`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${publicAnonKey}`,
    },
    body: formData,
  });
  
  if (!response.ok) {
    throw new Error('Failed to upload file');
  }
  
  const data = await response.json();
  return data.fileUrl;
}