// Fallback environment configuration that always works
// This is used when all other environment access fails

export const FALLBACK_ENV = {
  NODE_ENV: 'development',
  APP_NAME: 'WBS Dinas PMPTSP Kab.Tegal',
  APP_VERSION: '1.0.0',
  APP_DESCRIPTION: 'Sistem Pengaduan Whistleblowing Dinas PMPTSP Kabupaten Tegal',
  
  SUPABASE_URL: 'https://placeholder.supabase.co',
  SUPABASE_ANON_KEY: 'placeholder-key',
  
  FEATURES: {
    ANALYTICS: false,
    ERROR_REPORTING: false,
    PERFORMANCE_MONITORING: false,
    DEBUG_MODE: true,
  },
  
  API: {
    TIMEOUT: 30000,
    RETRY_ATTEMPTS: 3,
    RETRY_DELAY: 1000,
  },
  
  UPLOAD: {
    MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
    ALLOWED_TYPES: [
      'image/jpeg',
      'image/jpg', 
      'image/png',
      'image/gif',
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain'
    ],
    ALLOWED_EXTENSIONS: ['.jpg', '.jpeg', '.png', '.gif', '.pdf', '.doc', '.docx', '.txt']
  },
  
  UI: {
    TOAST_DURATION: 5000,
    LOADING_TIMEOUT: 30000,
    PAGINATION_SIZE: 10,
    MAX_SEARCH_RESULTS: 100
  },
  
  SECURITY: {
    SESSION_TIMEOUT: 8 * 60 * 60 * 1000, // 8 hours
    MAX_LOGIN_ATTEMPTS: 5,
    LOCKOUT_DURATION: 15 * 60 * 1000, // 15 minutes
    PASSWORD_MIN_LENGTH: 8
  }
};

export const fallbackLogger = {
  info: (message: string, data?: any) => {
    console.log(`[INFO] ${message}`, data);
  },
  error: (message: string, error?: any) => {
    console.error(`[ERROR] ${message}`, error);
  },
  debug: (message: string, data?: any) => {
    console.debug(`[DEBUG] ${message}`, data);
  },
  warn: (message: string, data?: any) => {
    console.warn(`[WARN] ${message}`, data);
  }
};

export default FALLBACK_ENV;