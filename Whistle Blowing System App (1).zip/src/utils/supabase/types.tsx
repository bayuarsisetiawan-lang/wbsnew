export type UserRole = 'admin' | 'display' | 'public';

export type ReportStatus = 'baru' | 'diproses' | 'selesai' | 'ditolak';

export interface Category {
  id: string;
  name: string;
  description: string;
  created_at: string;
}

export interface Report {
  id: string;
  ticket_number: string;
  reporter_name: string | null;
  reporter_contact: string | null;
  reporter_anonymous: boolean;
  reported_entity: string | null;
  category_id: string;
  category?: Category;
  description: string;
  location: string | null;
  incident_date: string | null;
  file_urls: string[] | null;
  status: ReportStatus;
  created_at: string;
  updated_at: string;
}

export interface ReportStatusLog {
  id: string;
  report_id: string;
  status: ReportStatus;
  comment: string | null;
  updated_by: string;
  created_at: string;
}

export interface UserMetadata {
  role: UserRole;
  name: string;
}