import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { projectId, publicAnonKey } from './supabase/info';

export interface AppSettings {
  institutionName: string;
  institutionShortName: string;
  institutionAddress: string;
  institutionPhone: string;
  institutionEmail: string;
  institutionWebsite: string;
  logoUrl: string;
  footerText: string;
  heroTitle: string;
  heroSubtitle: string;
}

const defaultSettings: AppSettings = {
  institutionName: 'Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Tegal',
  institutionShortName: 'DPMPTSP Kab. Tegal',
  institutionAddress: 'Jl. Pemuda No. 1, Kabupaten Tegal, Jawa Tengah',
  institutionPhone: '(0283) 123456',
  institutionEmail: 'dpmptsp@tegalkab.go.id',
  institutionWebsite: 'https://dpmptsp.tegalkab.go.id',
  logoUrl: '',
  footerText: 'Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Tegal',
  heroTitle: 'Whistle Blowing System',
  heroSubtitle: 'Laporkan dugaan pelanggaran, penyimpangan, atau tindakan yang merugikan instansi secara aman dan terpercaya.'
};

interface SettingsContextType {
  settings: AppSettings;
  loading: boolean;
  updateSettings: (newSettings: Partial<AppSettings>) => Promise<void>;
  uploadLogo: (file: File) => Promise<string>;
  refreshSettings: () => Promise<void>;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);
  const [loading, setLoading] = useState(true);

  const fetchSettings = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-7bc260f6/settings`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        if (data.settings) {
          setSettings({ ...defaultSettings, ...data.settings });
        }
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const updateSettings = async (newSettings: Partial<AppSettings>) => {
    try {
      // Import createClient here to get session
      const { createClient } = await import('./supabase/client');
      const supabase = createClient();
      
      // Get current session
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError || !session?.access_token) {
        throw new Error('Anda harus login terlebih dahulu. Silakan logout dan login kembali.');
      }

      const accessToken = session.access_token;
      console.log('Updating settings...', { accessToken: 'exists', userId: session.user?.id });

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-7bc260f6/settings`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ settings: newSettings }),
        }
      );

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('Update settings failed:', { 
          status: response.status, 
          statusText: response.statusText,
          error: errorData 
        });
        
        if (response.status === 401) {
          throw new Error('Sesi login Anda telah berakhir. Silakan login kembali.');
        } else if (response.status === 403) {
          throw new Error('Anda tidak memiliki akses. Hanya admin yang dapat mengubah pengaturan.');
        } else {
          throw new Error(errorData.error || 'Gagal menyimpan pengaturan');
        }
      }

      const updatedSettings = { ...settings, ...newSettings };
      setSettings(updatedSettings);
      console.log('Settings updated successfully');
    } catch (error) {
      console.error('Error updating settings:', error);
      throw error;
    }
  };

  const uploadLogo = async (file: File): Promise<string> => {
    try {
      // Convert image to base64
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onloadend = () => {
          const base64String = reader.result as string;
          resolve(base64String);
        };
        
        reader.onerror = () => {
          reject(new Error('Failed to read file'));
        };
        
        reader.readAsDataURL(file);
      });
    } catch (error) {
      console.error('Error uploading logo:', error);
      throw error;
    }
  };

  const refreshSettings = async () => {
    await fetchSettings();
  };

  return (
    <SettingsContext.Provider value={{ settings, loading, updateSettings, uploadLogo, refreshSettings }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}