import { useState } from 'react';
import { Search, AlertCircle, Clock, CheckCircle, XCircle, FileText } from 'lucide-react';
import { getReportByTicket, type Report } from '../utils/dataStore';

export function PantauAduan() {
  const [ticketNumber, setTicketNumber] = useState('');
  const [report, setReport] = useState<Report | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSearch() {
    if (!ticketNumber.trim()) {
      setError('Nomor tiket tidak boleh kosong');
      return;
    }

    setLoading(true);
    setError('');
    setReport(null);

    try {
      const data = await getReportByTicket(ticketNumber.trim());
      
      if (!data) {
        setError('Laporan tidak ditemukan. Periksa kembali nomor tiket Anda.');
      } else {
        setReport(data);
      }
    } catch (err) {
      console.error('Error searching report:', err);
      setError('Terjadi kesalahan saat mencari laporan. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  }

  function getStatusIcon(status: string) {
    switch (status) {
      case 'baru':
        return <FileText className="h-6 w-6 text-blue-600" />;
      case 'diproses':
        return <Clock className="h-6 w-6 text-yellow-600" />;
      case 'selesai':
        return <CheckCircle className="h-6 w-6 text-green-600" />;
      case 'ditolak':
        return <XCircle className="h-6 w-6 text-red-600" />;
      default:
        return <FileText className="h-6 w-6 text-gray-600" />;
    }
  }

  function getStatusBadge(status: string) {
    switch (status) {
      case 'baru':
        return <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full">Baru</span>;
      case 'diproses':
        return <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full">Diproses</span>;
      case 'selesai':
        return <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full">Selesai</span>;
      case 'ditolak':
        return <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full">Ditolak</span>;
      default:
        return <span className="px-3 py-1 bg-gray-100 text-gray-800 rounded-full">Unknown</span>;
    }
  }

  function formatDate(dateString: string) {
    return new Date(dateString).toLocaleString('id-ID', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="flex items-center space-x-3 mb-6">
            <Search className="h-8 w-8 text-blue-600" />
            <h1 className="text-gray-900">Pantau Status Aduan</h1>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
            <div className="flex items-start space-x-3">
              <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-blue-800">
                <p>
                  Masukkan nomor tiket yang Anda terima saat mengirim laporan untuk melihat status
                  terkini dari pengaduan Anda.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <div>
              <label className="block text-gray-700 mb-2">
                Nomor Tiket <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={ticketNumber}
                onChange={(e) => {
                  setTicketNumber(e.target.value);
                  setError('');
                }}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Contoh: WBS-20251003-1234"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
              {error && (
                <p className="text-red-500 mt-2">{error}</p>
              )}
            </div>

            <button
              onClick={handleSearch}
              disabled={loading}
              className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
            >
              {loading ? (
                <span>Mencari...</span>
              ) : (
                <>
                  <Search className="h-5 w-5" />
                  <span>Cari Laporan</span>
                </>
              )}
            </button>
          </div>

          {report && (
            <div className="border-t pt-8 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-gray-900 mb-1">Status Laporan</h2>
                  <p className="text-gray-600">Nomor Tiket: {report.ticket_number}</p>
                </div>
                {getStatusBadge(report.status)}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-gray-600 mb-1">Kategori</div>
                  <div className="text-gray-900">{report.category_name || '-'}</div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-gray-600 mb-1">Tanggal Laporan</div>
                  <div className="text-gray-900">{formatDate(report.created_at)}</div>
                </div>

                {report.location && (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-gray-600 mb-1">Lokasi Kejadian</div>
                    <div className="text-gray-900">{report.location}</div>
                  </div>
                )}

                {report.incident_date && (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="text-gray-600 mb-1">Waktu Kejadian</div>
                    <div className="text-gray-900">{new Date(report.incident_date).toLocaleDateString('id-ID')}</div>
                  </div>
                )}
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="text-gray-600 mb-2">Deskripsi</div>
                <div className="text-gray-900 whitespace-pre-wrap">{report.description}</div>
              </div>

              {report.status_history && report.status_history.length > 0 && (
                <div>
                  <h3 className="text-gray-900 mb-4">Riwayat Status</h3>
                  <div className="space-y-4">
                    {report.status_history.map((log, index) => (
                      <div key={index} className="flex items-start space-x-4 border-l-4 border-blue-500 pl-4 py-2">
                        <div className="flex-shrink-0 mt-1">
                          {getStatusIcon(log.status)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-1">
                            {getStatusBadge(log.status)}
                            <span className="text-gray-500">
                              {formatDate(log.timestamp)}
                            </span>
                          </div>
                          {log.comment && (
                            <p className="text-gray-700 mt-2">{log.comment}</p>
                          )}
                          <p className="text-gray-500 mt-1">oleh {log.updated_by}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}