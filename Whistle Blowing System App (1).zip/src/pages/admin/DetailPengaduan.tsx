import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Save } from 'lucide-react';
import { AdminLayout } from '../../components/AdminLayout';
import { getCurrentUser, getUserRole, getAccessToken } from '../../utils/auth';
import { getReportByTicket, updateReportStatus, type Report, type ReportStatus } from '../../utils/dataStore';

const statusLabels = {
  baru: 'Baru',
  diproses: 'Diproses',
  selesai: 'Selesai',
  ditolak: 'Ditolak',
};

const statusColors = {
  baru: 'bg-blue-100 text-blue-800',
  diproses: 'bg-yellow-100 text-yellow-800',
  selesai: 'bg-green-100 text-green-800',
  ditolak: 'bg-red-100 text-red-800',
};

export function DetailPengaduan() {
  const { id: ticketNumber } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [report, setReport] = useState<Report | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [user, setUser] = useState<any>(null);
  
  const [newStatus, setNewStatus] = useState<ReportStatus>('baru');
  const [comment, setComment] = useState('');

  useEffect(() => {
    checkAuth();
    loadData();
  }, [ticketNumber]);

  async function checkAuth() {
    try {
      const currentUser = await getCurrentUser();
      const role = getUserRole(currentUser);
      
      if (role !== 'admin') {
        navigate('/login');
      }
      setUser(currentUser);
    } catch (error) {
      navigate('/login');
    }
  }

  async function loadData() {
    if (!ticketNumber) return;
    
    try {
      const foundReport = await getReportByTicket(ticketNumber);
      
      if (!foundReport) {
        alert('Laporan tidak ditemukan');
        navigate('/admin/pengaduan');
        return;
      }
      
      setReport(foundReport);
      setNewStatus(foundReport.status);
    } catch (error) {
      console.error('Error loading report:', error);
      alert('Gagal memuat data laporan');
    } finally {
      setLoading(false);
    }
  }

  async function handleUpdateStatus(e: React.FormEvent) {
    e.preventDefault();
    
    if (!ticketNumber || !user) return;
    
    if (newStatus === report?.status && !comment.trim()) {
      alert('Tidak ada perubahan atau komentar yang ditambahkan');
      return;
    }

    setSaving(true);

    try {
      const accessToken = await getAccessToken();
      const userName = user.user_metadata?.name || 'Admin';
      
      await updateReportStatus(
        ticketNumber,
        newStatus,
        comment.trim() || '',
        userName,
        accessToken
      );
      
      alert('Status berhasil diperbarui');
      setComment('');
      await loadData();
    } catch (error) {
      console.error('Error updating status:', error);
      alert('Gagal mengupdate status');
    } finally {
      setSaving(false);
    }
  }

  function formatDate(dateString: string) {
    return new Date(dateString).toLocaleString('id-ID', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-600">Memuat data...</div>
        </div>
      </AdminLayout>
    );
  }

  if (!report) {
    return (
      <AdminLayout>
        <div className="text-center text-gray-500 py-12">
          Laporan tidak ditemukan
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <button
          onClick={() => navigate('/admin/pengaduan')}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Kembali ke Daftar Pengaduan</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h1 className="text-gray-900 mb-4">Detail Laporan</h1>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-gray-600 mb-1">Nomor Tiket</div>
                    <div className="text-gray-900">{report.ticket_number}</div>
                  </div>
                  <div>
                    <div className="text-gray-600 mb-1">Status</div>
                    <span className={`px-3 py-1 rounded-full ${statusColors[report.status]}`}>
                      {statusLabels[report.status]}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-gray-600 mb-1">Kategori</div>
                    <div className="text-gray-900">{report.category_name || '-'}</div>
                  </div>
                  <div>
                    <div className="text-gray-600 mb-1">Tanggal Laporan</div>
                    <div className="text-gray-900">{formatDate(report.created_at)}</div>
                  </div>
                </div>

                {!report.reporter_anonymous && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-gray-600 mb-1">Nama Pelapor</div>
                      <div className="text-gray-900">{report.reporter_name || '-'}</div>
                    </div>
                    <div>
                      <div className="text-gray-600 mb-1">Kontak Pelapor</div>
                      <div className="text-gray-900">{report.reporter_contact || '-'}</div>
                    </div>
                  </div>
                )}

                {report.reporter_anonymous && (
                  <div>
                    <div className="text-gray-600 mb-1">Pelapor</div>
                    <div className="text-gray-900 italic">Anonim</div>
                  </div>
                )}

                {report.reported_entity && (
                  <div>
                    <div className="text-gray-600 mb-1">Terlapor</div>
                    <div className="text-gray-900">{report.reported_entity}</div>
                  </div>
                )}

                {report.location && (
                  <div>
                    <div className="text-gray-600 mb-1">Lokasi Kejadian</div>
                    <div className="text-gray-900">{report.location}</div>
                  </div>
                )}

                {report.incident_date && (
                  <div>
                    <div className="text-gray-600 mb-1">Waktu Kejadian</div>
                    <div className="text-gray-900">
                      {new Date(report.incident_date).toLocaleDateString('id-ID')}
                    </div>
                  </div>
                )}

                <div>
                  <div className="text-gray-600 mb-2">Deskripsi Kronologis</div>
                  <div className="bg-gray-50 p-4 rounded-lg text-gray-900 whitespace-pre-wrap">
                    {report.description}
                  </div>
                </div>
              </div>
            </div>

            {report.status_history && report.status_history.length > 0 && (
              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-gray-900 mb-4">Riwayat Status</h2>
                <div className="space-y-4">
                  {report.status_history.map((log, index) => (
                    <div key={index} className="border-l-4 border-blue-500 pl-4 py-2">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className={`px-2 py-1 rounded-full ${statusColors[log.status]}`}>
                          {statusLabels[log.status]}
                        </span>
                        <span className="text-gray-500">{formatDate(log.timestamp)}</span>
                      </div>
                      {log.comment && (
                        <p className="text-gray-700 mb-1">{log.comment}</p>
                      )}
                      <p className="text-gray-500">oleh {log.updated_by}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-gray-900 mb-4">Update Status</h2>
              
              <form onSubmit={handleUpdateStatus} className="space-y-4">
                <div>
                  <label className="block text-gray-700 mb-2">Status Baru</label>
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as ReportStatus)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="baru">Baru</option>
                    <option value="diproses">Diproses</option>
                    <option value="selesai">Selesai</option>
                    <option value="ditolak">Ditolak</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-700 mb-2">Komentar</label>
                  <textarea
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Tambahkan komentar (opsional)"
                  />
                </div>

                <button
                  type="submit"
                  disabled={saving}
                  className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                  <Save className="h-5 w-5" />
                  <span>{saving ? 'Menyimpan...' : 'Update Status'}</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}