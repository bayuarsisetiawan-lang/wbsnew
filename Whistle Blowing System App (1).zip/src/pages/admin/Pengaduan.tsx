import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Eye, Trash2 } from 'lucide-react';
import { AdminLayout } from '../../components/AdminLayout';
import { getCurrentUser, getUserRole, getAccessToken } from '../../utils/auth';
import { getReports, getCategories, deleteReport, type Report, type Category, type ReportStatus } from '../../utils/dataStore';

const statusLabels = {
  baru: 'Baru',
  diproses: 'Diproses',
  selesai: 'Selesai',
  ditolak: 'Ditolak',
};

const statusColors = {
  baru: 'bg-blue-100 text-blue-800',
  diproses: 'bg-yellow-100 text-yellow-800',
  selesai: 'bg-green-100 text-green-800',
  ditolak: 'bg-red-100 text-red-800',
};

export function Pengaduan() {
  const navigate = useNavigate();
  const [reports, setReports] = useState<Report[]>([]);
  const [filteredReports, setFilteredReports] = useState<Report[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [filters, setFilters] = useState({
    search: '',
    status: '' as ReportStatus | '',
    categoryId: '',
  });

  useEffect(() => {
    checkAuth();
    loadData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [reports, filters]);

  async function checkAuth() {
    try {
      const user = await getCurrentUser();
      const role = getUserRole(user);
      
      if (role !== 'admin') {
        navigate('/login');
      }
    } catch (error) {
      navigate('/login');
    }
  }

  async function loadData() {
    try {
      setLoading(true);
      
      const [reportsData, categoriesData] = await Promise.all([
        getReports(),
        getCategories(),
      ]);
      
      setReports(reportsData || []);
      setCategories(categoriesData || []);
    } catch (error) {
      console.error('Error loading data:', error);
      setReports([]);
      setCategories([]);
    } finally {
      setLoading(false);
    }
  }

  function applyFilters() {
    let filtered = [...reports];

    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      filtered = filtered.filter(
        r =>
          r.ticket_number.toLowerCase().includes(searchLower) ||
          r.description.toLowerCase().includes(searchLower) ||
          r.reported_entity?.toLowerCase().includes(searchLower)
      );
    }

    if (filters.status) {
      filtered = filtered.filter(r => r.status === filters.status);
    }

    if (filters.categoryId) {
      filtered = filtered.filter(r => r.category_id === filters.categoryId);
    }

    setFilteredReports(filtered);
  }

  async function handleDelete(ticketNumber: string) {
    if (!confirm('Apakah Anda yakin ingin menghapus laporan ini?')) {
      return;
    }

    try {
      const accessToken = await getAccessToken();
      await deleteReport(ticketNumber, accessToken);
      setReports(reports.filter(r => r.ticket_number !== ticketNumber));
      alert('Laporan berhasil dihapus');
    } catch (error) {
      console.error('Error deleting report:', error);
      alert('Gagal menghapus laporan');
    }
  }

  function formatDate(dateString: string) {
    return new Date(dateString).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  }

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-600">Memuat data...</div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-gray-900 mb-2">Kelola Pengaduan</h1>
            <p className="text-gray-600">Daftar semua pengaduan yang masuk</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div>
              <label className="block text-gray-700 mb-2">Cari</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  value={filters.search}
                  onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                  placeholder="Nomor tiket, deskripsi..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Status</label>
              <select
                value={filters.status}
                onChange={(e) => setFilters({ ...filters, status: e.target.value as ReportStatus | '' })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Semua Status</option>
                <option value="baru">Baru</option>
                <option value="diproses">Diproses</option>
                <option value="selesai">Selesai</option>
                <option value="ditolak">Ditolak</option>
              </select>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">Kategori</label>
              <select
                value={filters.categoryId}
                onChange={(e) => setFilters({ ...filters, categoryId: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Semua Kategori</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="text-gray-600 mb-4">
            Menampilkan {filteredReports.length} dari {reports.length} laporan
          </div>

          <div className="overflow-x-auto">
            {filteredReports.length > 0 ? (
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-gray-600">Nomor Tiket</th>
                    <th className="px-6 py-3 text-left text-gray-600">Kategori</th>
                    <th className="px-6 py-3 text-left text-gray-600">Deskripsi</th>
                    <th className="px-6 py-3 text-left text-gray-600">Status</th>
                    <th className="px-6 py-3 text-left text-gray-600">Tanggal</th>
                    <th className="px-6 py-3 text-left text-gray-600">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredReports.map((report) => (
                    <tr key={report.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-gray-900">{report.ticket_number}</td>
                      <td className="px-6 py-4 text-gray-600">{report.category_name || '-'}</td>
                      <td className="px-6 py-4 text-gray-600">
                        <div className="max-w-xs truncate">{report.description}</div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-full ${statusColors[report.status]}`}>
                          {statusLabels[report.status]}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-gray-600">{formatDate(report.created_at)}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-3">
                          <Link
                            to={`/admin/pengaduan/${report.ticket_number}`}
                            className="text-blue-600 hover:text-blue-700"
                            title="Lihat detail"
                          >
                            <Eye className="h-5 w-5" />
                          </Link>
                          <button
                            onClick={() => handleDelete(report.ticket_number)}
                            className="text-red-600 hover:text-red-700"
                            title="Hapus"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="text-center text-gray-500 py-12">
                {reports.length === 0 ? 'Belum ada laporan' : 'Tidak ada laporan yang sesuai filter'}
              </div>
            )}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}