import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell 
} from 'recharts';
import { FileText, Clock, CheckCircle, XCircle, TrendingUp } from 'lucide-react';
import { AdminLayout } from '../../components/AdminLayout';
import { getCurrentUser, getUserRole } from '../../utils/auth';
import { getReports, getReportStats, getCategories, type Report, type Category } from '../../utils/dataStore';

const COLORS = {
  baru: '#3B82F6',
  diproses: '#F59E0B',
  selesai: '#10B981',
  ditolak: '#EF4444',
};

export function Dashboard() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    total: 0,
    baru: 0,
    diproses: 0,
    selesai: 0,
    ditolak: 0,
  });
  const [reports, setReports] = useState<Report[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    async function initDashboard() {
      try {
        const user = await getCurrentUser();
        const role = getUserRole(user);
        
        if (role !== 'admin') {
          navigate('/login');
          return;
        }

        const [statsData, reportsData, categoriesData] = await Promise.all([
          getReportStats(),
          getReports({ limit: 10 }),
          getCategories(),
        ]);
        
        setStats(statsData);
        setReports(reportsData);
        setCategories(categoriesData);
      } catch (error) {
        console.error('Error loading dashboard data:', error);
      } finally {
        setLoading(false);
      }
    }

    initDashboard();
  }, [navigate]);

  const statusData = [
    { name: 'Baru', value: stats.baru, color: COLORS.baru },
    { name: 'Diproses', value: stats.diproses, color: COLORS.diproses },
    { name: 'Selesai', value: stats.selesai, color: COLORS.selesai },
    { name: 'Ditolak', value: stats.ditolak, color: COLORS.ditolak },
  ];

  const categoryData = categories.map(cat => {
    const count = reports.filter(r => r.category_id === cat.id).length;
    return { name: cat.name, count };
  }).filter(d => d.count > 0);

  function formatDate(dateString: string) {
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  }

  function getStatusBadge(status: string) {
    switch (status) {
      case 'baru':
        return <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full">Baru</span>;
      case 'diproses':
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full">Diproses</span>;
      case 'selesai':
        return <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full">Selesai</span>;
      case 'ditolak':
        return <span className="px-2 py-1 bg-red-100 text-red-800 rounded-full">Ditolak</span>;
      default:
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full">Unknown</span>;
    }
  }

  if (loading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-500">Memuat data...</div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-gray-900 mb-2">Dashboard</h1>
          <p className="text-gray-600">Ringkasan statistik dan laporan terbaru</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="text-gray-600">Total Laporan</div>
              <TrendingUp className="h-5 w-5 text-gray-400" />
            </div>
            <div className="text-gray-900">{stats.total}</div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="text-gray-600">Baru</div>
              <FileText className="h-5 w-5 text-blue-500" />
            </div>
            <div className="text-blue-600">{stats.baru}</div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="text-gray-600">Diproses</div>
              <Clock className="h-5 w-5 text-yellow-500" />
            </div>
            <div className="text-yellow-600">{stats.diproses}</div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="text-gray-600">Selesai</div>
              <CheckCircle className="h-5 w-5 text-green-500" />
            </div>
            <div className="text-green-600">{stats.selesai}</div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <div className="text-gray-600">Ditolak</div>
              <XCircle className="h-5 w-5 text-red-500" />
            </div>
            <div className="text-red-600">{stats.ditolak}</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-gray-900 mb-4">Status Laporan</h2>
            {stats.total > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => `${entry.name}: ${entry.value}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center text-gray-500 py-12">Belum ada data</div>
            )}
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-gray-900 mb-4">Laporan per Kategori</h2>
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={categoryData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="count" fill="#3B82F6" name="Jumlah Laporan" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center text-gray-500 py-12">Belum ada data</div>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b">
            <h2 className="text-gray-900">Laporan Terbaru</h2>
          </div>
          <div className="overflow-x-auto">
            {reports.length > 0 ? (
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-gray-600">Nomor Tiket</th>
                    <th className="px-6 py-3 text-left text-gray-600">Kategori</th>
                    <th className="px-6 py-3 text-left text-gray-600">Status</th>
                    <th className="px-6 py-3 text-left text-gray-600">Tanggal</th>
                    <th className="px-6 py-3 text-left text-gray-600">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {reports.map((report) => (
                    <tr key={report.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-gray-900">{report.ticket_number}</td>
                      <td className="px-6 py-4 text-gray-600">{report.category_name || '-'}</td>
                      <td className="px-6 py-4">{getStatusBadge(report.status)}</td>
                      <td className="px-6 py-4 text-gray-600">{formatDate(report.created_at)}</td>
                      <td className="px-6 py-4">
                        <Link
                          to={`/admin/pengaduan/${report.ticket_number}`}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          Lihat Detail
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="text-center text-gray-500 py-12">Belum ada laporan</div>
            )}
          </div>
          {reports.length > 0 && (
            <div className="p-4 border-t">
              <Link
                to="/admin/pengaduan"
                className="text-blue-600 hover:text-blue-700"
              >
                Lihat Semua Laporan →
              </Link>
            </div>
          )}
        </div>
      </div>
    </AdminLayout>
  );
}