import { useState, useRef } from 'react';
import { AdminLayout } from '../../components/AdminLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { Button } from '../../components/ui/button';
import { useSettings } from '../../utils/settings';
import { toast } from 'sonner@2.0.3';
import { Upload, Save, Image as ImageIcon } from 'lucide-react';

export function Settings() {
  const { settings, updateSettings, uploadLogo } = useSettings();
  const [formData, setFormData] = useState(settings);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string>(settings.logoUrl);
  const [saving, setSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleLogoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        toast.error('Ukuran file maksimal 2MB');
        return;
      }
      
      if (!file.type.startsWith('image/')) {
        toast.error('File harus berupa gambar');
        return;
      }

      setLogoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setLogoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      let newLogoUrl = formData.logoUrl;

      // Upload logo jika ada file baru (convert to base64)
      if (logoFile) {
        toast.info('Memproses logo...');
        newLogoUrl = await uploadLogo(logoFile);
      }

      // Update settings
      await updateSettings({
        ...formData,
        logoUrl: newLogoUrl,
      });

      toast.success('Pengaturan berhasil disimpan!');
      
      // Reset logo file after save
      setLogoFile(null);
    } catch (error: any) {
      console.error('Error saving settings:', error);
      toast.error(error.message || 'Gagal menyimpan pengaturan');
    } finally {
      setSaving(false);
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Pengaturan Aplikasi</h1>
          <p className="text-muted-foreground mt-2">
            Kelola tampilan dan informasi instansi Anda
          </p>
        </div>

        <div className="grid gap-6">
          {/* Logo Upload */}
          <Card>
            <CardHeader>
              <CardTitle>Logo Instansi</CardTitle>
              <CardDescription>
                Upload logo instansi Anda. Rekomendasi: PNG/JPG dengan ukuran maksimal 2MB
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-6">
                <div className="w-32 h-32 border-2 border-dashed rounded-lg flex items-center justify-center bg-muted">
                  {logoPreview ? (
                    <img 
                      src={logoPreview} 
                      alt="Logo preview" 
                      className="max-w-full max-h-full object-contain p-2"
                    />
                  ) : (
                    <ImageIcon className="w-12 h-12 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleLogoSelect}
                    className="hidden"
                  />
                  <Button
                    onClick={() => fileInputRef.current?.click()}
                    variant="outline"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Pilih Logo
                  </Button>
                  {logoFile && (
                    <p className="text-sm text-muted-foreground mt-2">
                      File dipilih: {logoFile.name}
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Informasi Instansi */}
          <Card>
            <CardHeader>
              <CardTitle>Informasi Instansi</CardTitle>
              <CardDescription>
                Informasi ini akan ditampilkan di seluruh aplikasi
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="space-y-2">
                  <Label htmlFor="institutionName">Nama Instansi Lengkap</Label>
                  <Input
                    id="institutionName"
                    value={formData.institutionName}
                    onChange={(e) => handleInputChange('institutionName', e.target.value)}
                    placeholder="Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Tegal"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="institutionShortName">Nama Singkat</Label>
                  <Input
                    id="institutionShortName"
                    value={formData.institutionShortName}
                    onChange={(e) => handleInputChange('institutionShortName', e.target.value)}
                    placeholder="DPMPTSP Kab. Tegal"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="institutionAddress">Alamat</Label>
                  <Textarea
                    id="institutionAddress"
                    value={formData.institutionAddress}
                    onChange={(e) => handleInputChange('institutionAddress', e.target.value)}
                    placeholder="Jl. Pemuda No. 1, Kabupaten Tegal, Jawa Tengah"
                    rows={3}
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="institutionPhone">Telepon</Label>
                    <Input
                      id="institutionPhone"
                      value={formData.institutionPhone}
                      onChange={(e) => handleInputChange('institutionPhone', e.target.value)}
                      placeholder="(0283) 123456"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="institutionEmail">Email</Label>
                    <Input
                      id="institutionEmail"
                      type="email"
                      value={formData.institutionEmail}
                      onChange={(e) => handleInputChange('institutionEmail', e.target.value)}
                      placeholder="dpmptsp@tegalkab.go.id"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="institutionWebsite">Website</Label>
                  <Input
                    id="institutionWebsite"
                    type="url"
                    value={formData.institutionWebsite}
                    onChange={(e) => handleInputChange('institutionWebsite', e.target.value)}
                    placeholder="https://dpmptsp.tegalkab.go.id"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Teks Halaman Utama */}
          <Card>
            <CardHeader>
              <CardTitle>Teks Halaman Utama</CardTitle>
              <CardDescription>
                Sesuaikan teks yang ditampilkan di halaman utama
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="heroTitle">Judul Utama</Label>
                <Input
                  id="heroTitle"
                  value={formData.heroTitle}
                  onChange={(e) => handleInputChange('heroTitle', e.target.value)}
                  placeholder="Whistle Blowing System"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="heroSubtitle">Subjudul</Label>
                <Textarea
                  id="heroSubtitle"
                  value={formData.heroSubtitle}
                  onChange={(e) => handleInputChange('heroSubtitle', e.target.value)}
                  placeholder="Laporkan dugaan pelanggaran..."
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="footerText">Teks Footer</Label>
                <Input
                  id="footerText"
                  value={formData.footerText}
                  onChange={(e) => handleInputChange('footerText', e.target.value)}
                  placeholder="Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Tegal"
                />
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button onClick={handleSave} disabled={saving} size="lg">
              <Save className="w-4 h-4 mr-2" />
              {saving ? 'Menyimpan...' : 'Simpan Pengaturan'}
            </Button>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}