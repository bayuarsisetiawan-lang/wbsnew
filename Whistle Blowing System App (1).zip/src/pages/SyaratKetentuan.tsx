export function SyaratKetentuan() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl text-gray-900 mb-6">Syarat & Ketentuan</h1>
          
          <div className="prose max-w-none space-y-6 text-gray-700">
            <section>
              <h2 className="text-2xl text-gray-900 mb-3">1. Ketentuan Umum</h2>
              <p className="leading-relaxed mb-3">
                Dengan menggunakan layanan Whistle Blowing System (WBS) ini, Anda dianggap telah 
                membaca, memahami, dan menyetujui seluruh syarat dan ketentuan yang berlaku.
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>WBS adalah sarana untuk melaporkan dugaan pelanggaran yang terjadi di lingkungan organisasi</li>
                <li>Pelapor bukan merupakan bagian dari pelaku kejahatan yang dilaporkan</li>
                <li>Laporan harus berdasarkan itikad baik dan didukung oleh informasi atau bukti yang memadai</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl text-gray-900 mb-3">2. Kriteria Laporan</h2>
              <p className="leading-relaxed mb-3">
                Laporan yang dapat diterima melalui WBS harus memenuhi kriteria berikut:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Mengandung informasi yang jelas dan spesifik (5W1H: What, Who, Where, When, Why, How)</li>
                <li>Terkait dengan dugaan pelanggaran yang masuk dalam kategori WBS</li>
                <li>Bukan merupakan pengaduan pribadi, perselisihan internal, atau perbedaan pendapat</li>
                <li>Bukan laporan yang sedang dalam proses hukum atau telah diputus oleh pengadilan</li>
                <li>Didukung oleh bukti awal yang cukup (dokumen, foto, atau informasi pendukung lainnya)</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl text-gray-900 mb-3">3. Hak dan Kewajiban Pelapor</h2>
              <div className="mb-4">
                <h3 className="text-xl text-gray-900 mb-2">Hak Pelapor:</h3>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Mendapatkan perlindungan kerahasiaan identitas</li>
                  <li>Mendapatkan nomor tiket untuk memantau perkembangan laporan</li>
                  <li>Mendapatkan perlindungan dari ancaman, intimidasi, atau tindakan balasan</li>
                  <li>Mendapatkan informasi tentang tindak lanjut laporan (sesuai ketentuan)</li>
                </ul>
              </div>
              <div>
                <h3 className="text-xl text-gray-900 mb-2">Kewajiban Pelapor:</h3>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Memberikan informasi yang benar, akurat, dan dapat dipertanggungjawabkan</li>
                  <li>Menyampaikan laporan dengan itikad baik tanpa maksud mencemarkan nama baik</li>
                  <li>Bersedia memberikan informasi tambahan jika diperlukan</li>
                  <li>Tidak menyalahgunakan sistem untuk kepentingan pribadi</li>
                  <li>Menjaga kerahasiaan proses penanganan laporan</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl text-gray-900 mb-3">4. Kerahasiaan dan Perlindungan Data</h2>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Identitas pelapor dijamin kerahasiaannya dan hanya dapat diakses oleh pihak berwenang</li>
                <li>Data dan informasi yang diberikan akan digunakan semata-mata untuk kepentingan proses penanganan laporan</li>
                <li>Organisasi tidak akan memberikan informasi pelapor kepada pihak ketiga tanpa persetujuan, kecuali diwajibkan oleh hukum</li>
                <li>Pelapor dapat memilih untuk melaporkan secara anonim</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl text-gray-900 mb-3">5. Proses Penanganan Laporan</h2>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Setiap laporan yang masuk akan dilakukan verifikasi dan analisis awal</li>
                <li>Laporan yang memenuhi kriteria akan ditindaklanjuti sesuai prosedur</li>
                <li>Standar waktu respon awal adalah 7 hari kerja</li>
                <li>Pelapor dapat memantau status laporan melalui nomor tiket</li>
                <li>Organisasi berhak menolak laporan yang tidak memenuhi kriteria atau tidak didukung bukti</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl text-gray-900 mb-3">6. Sanksi</h2>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Pelapor yang dengan sengaja membuat laporan palsu atau fitnah dapat dikenakan sanksi hukum</li>
                <li>Laporan yang mengandung berita bohong atau tidak berdasar dapat ditindak sesuai peraturan perundang-undangan</li>
                <li>Penyalahgunaan sistem WBS akan ditindak tegas</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl text-gray-900 mb-3">7. Batasan Tanggung Jawab</h2>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Organisasi tidak bertanggung jawab atas kerugian yang timbul akibat laporan yang tidak benar</li>
                <li>Organisasi berhak menghentikan atau menunda proses penanganan jika ditemukan informasi yang tidak valid</li>
                <li>Keputusan akhir mengenai tindak lanjut laporan sepenuhnya menjadi wewenang organisasi</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl text-gray-900 mb-3">8. Perubahan Syarat dan Ketentuan</h2>
              <p className="leading-relaxed">
                Organisasi berhak untuk mengubah atau memperbarui syarat dan ketentuan ini sewaktu-waktu. 
                Perubahan akan diberitahukan melalui sistem dan dianggap berlaku sejak tanggal publikasi.
              </p>
            </section>

            <section>
              <h2 className="text-2xl text-gray-900 mb-3">9. Hukum yang Berlaku</h2>
              <p className="leading-relaxed">
                Syarat dan ketentuan ini tunduk pada hukum Republik Indonesia. Setiap perselisihan yang 
                timbul akan diselesaikan sesuai dengan peraturan perundang-undangan yang berlaku.
              </p>
            </section>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mt-8">
              <h3 className="text-xl text-gray-900 mb-3">Pernyataan Persetujuan</h3>
              <p className="text-gray-700">
                Dengan mengirimkan laporan melalui sistem WBS ini, Anda menyatakan bahwa:
              </p>
              <ul className="list-disc list-inside space-y-2 ml-4 mt-3 text-gray-700">
                <li>Anda telah membaca dan memahami seluruh syarat dan ketentuan yang berlaku</li>
                <li>Anda menyetujui untuk terikat dengan syarat dan ketentuan tersebut</li>
                <li>Informasi yang Anda berikan adalah benar dan dapat dipertanggungjawabkan</li>
                <li>Anda melaporkan dengan itikad baik untuk kepentingan organisasi dan masyarakat</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}