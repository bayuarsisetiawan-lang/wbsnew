import { Link } from 'react-router-dom';
import { Shield, Eye, Lock, FileText, Search, CheckCircle } from 'lucide-react';
import { useSettings } from '../utils/settings';

export function Home() {
  const { settings } = useSettings();

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl mb-6">
              {settings.heroTitle}
            </h1>
            <p className="text-xl mb-8 max-w-3xl mx-auto opacity-90">
              {settings.heroSubtitle}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/buat-aduan"
                className="bg-white text-blue-600 px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors"
              >
                Buat Aduan
              </Link>
              <Link
                to="/pantau-aduan"
                className="bg-blue-700 text-white px-8 py-3 rounded-lg hover:bg-blue-800 transition-colors border border-white"
              >
                Pantau Aduan
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* What is WBS */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl text-gray-900 mb-4">Apa itu Whistle Blowing System?</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              WBS adalah mekanisme penyampaian pengaduan dugaan tindak pidana tertentu yang telah terjadi
              atau akan terjadi yang melibatkan pegawai dan orang lain yang dilakukan dalam organisasi,
              dimana pelapor bukan merupakan bagian dari pelaku kejahatan yang dilaporkannya.
            </p>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div className="text-center p-6">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl text-gray-900 mb-2">Kerahasiaan Terjamin</h3>
              <p className="text-gray-600">
                Identitas pelapor dijamin kerahasiaannya dan dilindungi sesuai peraturan perundang-undangan
              </p>
            </div>

            <div className="text-center p-6">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Eye className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl text-gray-900 mb-2">Transparan</h3>
              <p className="text-gray-600">
                Pantau status pengaduan Anda secara real-time melalui nomor tiket yang diberikan
              </p>
            </div>

            <div className="text-center p-6">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="text-xl text-gray-900 mb-2">Aman</h3>
              <p className="text-gray-600">
                Data pengaduan tersimpan dengan sistem keamanan tinggi dan hanya dapat diakses oleh pihak berwenang
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5W1H Criteria */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl text-gray-900 mb-4">Kriteria Pengaduan</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Pastikan laporan Anda memuat informasi sesuai prinsip 5W1H untuk mempermudah proses verifikasi
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="text-blue-600 mb-2">WHAT</div>
              <p className="text-gray-700">
                Apa yang dilaporkan? Jelaskan permasalahan atau pelanggaran yang terjadi
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="text-blue-600 mb-2">WHO</div>
              <p className="text-gray-700">
                Siapa yang melakukan? Identitas pelaku atau pihak yang terlibat
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="text-blue-600 mb-2">WHERE</div>
              <p className="text-gray-700">
                Di mana kejadian terjadi? Lokasi atau tempat terjadinya pelanggaran
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="text-blue-600 mb-2">WHEN</div>
              <p className="text-gray-700">
                Kapan kejadian terjadi? Waktu atau periode terjadinya pelanggaran
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="text-blue-600 mb-2">WHY</div>
              <p className="text-gray-700">
                Mengapa hal tersebut terjadi? Latar belakang atau motif jika diketahui
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="text-blue-600 mb-2">HOW</div>
              <p className="text-gray-700">
                Bagaimana cara kejadian berlangsung? Kronologi atau modus operandi
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How to Report */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl text-gray-900 mb-4">Cara Melaporkan</h2>
            <p className="text-lg text-gray-600">
              Proses pelaporan yang mudah dan cepat
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-blue-600 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="h-6 w-6" />
              </div>
              <h3 className="text-lg text-gray-900 mb-2">1. Isi Formulir</h3>
              <p className="text-gray-600">
                Lengkapi formulir pengaduan dengan informasi yang jelas dan detail
              </p>
            </div>

            <div className="text-center">
              <div className="bg-blue-600 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-6 w-6" />
              </div>
              <h3 className="text-lg text-gray-900 mb-2">2. Kirim Laporan</h3>
              <p className="text-gray-600">
                Submit pengaduan Anda dan dapatkan nomor tiket
              </p>
            </div>

            <div className="text-center">
              <div className="bg-blue-600 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-6 w-6" />
              </div>
              <h3 className="text-lg text-gray-900 mb-2">3. Pantau Status</h3>
              <p className="text-gray-600">
                Gunakan nomor tiket untuk memantau perkembangan laporan
              </p>
            </div>

            <div className="text-center">
              <div className="bg-blue-600 text-white w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-6 w-6" />
              </div>
              <h3 className="text-lg text-gray-900 mb-2">4. Tindak Lanjut</h3>
              <p className="text-gray-600">
                Tim akan memverifikasi dan menindaklanjuti laporan Anda
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl mb-4">Siap Melaporkan?</h2>
          <p className="text-xl mb-8 opacity-90">
            Laporkan dugaan pelanggaran sekarang juga. Identitas Anda akan dijaga kerahasiaannya.
          </p>
          <Link
            to="/buat-aduan"
            className="inline-block bg-white text-blue-600 px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors"
          >
            Buat Aduan Sekarang
          </Link>
        </div>
      </section>
    </div>
  );
}