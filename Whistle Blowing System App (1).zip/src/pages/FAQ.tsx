import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface FAQItem {
  question: string;
  answer: string;
}

const faqs: FAQItem[] = [
  {
    question: 'Apa itu Whistle Blowing System (WBS)?',
    answer: 'WBS adalah sistem pelaporan pelanggaran yang merupakan sarana penyampaian pengaduan dugaan tindak pidana tertentu yang telah terjadi atau akan terjadi yang melibatkan pegawai dan orang lain yang dilakukan dalam organisasi, dimana pelapor bukan merupakan bagian dari pelaku kejahatan yang dilaporkannya.',
  },
  {
    question: 'Siapa yang bisa menggunakan WBS?',
    answer: 'WBS dapat digunakan oleh siapa saja, baik pegawai internal maupun masyarakat umum yang mengetahui atau menjadi korban dari dugaan pelanggaran yang terjadi di lingkungan organisasi.',
  },
  {
    question: 'Apakah identitas saya akan dirahasiakan?',
    answer: 'Ya, identitas pelapor dijamin kerahasiaannya sesuai dengan peraturan perundang-undangan yang berlaku. Anda juga dapat melaporkan secara anonim tanpa mencantumkan identitas.',
  },
  {
    question: 'Apa saja yang bisa dilaporkan melalui WBS?',
    answer: 'WBS menerima laporan terkait dugaan korupsi, penyalahgunaan wewenang, pelanggaran disiplin, pelanggaran kode etik, diskriminasi, fraud, dan pelanggaran lainnya yang merugikan organisasi atau masyarakat.',
  },
  {
    question: 'Bagaimana cara membuat laporan?',
    answer: 'Anda dapat membuat laporan dengan mengklik menu "Buat Aduan", kemudian mengisi formulir yang disediakan. Pastikan informasi yang Anda berikan lengkap dan jelas sesuai prinsip 5W1H (What, Who, Where, When, Why, How).',
  },
  {
    question: 'Apakah saya perlu mendaftar atau login untuk membuat laporan?',
    answer: 'Tidak, Anda dapat membuat laporan tanpa perlu mendaftar atau login. Namun, Anda akan mendapatkan nomor tiket untuk memantau status laporan Anda.',
  },
  {
    question: 'Bagaimana cara memantau status laporan saya?',
    answer: 'Setelah mengirim laporan, Anda akan mendapatkan nomor tiket. Gunakan nomor tiket tersebut di menu "Pantau Aduan" untuk melihat perkembangan laporan Anda.',
  },
  {
    question: 'Berapa lama waktu yang diperlukan untuk menindaklanjuti laporan?',
    answer: 'Standar waktu respon awal adalah 7 hari kerja sejak laporan diterima. Namun, waktu penyelesaian dapat bervariasi tergantung kompleksitas kasus dan proses verifikasi yang diperlukan.',
  },
  {
    question: 'Apa saja bukti yang dapat saya lampirkan?',
    answer: 'Anda dapat melampirkan file berupa gambar (JPG, PNG) atau dokumen (PDF) dengan ukuran maksimal 5MB per file. Bukti yang dilampirkan dapat berupa foto, dokumen, atau file pendukung lainnya.',
  },
  {
    question: 'Apakah ada sanksi jika laporan yang saya buat tidak benar?',
    answer: 'Laporan yang terbukti mengandung fitnah atau berita bohong dapat dikenakan sanksi sesuai peraturan perundang-undangan yang berlaku. Oleh karena itu, pastikan laporan Anda berdasarkan fakta dan bukti yang valid.',
  },
  {
    question: 'Bagaimana jika saya memiliki informasi tambahan setelah membuat laporan?',
    answer: 'Anda dapat menghubungi tim WBS melalui kontak yang tersedia dengan menyertakan nomor tiket laporan Anda untuk menyampaikan informasi tambahan.',
  },
  {
    question: 'Apakah saya akan mendapat perlindungan setelah membuat laporan?',
    answer: 'Ya, pelapor yang beritikad baik akan mendapatkan perlindungan sesuai dengan UU No. 13 Tahun 2006 tentang Perlindungan Saksi dan Korban, termasuk perlindungan dari ancaman atau intimidasi.',
  },
  {
    question: 'Apa yang terjadi setelah saya mengirim laporan?',
    answer: 'Setelah laporan diterima, tim akan melakukan verifikasi dan analisis awal. Jika laporan memenuhi kriteria, akan dilakukan investigasi lebih lanjut. Anda dapat memantau perkembangannya melalui nomor tiket.',
  },
  {
    question: 'Apakah laporan saya akan ditanggapi?',
    answer: 'Setiap laporan yang masuk akan ditinjau dan ditanggapi sesuai dengan prosedur yang berlaku. Laporan yang memenuhi kriteria dan didukung bukti yang cukup akan ditindaklanjuti.',
  },
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl text-gray-900 mb-6">Frequently Asked Questions (FAQ)</h1>
          
          <p className="text-gray-600 mb-8">
            Temukan jawaban atas pertanyaan yang sering diajukan seputar Whistle Blowing System
          </p>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="border border-gray-200 rounded-lg overflow-hidden"
              >
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full flex items-center justify-between p-4 text-left hover:bg-gray-50 transition-colors"
                >
                  <span className="text-gray-900 pr-4">{faq.question}</span>
                  {openIndex === index ? (
                    <ChevronUp className="h-5 w-5 text-gray-500 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-500 flex-shrink-0" />
                  )}
                </button>
                {openIndex === index && (
                  <div className="px-4 pb-4 text-gray-700 bg-gray-50">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="text-lg text-gray-900 mb-2">Masih ada pertanyaan?</h3>
            <p className="text-gray-700 mb-4">
              Jika Anda memiliki pertanyaan lain yang tidak tercantum di atas, silakan hubungi kami melalui:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li>Email: wbs@instansi.go.id</li>
              <li>Telepon: (021) 1234-5678</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}