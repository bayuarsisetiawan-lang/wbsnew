import { Shield, Users, FileText, Lock, Eye, Scale } from 'lucide-react';

export function TentangWBS() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl text-gray-900 mb-6">Tentang Whistle Blowing System</h1>
          
          <div className="prose max-w-none">
            <section className="mb-8">
              <h2 className="text-2xl text-gray-900 mb-4">Apa itu WBS?</h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Whistle Blowing System (WBS) adalah sistem pelaporan pelanggaran (whistleblowing) 
                yang merupakan sarana penyampaian pengaduan dugaan tindak pidana tertentu yang telah 
                terjadi atau akan terjadi yang melibatkan pegawai dan orang lain yang dilakukan dalam 
                organisasi, dimana pelapor bukan merupakan bagian dari pelaku kejahatan yang dilaporkannya.
              </p>
              <p className="text-gray-700 leading-relaxed">
                WBS ini dibuat sebagai bentuk komitmen untuk menciptakan tata kelola yang bersih, 
                transparan, dan akuntabel serta bebas dari praktik Korupsi, Kolusi, dan Nepotisme (KKN).
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-gray-900 mb-4">Tujuan WBS</h2>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start space-x-3">
                  <div className="bg-blue-100 p-2 rounded-full flex-shrink-0">
                    <Shield className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <strong>Pencegahan Fraud:</strong> Mencegah terjadinya tindakan fraud, korupsi, dan 
                    penyalahgunaan wewenang di lingkungan organisasi
                  </div>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="bg-green-100 p-2 rounded-full flex-shrink-0">
                    <Users className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <strong>Partisipasi Publik:</strong> Memberikan sarana bagi masyarakat untuk melaporkan 
                    dugaan pelanggaran secara aman dan terjamin
                  </div>
                </li>
                <li className="flex items-start space-x-3">
                  <div className="bg-purple-100 p-2 rounded-full flex-shrink-0">
                    <FileText className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <strong>Transparansi:</strong> Meningkatkan transparansi dan akuntabilitas dalam 
                    pengelolaan organisasi
                  </div>
                </li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-gray-900 mb-4">Jaminan Perlindungan</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <Lock className="h-5 w-5 text-blue-600" />
                    <h3 className="text-lg text-gray-900">Kerahasiaan</h3>
                  </div>
                  <p className="text-gray-700 text-sm">
                    Identitas pelapor dijamin kerahasiaannya dan tidak akan dipublikasikan
                  </p>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <Shield className="h-5 w-5 text-green-600" />
                    <h3 className="text-lg text-gray-900">Perlindungan</h3>
                  </div>
                  <p className="text-gray-700 text-sm">
                    Pelapor dilindungi dari segala bentuk ancaman atau intimidasi
                  </p>
                </div>
                
                <div className="bg-purple-50 p-4 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <Eye className="h-5 w-5 text-purple-600" />
                    <h3 className="text-lg text-gray-900">Transparansi Proses</h3>
                  </div>
                  <p className="text-gray-700 text-sm">
                    Pelapor dapat memantau perkembangan laporan melalui nomor tiket
                  </p>
                </div>
                
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <div className="flex items-center space-x-2 mb-2">
                    <Scale className="h-5 w-5 text-yellow-600" />
                    <h3 className="text-lg text-gray-900">Profesional</h3>
                  </div>
                  <p className="text-gray-700 text-sm">
                    Laporan ditangani secara profesional dan sesuai prosedur
                  </p>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-gray-900 mb-4">Kategori Pengaduan</h2>
              <p className="text-gray-700 mb-4">
                WBS menerima pengaduan terkait dugaan pelanggaran berikut:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4">
                <li>Tindakan korupsi, gratifikasi, atau penyalahgunaan dana</li>
                <li>Penyalahgunaan jabatan atau kewenangan</li>
                <li>Pelanggaran disiplin pegawai atau aturan internal</li>
                <li>Pelanggaran kode etik dan norma perilaku</li>
                <li>Tindakan diskriminasi atau pelecehan</li>
                <li>Penipuan atau kecurangan dalam proses kerja</li>
                <li>Pelanggaran lainnya yang merugikan organisasi atau masyarakat</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl text-gray-900 mb-4">Dasar Hukum</h2>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4">
                <li>Undang-Undang Nomor 31 Tahun 1999 tentang Pemberantasan Tindak Pidana Korupsi</li>
                <li>Undang-Undang Nomor 20 Tahun 2001 tentang Perubahan atas Undang-Undang Nomor 31 Tahun 1999</li>
                <li>Undang-Undang Nomor 13 Tahun 2006 tentang Perlindungan Saksi dan Korban</li>
                <li>Peraturan Pemerintah dan peraturan internal terkait</li>
              </ul>
            </section>

            <section>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 className="text-xl text-gray-900 mb-3">Komitmen Kami</h3>
                <p className="text-gray-700">
                  Kami berkomitmen untuk menindaklanjuti setiap laporan yang masuk secara profesional, 
                  objektif, dan sesuai dengan prosedur yang berlaku. Setiap laporan akan ditangani dengan 
                  serius dan identitas pelapor akan dijaga kerahasiaannya.
                </p>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}