import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertCircle, Upload, X, CheckCircle } from 'lucide-react';
import { getCategories, createReport, type Category } from '../utils/dataStore';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';

export function BuatAduan() {
  const navigate = useNavigate();
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [ticketNumber, setTicketNumber] = useState('');
  const [files, setFiles] = useState<File[]>([]);

  const [formData, setFormData] = useState({
    reporterAnonymous: false,
    reporterName: '',
    reporterContact: '',
    reportedEntity: '',
    categoryId: '',
    location: '',
    incidentDate: '',
    description: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    loadCategories();
  }, []);

  async function loadCategories() {
    const data = await getCategories();
    setCategories(data);
  }

  function handleInputChange(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));

    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  }

  function handleSelectChange(name: string, value: string) {
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));

    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  }

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const selectedFiles = Array.from(e.target.files || []);
    
    const maxSize = 5 * 1024 * 1024;
    const validFiles = selectedFiles.filter(file => {
      if (file.size > maxSize) {
        alert(`File ${file.name} terlalu besar. Maksimal 5MB per file.`);
        return false;
      }
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
      if (!validTypes.includes(file.type)) {
        alert(`File ${file.name} tidak valid. Hanya menerima JPG, PNG, dan PDF.`);
        return false;
      }
      return true;
    });

    setFiles(prev => [...prev, ...validFiles]);
  }

  function removeFile(index: number) {
    setFiles(prev => prev.filter((_, i) => i !== index));
  }

  function validateForm(): boolean {
    const newErrors: Record<string, string> = {};

    if (!formData.reporterAnonymous) {
      if (!formData.reporterName.trim()) {
        newErrors.reporterName = 'Nama pelapor wajib diisi';
      }
      if (!formData.reporterContact.trim()) {
        newErrors.reporterContact = 'Kontak pelapor wajib diisi';
      }
    }

    if (!formData.categoryId) {
      newErrors.categoryId = 'Kategori wajib dipilih';
    }

    if (!formData.description.trim() || formData.description.trim().length < 50) {
      newErrors.description = 'Deskripsi minimal 50 karakter';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      const report = await createReport({
        reporter_name: formData.reporterAnonymous ? null : formData.reporterName,
        reporter_contact: formData.reporterAnonymous ? null : formData.reporterContact,
        reporter_anonymous: formData.reporterAnonymous,
        reported_entity: formData.reportedEntity || null,
        category_id: formData.categoryId,
        description: formData.description,
        location: formData.location || null,
        incident_date: formData.incidentDate || null,
      });

      setTicketNumber(report.ticket_number);
      setSuccess(true);

      // Reset form
      setFormData({
        reporterAnonymous: false,
        reporterName: '',
        reporterContact: '',
        reportedEntity: '',
        categoryId: '',
        location: '',
        incidentDate: '',
        description: '',
      });
      setFiles([]);

    } catch (error) {
      console.error('Error submitting report:', error);
      alert('Terjadi kesalahan saat mengirim laporan. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-lg shadow-lg p-8 text-center">
            <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="h-10 w-10 text-green-600" />
            </div>
            <h2 className="text-gray-900 mb-4">Laporan Berhasil Dikirim!</h2>
            <p className="text-gray-600 mb-6">
              Terima kasih telah melaporkan. Nomor tiket Anda adalah:
            </p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <div className="text-blue-600 mb-1">Nomor Tiket</div>
              <div className="text-blue-900">{ticketNumber}</div>
            </div>
            <p className="text-gray-600 mb-8">
              Simpan nomor tiket ini untuk memantau status laporan Anda. Kami akan memproses laporan
              dalam waktu 7 hari kerja.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => navigate('/pantau-aduan')}
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Pantau Status
              </button>
              <button
                onClick={() => {
                  setSuccess(false);
                  setTicketNumber('');
                }}
                className="bg-white text-gray-700 px-6 py-3 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors"
              >
                Buat Laporan Baru
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <div className="flex items-center space-x-3 mb-6">
            <AlertCircle className="h-8 w-8 text-blue-600" />
            <h1 className="text-gray-900">Buat Aduan</h1>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
            <div className="flex items-start space-x-3">
              <AlertCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-blue-800">
                <p className="mb-2">
                  Pastikan laporan Anda memuat informasi yang lengkap dan jelas sesuai prinsip 5W1H
                  (What, Who, Where, When, Why, How) untuk mempermudah proses verifikasi.
                </p>
                <p>
                  Identitas Anda akan dijaga kerahasiaannya sesuai dengan peraturan perundang-undangan yang berlaku.
                </p>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-lg">
              <input
                type="checkbox"
                id="reporterAnonymous"
                name="reporterAnonymous"
                checked={formData.reporterAnonymous}
                onChange={handleInputChange}
                className="h-5 w-5 text-blue-600 rounded"
              />
              <label htmlFor="reporterAnonymous" className="text-gray-700 cursor-pointer">
                Laporkan secara anonim (identitas tidak perlu dicantumkan)
              </label>
            </div>

            {!formData.reporterAnonymous && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-gray-700 mb-2">
                    Nama Pelapor <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="reporterName"
                    value={formData.reporterName}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Nama lengkap atau nama samaran"
                  />
                  {errors.reporterName && (
                    <p className="text-red-500 mt-1">{errors.reporterName}</p>
                  )}
                </div>

                <div>
                  <label className="block text-gray-700 mb-2">
                    Kontak (Email/Telepon) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="reporterContact"
                    value={formData.reporterContact}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="email@example.com atau 08123456789"
                  />
                  {errors.reporterContact && (
                    <p className="text-red-500 mt-1">{errors.reporterContact}</p>
                  )}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-gray-700 mb-2">
                  Kategori Pengaduan <span className="text-red-500">*</span>
                </label>
                <Select
                  value={formData.categoryId}
                  onValueChange={(value) => handleSelectChange('categoryId', value)}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Pilih kategori pengaduan" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.categoryId && (
                  <p className="text-red-500 mt-1">{errors.categoryId}</p>
                )}
              </div>

              <div>
                <label className="block text-gray-700 mb-2">
                  Identitas Terlapor (Opsional)
                </label>
                <input
                  type="text"
                  name="reportedEntity"
                  value={formData.reportedEntity}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Nama orang/unit/instansi"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-gray-700 mb-2">
                  Lokasi Kejadian (Opsional)
                </label>
                <input
                  type="text"
                  name="location"
                  value={formData.location}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Kota, provinsi, atau tempat kejadian"
                />
              </div>

              <div>
                <label className="block text-gray-700 mb-2">
                  Waktu Kejadian (Opsional)
                </label>
                <input
                  type="date"
                  name="incidentDate"
                  value={formData.incidentDate}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">
                Deskripsi Kronologis Kejadian <span className="text-red-500">*</span>
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                rows={8}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Jelaskan secara detail kronologi kejadian sesuai prinsip 5W1H (What, Who, Where, When, Why, How)..."
              />
              <div className="flex justify-between items-center mt-1">
                {errors.description ? (
                  <p className="text-red-500">{errors.description}</p>
                ) : (
                  <p className="text-gray-500">Minimal 50 karakter</p>
                )}
                <p className="text-gray-500">{formData.description.length} karakter</p>
              </div>
            </div>

            <div>
              <label className="block text-gray-700 mb-2">
                Upload Bukti Pendukung (Opsional)
              </label>
              <p className="text-gray-600 mb-3">
                Format: JPG, PNG, PDF. Maksimal 5MB per file.
              </p>
              
              <label className="flex items-center justify-center w-full px-4 py-6 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-colors">
                <div className="text-center">
                  <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                  <span className="text-gray-600">Klik untuk upload file</span>
                </div>
                <input
                  type="file"
                  multiple
                  accept="image/jpeg,image/jpg,image/png,application/pdf"
                  onChange={handleFileChange}
                  className="hidden"
                />
              </label>

              {files.length > 0 && (
                <div className="mt-4 space-y-2">
                  {files.map((file, index) => (
                    <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="text-gray-600">{file.name}</div>
                        <div className="text-gray-500">
                          ({(file.size / 1024 / 1024).toFixed(2)} MB)
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFile(index)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <X className="h-5 w-5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex gap-4">
              <button
                type="submit"
                disabled={loading}
                className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                {loading ? 'Mengirim laporan...' : 'Kirim Laporan'}
              </button>
              <button
                type="button"
                onClick={() => navigate('/')}
                className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Batal
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}