import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, Clock, CheckCircle, TrendingUp, LogOut, RefreshCw } from 'lucide-react';
import { getCurrentUser, getUserRole, signOut } from '../../utils/auth';
import { getReports, getReportStats, getCategories, type Report, type Category } from '../../utils/dataStore';
import { useSettings } from '../../utils/settings';

export function DisplayDashboard() {
  const navigate = useNavigate();
  const { settings } = useSettings();
  const [stats, setStats] = useState({
    total: 0,
    baru: 0,
    diproses: 0,
    selesai: 0,
  });
  const [recentReports, setRecentReports] = useState<Report[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();
    loadData();
    
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, []);

  async function checkAuth() {
    try {
      const user = await getCurrentUser();
      const role = getUserRole(user);
      
      if (role !== 'display') {
        navigate('/login');
      }
    } catch (error) {
      navigate('/login');
    }
  }

  async function loadData() {
    try {
      const [statsData, reportsData, categoriesData] = await Promise.all([
        getReportStats(),
        getReports({ limit: 5 }),
        getCategories(),
      ]);
      
      setStats(statsData);
      setRecentReports(reportsData);
      setCategories(categoriesData);
      setLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  }

  async function handleSignOut() {
    await signOut();
    navigate('/login');
  }

  function formatDate(dateString: string) {
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  }

  function getStatusBadge(status: string) {
    switch (status) {
      case 'baru':
        return <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full">Baru</span>;
      case 'diproses':
        return <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full">Diproses</span>;
      case 'selesai':
        return <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full">Selesai</span>;
      case 'ditolak':
        return <span className="px-3 py-1 bg-red-100 text-red-800 rounded-full">Ditolak</span>;
      default:
        return <span className="px-3 py-1 bg-gray-100 text-gray-800 rounded-full">Unknown</span>;
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {settings.logoUrl && (
                <img src={settings.logoUrl} alt="Logo" className="h-16 w-16 object-contain" />
              )}
              <div>
                <h1 className="text-gray-900">
                  {settings.institutionName || 'Whistle Blowing System'}
                </h1>
                <p className="text-gray-600">Dashboard Monitoring Pengaduan</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <button
                onClick={loadData}
                disabled={loading}
                className="p-2 text-gray-600 hover:text-gray-900 disabled:opacity-50"
                title="Refresh"
              >
                <RefreshCw className={`h-6 w-6 ${loading ? 'animate-spin' : ''}`} />
              </button>
              <button
                onClick={handleSignOut}
                className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                <LogOut className="h-5 w-5" />
                <span>Keluar</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-white rounded-xl shadow-lg p-8 transform hover:scale-105 transition-transform">
            <div className="flex items-center justify-between mb-4">
              <div className="text-gray-600">Total Laporan</div>
              <TrendingUp className="h-8 w-8 text-blue-500" />
            </div>
            <div className="text-blue-600">{stats.total}</div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 transform hover:scale-105 transition-transform">
            <div className="flex items-center justify-between mb-4">
              <div className="text-gray-600">Laporan Baru</div>
              <FileText className="h-8 w-8 text-indigo-500" />
            </div>
            <div className="text-indigo-600">{stats.baru}</div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 transform hover:scale-105 transition-transform">
            <div className="flex items-center justify-between mb-4">
              <div className="text-gray-600">Sedang Diproses</div>
              <Clock className="h-8 w-8 text-yellow-500" />
            </div>
            <div className="text-yellow-600">{stats.diproses}</div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 transform hover:scale-105 transition-transform">
            <div className="flex items-center justify-between mb-4">
              <div className="text-gray-600">Selesai</div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
            <div className="text-green-600">{stats.selesai}</div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="px-8 py-6 border-b">
            <h2 className="text-gray-900">Laporan Terbaru</h2>
          </div>
          <div className="overflow-x-auto">
            {recentReports.length > 0 ? (
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-gray-600">Nomor Tiket</th>
                    <th className="px-6 py-4 text-left text-gray-600">Kategori</th>
                    <th className="px-6 py-4 text-left text-gray-600">Status</th>
                    <th className="px-6 py-4 text-left text-gray-600">Tanggal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {recentReports.map((report) => (
                    <tr key={report.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 text-gray-900">{report.ticket_number}</td>
                      <td className="px-6 py-4 text-gray-600">{report.category_name || '-'}</td>
                      <td className="px-6 py-4">{getStatusBadge(report.status)}</td>
                      <td className="px-6 py-4 text-gray-600">{formatDate(report.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="text-center text-gray-500 py-12">
                Belum ada laporan
              </div>
            )}
          </div>
        </div>

        {settings.contactInfo && (
          <div className="mt-8 text-center text-gray-600">
            <p>{settings.contactInfo}</p>
          </div>
        )}
      </div>
    </div>
  );
}