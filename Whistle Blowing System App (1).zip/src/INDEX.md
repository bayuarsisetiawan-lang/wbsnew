# 📑 INDEX - Navigasi Cepat Dokumentasi WBS

> **Tidak tahu harus baca file mana? Lihat panduan di bawah!**

---

## 🎯 Pilih Sesuai Kebutuhan Anda:

### 1️⃣ Saya Baru Pertama Kali & Butuh Username/Password
→ **Baca:** [`USERNAME_PASSWORD.txt`](./USERNAME_PASSWORD.txt) (1 menit)  
→ **Atau:** [`INFO_LOGIN.txt`](./INFO_LOGIN.txt) (1 menit)  
→ **Kemudian:** [`MULAI_DI_SINI.md`](./MULAI_DI_SINI.md) (2 menit)

### 2️⃣ Saya Ingin Cepat Setup & Langsung Pakai
→ **Baca:** [`MULAI_DI_SINI.md`](./MULAI_DI_SINI.md) (2 menit) ⭐ **RECOMMENDED**  
→ **Praktek:** Buka `/setup`, isi form, submit!

### 3️⃣ Saya Punya Pertanyaan Spesifik
→ **Baca:** [`JAWABAN_SINGKAT.md`](./JAWABAN_SINGKAT.md) - FAQ dengan jawaban singkat  
→ **Atau:** [`DAFTAR_ISI.md`](./DAFTAR_ISI.md) - Index detail semua topik

### 4️⃣ Saya Developer/IT yang Butuh Info Teknis
→ **Baca:** [`QUICK_START.md`](./QUICK_START.md) - Technical quick reference  
→ **Atau:** [`README.md`](./README.md) - Overview & tech stack

### 5️⃣ Saya Ingin Tutorial Lengkap Semua Fitur
→ **Baca:** [`PANDUAN_PENGGUNAAN.md`](./PANDUAN_PENGGUNAAN.md) - Manual lengkap

### 6️⃣ Saya Butuh Info tentang Keamanan & Kredensial
→ **Baca:** [`KREDENSIAL_DEFAULT.md`](./KREDENSIAL_DEFAULT.md) - Panduan keamanan lengkap

---

## 📚 Semua File Dokumentasi (Berdasarkan Tipe)

### 🚀 Quick Start (Baca Ini Dulu!)

| File | Deskripsi | Estimasi Waktu |
|------|-----------|----------------|
| **[MULAI_DI_SINI.md](./MULAI_DI_SINI.md)** | ⭐ Panduan 3 langkah untuk pemula | 2 menit |
| **[USERNAME_PASSWORD.txt](./USERNAME_PASSWORD.txt)** | Username & password (format text) | 1 menit |
| **[INFO_LOGIN.txt](./INFO_LOGIN.txt)** | Info kredensial & login (format text) | 1 menit |
| **[JAWABAN_SINGKAT.md](./JAWABAN_SINGKAT.md)** | FAQ dengan jawaban super ringkas | 3 menit |

### 📖 Panduan Lengkap

| File | Deskripsi | Untuk Siapa |
|------|-----------|-------------|
| **[README.md](./README.md)** | Overview sistem & quick start | Semua user |
| **[PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md)** | Manual lengkap semua fitur | User yang ingin detail |
| **[KREDENSIAL_DEFAULT.md](./KREDENSIAL_DEFAULT.md)** | Panduan keamanan & setup admin | Admin & IT |
| **[QUICK_START.md](./QUICK_START.md)** | Technical quick reference | Developer/IT |

### 📑 Navigasi & Reference

| File | Deskripsi | Kegunaan |
|------|-----------|----------|
| **[DAFTAR_ISI.md](./DAFTAR_ISI.md)** | Index detail semua dokumentasi | Cari topik spesifik |
| **[INDEX.md](./INDEX.md)** | Navigasi cepat (file ini) | Tahu harus baca apa |

### 📝 Informasi Tambahan

| File | Deskripsi | Kapan Dibaca |
|------|-----------|--------------|
| **[CHANGELOG.md](./CHANGELOG.md)** | Riwayat perubahan sistem | Ingin tahu update terbaru |
| **[Attributions.md](./Attributions.md)** | Credits & acknowledgments | Info library & dependencies |

---

## ⚡ Flowchart: File Mana yang Harus Dibaca?

```
                    MULAI
                      |
                      v
          Sudah pernah setup sebelumnya?
                    /   \
                  Ya     Tidak
                  |        |
                  v        v
         Baca         Baca
         PANDUAN_     MULAI_DI_SINI.md
         PENGGUNAAN   USERNAME_PASSWORD.txt
         .md          INFO_LOGIN.txt
                      |
                      v
                   Setup Admin
                   di /setup
                      |
                      v
                   Login
                      |
                      v
              Gunakan Sistem!
```

---

## 🎯 Checklist Setup (Ikuti Urutan Ini)

### Fase 1: Persiapan
- [ ] Baca `MULAI_DI_SINI.md` atau `USERNAME_PASSWORD.txt`
- [ ] Pahami tidak ada default username/password
- [ ] Siapkan data admin (nama, email, password)

### Fase 2: Setup
- [ ] Buka aplikasi di browser
- [ ] Kunjungi `/setup`
- [ ] Isi formulir setup admin
- [ ] Submit dan tunggu redirect ke login

### Fase 3: Login Pertama
- [ ] Login dengan kredensial yang baru dibuat
- [ ] Verifikasi masuk ke dashboard admin
- [ ] Explore fitur-fitur yang tersedia

### Fase 4: Kustomisasi (Opsional)
- [ ] Upload logo di `/admin/settings`
- [ ] Ubah nama instansi
- [ ] Update informasi kontak
- [ ] Tambah kategori custom di `/admin/kategori`

### Fase 5: Operasional
- [ ] Buat user display jika perlu
- [ ] Share link website ke masyarakat
- [ ] Terima & kelola pengaduan
- [ ] Monitor statistik

---

## 🔍 Cari Berdasarkan Pertanyaan

### "Bagaimana cara login?"
→ [`USERNAME_PASSWORD.txt`](./USERNAME_PASSWORD.txt)  
→ [`INFO_LOGIN.txt`](./INFO_LOGIN.txt)

### "Apa username dan password default?"
→ [`USERNAME_PASSWORD.txt`](./USERNAME_PASSWORD.txt)  
→ [`JAWABAN_SINGKAT.md`](./JAWABAN_SINGKAT.md#username-dan-password-admin)

### "Bagaimana cara mulai dari awal?"
→ [`MULAI_DI_SINI.md`](./MULAI_DI_SINI.md)

### "Cara ubah logo?"
→ [`MULAI_DI_SINI.md`](./MULAI_DI_SINI.md#upload-logo-instansi)  
→ [`PANDUAN_PENGGUNAAN.md`](./PANDUAN_PENGGUNAAN.md#mengubah-logo--informasi)

### "Cara buat user display?"
→ [`KREDENSIAL_DEFAULT.md`](./KREDENSIAL_DEFAULT.md#membuat-user-display)  
→ [`JAWABAN_SINGKAT.md`](./JAWABAN_SINGKAT.md#bagaimana-buat-user-display)

### "Lupa password?"
→ [`KREDENSIAL_DEFAULT.md`](./KREDENSIAL_DEFAULT.md#lupa-password-admin)  
→ [`USERNAME_PASSWORD.txt`](./USERNAME_PASSWORD.txt)

### "Perlu setup database?"
→ [`README.md`](./README.md#langsung-pakai-dalam-2-menit-super-mudah)  
→ [`JAWABAN_SINGKAT.md`](./JAWABAN_SINGKAT.md#perlu-setup-database)

### "Info teknis untuk developer?"
→ [`QUICK_START.md`](./QUICK_START.md)

### "Tutorial lengkap semua fitur?"
→ [`PANDUAN_PENGGUNAAN.md`](./PANDUAN_PENGGUNAAN.md)

---

## 📞 Masih Bingung?

### Langkah 1: Baca file yang paling sederhana
→ [`USERNAME_PASSWORD.txt`](./USERNAME_PASSWORD.txt) (format text, paling simple)

### Langkah 2: Jika butuh lebih detail
→ [`MULAI_DI_SINI.md`](./MULAI_DI_SINI.md) (panduan 3 langkah)

### Langkah 3: Jika ada pertanyaan spesifik
→ [`JAWABAN_SINGKAT.md`](./JAWABAN_SINGKAT.md) (FAQ)

### Langkah 4: Jika ingin tutorial lengkap
→ [`PANDUAN_PENGGUNAAN.md`](./PANDUAN_PENGGUNAAN.md) (manual lengkap)

### Langkah 5: Hubungi Support
- Email: (sesuai instansi)
- Telepon: (sesuai instansi)
- Atau hubungi administrator sistem

---

## 💡 Tips Membaca Dokumentasi

### Untuk User Baru (Non-Teknis):
1. Mulai dari file `.txt` (paling simple)
2. Lanjut ke `MULAI_DI_SINI.md`
3. Skip file teknis seperti `QUICK_START.md`

### Untuk Developer/IT:
1. Mulai dari `QUICK_START.md`
2. Lihat `README.md` untuk overview
3. Detail di `PANDUAN_PENGGUNAAN.md` jika perlu

### Untuk Admin Sistem:
1. Baca `KREDENSIAL_DEFAULT.md` untuk keamanan
2. Baca `PANDUAN_PENGGUNAAN.md` untuk fitur lengkap
3. `QUICK_START.md` untuk referensi teknis

---

## 🎉 Selamat Menggunakan WBS!

**Rekomendasi terakhir:**  
Jika masih bingung, cukup baca **1 file saja** → [`MULAI_DI_SINI.md`](./MULAI_DI_SINI.md)

File itu berisi semua yang Anda butuhkan untuk setup dan mulai menggunakan sistem!

---

© 2025 Dinas PMPTSP Kabupaten Tegal  
Whistle Blowing System - Dokumentasi Lengkap
