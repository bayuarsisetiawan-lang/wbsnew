# ❓ Pertanyaan yang Sering Ditanyakan - Jawaban Singkat

## 🔐 USERNAME DAN PASSWORD ADMIN?

**TIDAK ADA DEFAULT!**

Anda harus membuat sendiri:
1. Buka `/setup`
2. Isi form
3. Submit

**Contoh:**
```
Email: admin@tegalkab.go.id
Password: admin123 (atau password lain yang aman)
```

---

## 🚀 BAGAIMANA CARA MULAI?

**3 Langkah:**
```
1. Buka /setup
2. Isi nama, email, password
3. Klik submit
```

**Selesai!** Login di `/login`

---

## 🔑 LUPA PASSWORD?

1. Buka Supabase Dashboard
2. Authentication → Users
3. Cari user Anda
4. Klik "..." → Reset Password
5. Set password baru

---

## 📱 HALAMAN PENTING APA SAJA?

**Untuk Masyarakat (Tanpa Login):**
- `/` - Beranda
- `/buat-aduan` - Buat pengaduan
- `/pantau-aduan` - Cek status

**Untuk Admin (Harus Login):**
- `/login` - Login
- `/admin/dashboard` - Dashboard
- `/admin/pengaduan` - Kelola pengaduan
- `/admin/kategori` - Kelola kategori
- `/admin/users` - Kelola users
- `/admin/settings` - Pengaturan

**Setup (Sekali Saja):**
- `/setup` - Buat admin pertama

---

## 🎨 BAGAIMANA UBAH LOGO?

1. Login sebagai admin
2. Buka `/admin/settings`
3. Klik "Pilih Logo"
4. Pilih file gambar (max 2MB)
5. Lihat preview
6. Klik "Simpan Pengaturan"

**Troubleshooting:**
- File terlalu besar? → Kompres dulu ke < 2MB
- Preview tidak muncul? → Coba file lain
- Error saat save? → Cek console browser (F12)

---

## 👥 BAGAIMANA BUAT USER DISPLAY?

1. Login sebagai admin
2. Buka `/admin/users`
3. Klik "Tambah User"
4. Pilih role "Display"
5. Isi data, submit

---

## ⚙️ PERLU SETUP DATABASE?

**TIDAK!**

Sistem otomatis siap pakai.
Data tersimpan di KV Store Supabase.

---

## 🔒 APAKAH DATA AMAN?

**YA!**

- Data terenkripsi
- Identitas pelapor dilindungi
- Hanya admin yang bisa akses
- Hosted di Supabase (certified)

---

## 📊 BAGAIMANA LIHAT STATISTIK?

Login admin → `/admin/dashboard`

Akan muncul:
- Total laporan
- Grafik status
- Laporan terbaru

---

## 📂 BAGAIMANA TAMBAH KATEGORI?

1. Login admin
2. Buka `/admin/kategori`
3. Klik "Tambah Kategori"
4. Isi nama & deskripsi
5. Submit

---

## 🎯 SIAPA BISA BUAT LAPORAN?

**SEMUA ORANG!**

- Tidak perlu login
- Bisa anonim
- Gratis
- 24/7

Cukup buka `/buat-aduan`

---

## 🔍 BAGAIMANA CEK STATUS LAPORAN?

1. Buka `/pantau-aduan`
2. Masukkan nomor tiket
3. Klik "Cari"

Nomor tiket didapat saat buat laporan.

---

## 📄 DOKUMEN APA YANG HARUS DIBACA?

**User Baru:**
→ `MULAI_DI_SINI.md`

**Developer:**
→ `QUICK_START.md`

**Detail Lengkap:**
→ `PANDUAN_PENGGUNAAN.md`

**Info Login:**
→ `INFO_LOGIN.txt`

---

## ❌ ERROR SAAT LOGIN?

**Cek:**
- Email benar?
- Password benar?
- Caps Lock off?
- Sudah buat admin?

**Solusi:**
- Coba ulang dengan teliti
- Reset password jika lupa
- Buat admin baru via `/setup` jika belum

---

## ❌ ERROR SAAT SIMPAN PENGATURAN?

**Error: "Sesi login telah berakhir"**
→ Logout dan login kembali

**Error: "Hanya admin yang dapat mengubah pengaturan"**
→ Pastikan Anda login sebagai admin (bukan display)

**Error: "Gagal menyimpan pengaturan"**
→ Cek console browser (F12) untuk detail error
→ Refresh halaman dan coba lagi
→ Logout dan login kembali

---

## 🔄 BAGAIMANA RESET SEMUA?

1. Buka Supabase Dashboard
2. Authentication → Users
3. Hapus semua users
4. Buka `/setup` lagi
5. Buat admin baru

---

## 💻 BISA AKSES DARI HP?

**YA!**

Sistem responsive, bisa diakses dari:
- Komputer
- Laptop
- Tablet
- Smartphone

---

## 🌐 LINK WEBSITE APA?

Tergantung deployment Anda.

**Contoh:**
- `https://wbs-tegalkab.vercel.app`
- `https://wbs.pmptsp.tegalkab.go.id`
- Atau domain custom Anda

---

## 📞 KONTAK SUPPORT?

- Email: (sesuai instansi Anda)
- Telepon: (sesuai instansi Anda)
- Atau hubungi admin sistem

---

## 🎯 CHECKLIST CEPAT

Setup Awal:
- [ ] Buka `/setup`
- [ ] Buat admin
- [ ] Login
- [ ] Upload logo (opsional)
- [ ] Selesai!

Operasional:
- [ ] Share link ke masyarakat
- [ ] Monitor pengaduan
- [ ] Update status
- [ ] Kelola kategori
- [ ] Manage users

---

## 📚 BUTUH INFO LEBIH DETAIL?

Lihat file:
- `DAFTAR_ISI.md` - Index semua dokumentasi
- `MULAI_DI_SINI.md` - Panduan 3 langkah
- `PANDUAN_PENGGUNAAN.md` - Tutorial lengkap

---

**🎉 Masih bingung? Baca file `MULAI_DI_SINI.md` - Dijamin paham dalam 2 menit!**

---

© 2025 Dinas PMPTSP Kabupaten Tegal
