# 🔐 Kredensial & Setup Admin

## ✅ Status: Belum Ada Default Admin

Aplikasi WBS ini **TIDAK MEMILIKI DEFAULT ADMIN** untuk alasan keamanan. Anda harus membuat admin pertama sendiri menggunakan salah satu cara di bawah.

---

## 🚀 Cara 1: Setup via Web (PALING MUDAH!) ⭐

### Langkah-langkah:

1. **Buka aplikasi** di browser
2. **Kunjungi**: `/setup`
3. **Isi formulir** dengan data admin Anda:

```
Nama Lengkap:     Administrator PMPTSP Kab. Tegal
Email:            admin@tegalkab.go.id
Password:         (password aman Anda, minimal 6 karakter)
Konfirmasi:       (ketik ulang password)
```

4. **Klik** "Buat Admin Pertama"
5. **Selesai!** Otomatis redirect ke halaman login
6. **Login** dengan kredensial yang baru dibuat

### ✨ Fitur Otomatis:
- ✅ Sistem otomatis cek apakah sudah ada admin
- ✅ Jika belum ada, redirect ke `/setup`
- ✅ Jika sudah ada, redirect ke `/login`
- ✅ Halaman setup otomatis disabled setelah admin dibuat

---

## 🔧 Cara 2: Setup via Supabase Dashboard (Manual)

Jika Anda lebih suka menggunakan Supabase Dashboard:

1. **Buka** https://supabase.com/dashboard
2. **Pilih** project Anda
3. **Masuk ke** Authentication → Users
4. **Klik** "Add User" → "Create New User"
5. **Isi data**:
   - Email: `admin@tegalkab.go.id`
   - Password: `(password aman Anda)`
   - Auto Confirm User: ✅ Yes
   - User Metadata:
     ```json
     {
       "name": "Administrator PMPTSP",
       "role": "admin"
     }
     ```
6. **Klik** "Create User"
7. **Login** di `/login` dengan kredensial tersebut

---

## 📝 Contoh Kredensial Admin

Berikut contoh kredensial yang bisa Anda gunakan:

### Untuk Development/Testing:
```
Email:    admin@tegalkab.go.id
Password: admin123
Nama:     Administrator Test
```

### Untuk Production (Gunakan yang kuat!):
```
Email:    admin@pmptsp.tegalkab.go.id
Password: Tegal@PMPTSP2025!
Nama:     Administrator PMPTSP Kab. Tegal
```

**⚠️ PENTING:** 
- Ganti password default segera setelah login pertama!
- Gunakan password yang kuat (minimal 8 karakter, kombinasi huruf besar, kecil, angka, simbol)
- Jangan bagikan kredensial ke orang yang tidak berwenang

---

## 👥 Membuat User Display

Setelah admin dibuat, Anda bisa membuat user display dari dashboard admin:

1. **Login** sebagai admin
2. **Masuk ke** `/admin/users`
3. **Klik** "Tambah User"
4. **Isi data**:
   ```
   Nama:     Display Monitor
   Email:    display@tegalkab.go.id
   Password: display123
   Role:     Display
   ```
5. **Klik** "Tambah"
6. User display bisa login di `/login` dan akses `/display/dashboard`

---

## 🔒 Keamanan

### Password Policy:
- ✅ Minimal 6 karakter (disarankan 12+ karakter)
- ✅ Kombinasi huruf besar dan kecil
- ✅ Minimal 1 angka
- ✅ Minimal 1 simbol khusus (@, !, #, $, dll)

### Best Practices:
- 🔐 Jangan gunakan password yang sama dengan akun lain
- 🔐 Ganti password secara berkala (3-6 bulan sekali)
- 🔐 Jangan simpan password di file text biasa
- 🔐 Gunakan password manager jika memungkinkan
- 🔐 Aktifkan 2FA jika tersedia (future feature)

---

## ❓ Troubleshooting

### "Admin sudah ada, gunakan halaman login"
- Admin sudah pernah dibuat sebelumnya
- Gunakan kredensial admin yang sudah ada
- Atau reset user di Supabase Dashboard jika lupa password

### "Email atau password salah"
- Cek kembali email dan password yang diinput
- Pastikan tidak ada spasi di awal/akhir
- Pastikan Caps Lock tidak aktif
- Coba reset password via Supabase Dashboard

### Lupa Password Admin
1. Buka Supabase Dashboard
2. Authentication → Users
3. Cari user admin
4. Klik "..." → "Reset Password"
5. Set password baru
6. Login dengan password baru

### Ingin Reset Semua (Fresh Start)
1. Buka Supabase Dashboard
2. Authentication → Users
3. Hapus semua users
4. Kembali ke aplikasi
5. Kunjungi `/setup` untuk buat admin baru

---

## 📞 Support

Jika mengalami kesulitan dalam setup admin:
1. Lihat console browser (F12) untuk error logs
2. Cek Supabase Dashboard untuk status users
3. Pastikan environment variables sudah di-set dengan benar
4. Hubungi administrator sistem jika masih bermasalah

---

**🎉 Selamat! Sistem WBS siap digunakan setelah admin pertama dibuat.**

---

© 2025 Dinas PMPTSP Kabupaten Tegal
