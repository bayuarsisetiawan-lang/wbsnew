# 🚀 QUICK DEPLOY - 5 LANGKAH SIMPLE (BUDGET 100RB)

## RINGKASAN SUPER CEPAT:

### 1️⃣ BUAT AKUN & UPLOAD CODE (15 menit)
```
GitHub.com → Sign up → Create repository → Upload all files
```

### 2️⃣ DEPLOY GRATIS (10 menit)
```
Netlify.com → Sign up with GitHub → New site from Git → Deploy
```

### 3️⃣ BELI DOMAIN (5 menit + Rp 50-80k)
```
Niagahoster.co.id → Cari domain → Beli → Catat DNS info
```

### 4️⃣ HUBUNGKAN DOMAIN (20 menit)
```
Netlify: Add custom domain
Provider: Ganti DNS ke Netlify
Tunggu: 1-24 jam propagasi
```

### 5️⃣ GO LIVE! (5 menit)
```
Ganti password default
Upload logo dinas
Update info kontak
Test semua fitur
```

---

## 💡 TIPS HEMAT:

**Domain Termurah:**
- Niagahoster: Rp 50k/tahun (.com)
- Promo first year biasanya lebih murah

**Hosting:** 
- Netlify: 100% GRATIS selamanya
- Bandwidth: 100GB/bulan (cukup banget)
- Build time: 300 menit/bulan (lebih dari cukup)

**Total Biaya:**
- Tahun 1: Rp 50-80k (domain only)
- Tahun 2+: Rp 120-150k (renewal domain)
- Hosting: Rp 0 (selamanya gratis!)

---

## ⚡ AKSI LANGSUNG:

1. **Sekarang**: Buat akun GitHub
2. **Hari ini**: Upload code & deploy ke Netlify  
3. **Besok**: Beli domain (cek promo dulu!)
4. **Lusa**: Connect domain & go live!

**Estimasi total waktu: 2-3 hari (karena waiting DNS propagation)**

---

## 🎯 HASIL AKHIR:

✅ Website WBS live di `https://nama-domain.com`  
✅ Dashboard admin berfungsi penuh  
✅ System pengaduan online siap pakai  
✅ Mobile responsive  
✅ SSL/HTTPS secure  
✅ Backup otomatis  
✅ Zero maintenance cost  

**Budget tersisa dari 100rb bisa buat beli kopi sambil ngecek website! ☕**