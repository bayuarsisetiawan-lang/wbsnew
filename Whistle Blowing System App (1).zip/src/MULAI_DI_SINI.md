# 🚀 MULAI DI SINI - Panduan Super Cepat WBS

## 🎯 3 Langkah Mudah Menggunakan Sistem WBS

### Langkah 1: Buat Admin Pertama ⚡
1. Buka aplikasi di browser
2. Kunjungi halaman `/setup`
3. Isi formulir:
   ```
   Nama:      Administrator PMPTSP
   Email:     admin@tegalkab.go.id
   Password:  (password aman Anda)
   ```
4. Klik "Buat Admin Pertama"
5. **SELESAI!** Admin berhasil dibuat ✅

### Langkah 2: Login sebagai Admin 🔐
1. Buka `/login`
2. Masukkan email dan password yang tadi dibuat
3. Otomatis masuk ke Dashboard Admin

### Langkah 3: Mulai Gunakan Sistem 🎉
Sekarang Anda bisa:
- ✅ Melihat statistik pengaduan
- ✅ Mengelola pengaduan yang masuk
- ✅ Menambah kategori baru
- ✅ Membuat user display
- ✅ Customize logo dan info instansi

---

## 📋 Checklist Awal

- [ ] Admin pertama sudah dibuat
- [ ] Sudah login ke dashboard admin
- [ ] Logo instansi sudah diupload (opsional)
- [ ] Nama instansi sudah disesuaikan (opsional)
- [ ] Kontak sudah diupdate (opsional)
- [ ] Kategori sudah ditambahkan sesuai kebutuhan (opsional)
- [ ] User display sudah dibuat (jika perlu)

---

## 🎨 Kustomisasi (Opsional)

### Upload Logo Instansi
1. Login sebagai admin
2. Buka `/admin/settings`
3. Klik tombol "Pilih Logo"
4. Pilih file gambar (PNG/JPG, max 2MB)
5. Preview muncul otomatis ✅
6. Klik "Simpan Pengaturan"
7. Logo langsung tersimpan dan tampil di seluruh aplikasi! 🎉

**Catatan:**
- Logo disimpan sebagai base64 (tidak perlu storage eksternal)
- Upload instant dan reliable
- Max 2MB untuk performa optimal

### Ubah Nama Instansi
1. Buka `/admin/settings`
2. Edit "Nama Instansi"
3. Ubah dari "Dinas PMPTSP Kab. Tegal" ke nama instansi Anda
4. Klik "Simpan"

### Tambah Kategori Baru
1. Buka `/admin/kategori`
2. Klik "Tambah Kategori"
3. Isi nama dan deskripsi
4. Klik "Tambah"

---

## 📱 Halaman Penting

| Halaman | URL | Siapa yang Akses |
|---------|-----|------------------|
| Homepage | `/` | Semua orang |
| Buat Aduan | `/buat-aduan` | Semua orang (publik) |
| Pantau Aduan | `/pantau-aduan` | Semua orang (publik) |
| Setup Admin | `/setup` | Admin pertama (sekali) |
| Login | `/login` | Admin & Display |
| Dashboard Admin | `/admin/dashboard` | Admin saja |
| Kelola Pengaduan | `/admin/pengaduan` | Admin saja |
| Kelola Kategori | `/admin/kategori` | Admin saja |
| Kelola Users | `/admin/users` | Admin saja |
| Settings | `/admin/settings` | Admin saja |
| Dashboard Display | `/display/dashboard` | Display saja |

---

## 🔒 Role & Akses

### 👨‍💼 Admin
- **Bisa**: Akses semua fitur
- **Login di**: `/login`
- **Redirect ke**: `/admin/dashboard`
- **Dibuat via**: `/setup` (pertama kali) atau `/admin/users` (selanjutnya)

### 📺 Display
- **Bisa**: Lihat dashboard monitoring saja
- **Login di**: `/login`
- **Redirect ke**: `/display/dashboard`
- **Dibuat via**: `/admin/users` (oleh admin)

### 👥 Publik
- **Bisa**: Buat aduan, pantau aduan
- **Tidak perlu**: Login
- **Akses**: `/`, `/buat-aduan`, `/pantau-aduan`, dll

---

## ❓ FAQ Singkat

### Bagaimana cara membuat admin pertama?
→ Kunjungi `/setup`, isi form, klik submit. Selesai!

### Apakah perlu setup database?
→ **TIDAK!** Sistem menggunakan KV Store yang otomatis tersedia.

### Bagaimana cara membuat user display?
→ Login sebagai admin → `/admin/users` → "Tambah User" → Pilih role "Display"

### Lupa password admin?
→ Reset via Supabase Dashboard: Authentication → Users → Reset Password

### Bagaimana cara customize logo?
→ Login admin → `/admin/settings` → Upload logo → Simpan

### Apakah data aman?
→ Ya! Data terenkripsi dan disimpan di Supabase (SOC 2 Type 2 certified)

---

## 📞 Butuh Bantuan?

### Dokumentasi Lengkap
- 📖 [PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md) - Tutorial detail semua fitur
- 🔐 [KREDENSIAL_DEFAULT.md](./KREDENSIAL_DEFAULT.md) - Panduan setup admin & keamanan
- 📝 [README.md](./README.md) - Overview sistem
- 🔄 [CHANGELOG.md](./CHANGELOG.md) - Riwayat perubahan

### Support
- Console browser (F12) untuk lihat error
- Supabase Dashboard untuk monitoring
- Hubungi administrator sistem

---

## 🎉 Selamat!

Sistem WBS Anda siap digunakan! Mulai terima pengaduan dari masyarakat dan kelola dengan mudah.

**🚀 Langkah selanjutnya:**
1. ✅ Buat admin pertama di `/setup`
2. ✅ Login di `/login`
3. ✅ Customize di `/admin/settings`
4. ✅ Bagikan link website ke masyarakat
5. ✅ Mulai terima & kelola pengaduan

---

© 2025 Dinas PMPTSP Kabupaten Tegal  
Whistle Blowing System - Bersama Ciptakan Pemerintahan Bersih
