# 🚀 Panduan Penggunaan WBS - Whistle Blowing System

## ✨ Sistem Sudah Siap Digunakan!

Aplikasi WBS ini **LANGSUNG BISA DIGUNAKAN** tanpa perlu setup database yang rumit. Semua data disimpan menggunakan **KV Store** yang sudah tersedia secara otomatis.

---

## 🎯 Fitur Utama

### 1. **Formulir Pengaduan Publik** (/)
- Buat laporan pengaduan baru
- Opsi laporan anonim
- Upload bukti pendukung (JPG, PNG, PDF)
- Sistem nomor tiket otomatis
- **Langsung berfungsi tanpa setup!**

### 2. **Pantau Status Aduan** (/pantau-aduan)
- Cek status laporan dengan nomor tiket
- Lihat riwayat perubahan status
- Real-time tracking

### 3. **Dashboard Admin** (/admin/dashboard)
- Statistik laporan
- Grafik visualisasi data
- Daftar laporan terbaru
- **Login diperlukan**

### 4. **Kelola Pengaduan** (/admin/pengaduan)
- Lihat semua laporan
- Filter berdasarkan status & kategori
- Update status laporan
- Hapus laporan
- **Login diperlukan**

### 5. **Kelola Kategori** (/admin/kategori)
- Tambah kategori baru
- Edit kategori existing
- Hapus kategori
- **Kategori default sudah tersedia:**
  - Korupsi
  - Penyalahgunaan Wewenang
  - Pelanggaran Disiplin
  - Pelanggaran Kode Etik
  - Diskriminasi
  - Fraud
  - Lainnya

### 6. **Kelola Users** (/admin/users)
- Tambah user admin/display
- Hapus user
- **Login admin diperlukan**

### 7. **Dashboard Display** (/display/dashboard)
- Tampilan monitoring untuk layar publik
- Auto-refresh setiap 30 detik
- Statistik real-time
- **Login display diperlukan**

---

## 👤 Setup Admin Pertama (MUDAH!)

### ✨ Cara Tercepat - Gunakan Halaman Setup:

1. **Buka aplikasi** di browser
2. **Kunjungi** `/setup` atau klik link "Setup Admin" di halaman login
3. **Isi formulir**:
   - Nama Lengkap: `Administrator`
   - Email: `admin@tegalkab.go.id` (atau email lain)
   - Password: `admin123` (atau password yang aman)
   - Konfirmasi Password: (ketik ulang password)
4. **Klik "Buat Admin Pertama"**
5. **Selesai!** Langsung redirect ke halaman login
6. **Login** dengan email dan password yang baru dibuat

### 📝 Contoh Data Admin:
```
Nama: Administrator PMPTSP
Email: admin@tegalkab.go.id
Password: Tegal2025!
```

**💡 TIPS:** 
- Sistem akan otomatis redirect ke `/setup` jika belum ada admin
- Halaman setup hanya bisa diakses sekali (saat belum ada admin)
- Setelah admin dibuat, halaman setup akan redirect ke login
- Gunakan password yang kuat untuk keamanan

---

## 🔐 Role & Permissions

### Admin
- Akses penuh ke dashboard admin
- Bisa membuat, edit, hapus kategori
- Bisa update status laporan
- Bisa manage users
- Akses: `/admin/*`

### Display
- Hanya akses dashboard display
- Tidak bisa edit data
- Cocok untuk layar monitoring publik
- Akses: `/display/dashboard`

### Public
- Bisa buat laporan baru
- Bisa pantau status laporan
- Tidak perlu login
- Akses: `/`, `/buat-aduan`, `/pantau-aduan`

---

## 📝 Cara Menggunakan

### Membuat Laporan Baru
1. Kunjungi `/buat-aduan`
2. Pilih apakah ingin laporan anonim atau tidak
3. Isi data sesuai prinsip 5W1H
4. Upload bukti (opsional)
5. Klik **Kirim Laporan**
6. **Simpan nomor tiket** untuk tracking

### Memantau Status Laporan
1. Kunjungi `/pantau-aduan`
2. Masukkan nomor tiket
3. Klik **Cari Laporan**
4. Lihat status dan riwayat

### Login Admin/Display
1. Kunjungi `/login`
2. Masukkan email & password
3. Sistem otomatis redirect ke dashboard sesuai role

---

## 🎨 Customization

### Mengubah Logo & Informasi
1. Login sebagai admin
2. Masuk ke `/admin/settings`
3. Upload logo baru
4. Ubah nama instansi
5. Ubah informasi kontak
6. Klik **Simpan**

### Menambah Kategori Baru
1. Login sebagai admin
2. Masuk ke `/admin/kategori`
3. Klik **Tambah Kategori**
4. Isi nama dan deskripsi
5. Klik **Tambah**

---

## 🔧 Troubleshooting

### Tidak Bisa Login
- Pastikan user sudah dibuat di Supabase
- Pastikan role sudah di-set di user metadata
- Clear browser cache & cookies
- Coba browser lain

### Laporan Tidak Muncul
- Refresh halaman
- Pastikan koneksi internet stabil
- Cek console browser untuk error

### Data Hilang
- Data disimpan di KV Store Supabase
- Data akan persistent selama project Supabase aktif
- Backup data secara berkala (export dari admin dashboard)

---

## 🚨 Keamanan

- ✅ Identitas pelapor dijaga kerahasiaan
- ✅ File upload dibatasi ukuran & tipe
- ✅ Authentication dengan Supabase Auth
- ✅ Role-based access control
- ✅ Data enkripsi di-rest dan in-transit

---

## 📞 Support

Untuk pertanyaan atau bantuan, hubungi administrator sistem.

---

**🎉 Selamat menggunakan Whistle Blowing System!**

Sistem ini dibuat khusus untuk **Dinas PMPTSP Kab.Tegal** dengan teknologi modern:
- ⚛️ React + TypeScript
- 🎨 Tailwind CSS
- 🔥 Supabase (Auth & Storage)
- ⚡ Real-time updates