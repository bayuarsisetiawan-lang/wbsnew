import { AlertCircle, Mail, Phone, MapPin, Globe } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useSettings } from '../utils/settings';

export function Footer() {
  const { settings } = useSettings();

  return (
    <footer className="bg-gray-900 text-gray-300 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* About */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              {settings.logoUrl ? (
                <img 
                  src={settings.logoUrl} 
                  alt="Logo" 
                  className="h-8 w-8 object-contain brightness-0 invert"
                />
              ) : (
                <AlertCircle className="h-6 w-6 text-blue-400" />
              )}
              <span className="text-white">{settings.institutionShortName || 'WBS'}</span>
            </div>
            <p className="text-sm">
              Whistle Blowing System adalah sarana pelaporan dugaan pelanggaran yang terjadi
              di lingkungan {settings.institutionName || 'instansi'}, dengan jaminan kerahasiaan identitas pelapor.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white mb-4">Tautan Cepat</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/tentang-wbs" className="hover:text-white transition-colors">
                  Tentang WBS
                </Link>
              </li>
              <li>
                <Link to="/buat-aduan" className="hover:text-white transition-colors">
                  Buat Aduan
                </Link>
              </li>
              <li>
                <Link to="/pantau-aduan" className="hover:text-white transition-colors">
                  Pantau Aduan
                </Link>
              </li>
              <li>
                <Link to="/faq" className="hover:text-white transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/syarat-ketentuan" className="hover:text-white transition-colors">
                  Syarat & Ketentuan
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white mb-4">Kontak</h3>
            <ul className="space-y-3 text-sm">
              {settings.institutionEmail && (
                <li className="flex items-start space-x-2">
                  <Mail className="h-5 w-5 text-blue-400 flex-shrink-0" />
                  <a href={`mailto:${settings.institutionEmail}`} className="hover:text-white">
                    {settings.institutionEmail}
                  </a>
                </li>
              )}
              {settings.institutionPhone && (
                <li className="flex items-start space-x-2">
                  <Phone className="h-5 w-5 text-blue-400 flex-shrink-0" />
                  <span>{settings.institutionPhone}</span>
                </li>
              )}
              {settings.institutionAddress && (
                <li className="flex items-start space-x-2">
                  <MapPin className="h-5 w-5 text-blue-400 flex-shrink-0" />
                  <span>{settings.institutionAddress}</span>
                </li>
              )}
              {settings.institutionWebsite && (
                <li className="flex items-start space-x-2">
                  <Globe className="h-5 w-5 text-blue-400 flex-shrink-0" />
                  <a 
                    href={settings.institutionWebsite} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="hover:text-white"
                  >
                    {settings.institutionWebsite.replace(/^https?:\/\//, '')}
                  </a>
                </li>
              )}
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-sm text-center">
          <p>{settings.footerText || `© ${new Date().getFullYear()} Whistle Blowing System. All rights reserved.`}</p>
        </div>
      </div>
    </footer>
  );
}