import React from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { isDevelopment } from '../utils/environment';

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
  errorInfo?: React.ErrorInfo;
}

export class ErrorBoundary extends React.Component<
  React.PropsWithChildren<{}>,
  ErrorBoundaryState
> {
  constructor(props: React.PropsWithChildren<{}>) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    
    // Log error ke service monitoring (Sentry, LogRocket, dll)
    if (typeof window !== 'undefined' && window.location.hostname !== 'localhost') {
      // Di production, kirim error ke monitoring service
      this.logErrorToService(error, errorInfo);
    }
    
    this.setState({
      error,
      errorInfo
    });
  }

  logErrorToService = (error: Error, errorInfo: React.ErrorInfo) => {
    // Integrate dengan service monitoring seperti Sentry
    // window.Sentry?.captureException(error, {
    //   extra: errorInfo
    // });
    
    console.log('Error logged to monitoring service:', {
      error: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack
    });
  };

  handleRetry = () => {
    this.setState({ hasError: false, error: undefined, errorInfo: undefined });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-gray-50">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
                <AlertCircle className="w-6 h-6 text-red-600" />
              </div>
              <CardTitle className="text-red-900">Terjadi Kesalahan</CardTitle>
              <CardDescription>
                Maaf, terjadi kesalahan tak terduga pada aplikasi. 
                Tim teknis telah diberitahu dan akan segera memperbaiki masalah ini.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {isDevelopment() && this.state.error && (
                <div className="bg-gray-100 p-3 rounded text-xs">
                  <details>
                    <summary className="cursor-pointer font-medium">Error Details (Development Only)</summary>
                    <pre className="mt-2 whitespace-pre-wrap">
                      {this.state.error.message}
                      {'\n\n'}
                      {this.state.error.stack}
                    </pre>
                  </details>
                </div>
              )}
              
              <div className="flex flex-col gap-2">
                <Button 
                  onClick={this.handleRetry}
                  className="w-full"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Coba Lagi
                </Button>
                
                <Button 
                  variant="outline" 
                  onClick={() => window.location.href = '/'}
                  className="w-full"
                >
                  Kembali ke Beranda
                </Button>
              </div>
              
              <div className="text-center text-sm text-gray-600">
                <p>Jika masalah berlanjut, silakan hubungi:</p>
                <p className="font-medium">admin.wbs@tegalkab.go.id</p>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

// Hook untuk error boundary di functional components
export const useErrorHandler = () => {
  return (error: Error, errorInfo?: string) => {
    console.error('Application Error:', error);
    
    // Log ke monitoring service di production
    if (typeof window !== 'undefined' && window.location.hostname !== 'localhost') {
      // window.Sentry?.captureException(error, {
      //   extra: { errorInfo }
      // });
    }
  };
};