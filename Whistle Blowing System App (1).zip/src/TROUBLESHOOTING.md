# 🔧 Troubleshooting Guide - WBS

Panduan mengatasi masalah umum yang mungkin terjadi.

---

## 🚨 Error: "Failed to update settings"

### Penyebab Umum:
1. **Sesi login telah berakhir**
2. **User bukan admin**
3. **Masalah koneksi**

### Solusi:

#### 1. Logout dan Login Kembali
```
1. Klik tombol "Keluar" di navbar
2. Login lagi di /login
3. Coba simpan settings lagi
```

#### 2. Cek Role User
```
1. Buka Supabase Dashboard
2. Authentication → Users
3. Cari user Anda
4. Pastikan user_metadata → role = "admin"
5. Jika bukan "admin", ubah ke "admin"
```

#### 3. Cek Console Browser
```
1. Tekan F12 untuk buka DevTools
2. Tab Console
3. Lihat error detail
4. Screenshot dan laporkan ke admin
```

---

## 🚨 Error: "Failed to upload logo"

### Sudah Fixed di v2.1.1!

Jika masih terjadi:

#### 1. Cek Ukuran File
```
- Max: 2MB
- Jika lebih besar, compress dulu
- Gunakan tools: TinyPNG, ImageOptim
```

#### 2. Cek Format File
```
- Supported: PNG, JPG, JPEG, GIF, WebP
- Pastikan file adalah gambar valid
```

#### 3. Coba File Lain
```
- Pilih gambar yang lebih kecil
- Test dengan file lain
```

---

## 🚨 Error: "Sesi login telah berakhir"

### Penyebab:
Session Supabase expired (default: 1 hour inactive)

### Solusi:
```
1. Logout dari aplikasi
2. Login kembali
3. Session akan refresh otomatis
```

### Prevent di Masa Depan:
- Jangan biarkan tab idle terlalu lama
- Refresh halaman sebelum melakukan aksi penting
- Aktifkan "Remember me" jika tersedia

---

## 🚨 Error: "Hanya admin yang dapat mengubah pengaturan"

### Penyebab:
User login sebagai Display atau role tidak valid

### Solusi:
```
1. Check role di Supabase Dashboard
2. Authentication → Users → User Metadata
3. Pastikan: { "role": "admin" }
4. Logout dan login kembali
```

---

## 🚨 Tidak Bisa Login

### Cek List:
- [ ] Email benar? (cek typo)
- [ ] Password benar? (case sensitive!)
- [ ] Caps Lock aktif?
- [ ] User sudah dibuat di /setup?
- [ ] Network connection OK?

### Debug Steps:
```
1. F12 → Console → Lihat error
2. Network tab → Cek request/response
3. Coba browser lain (Chrome, Firefox)
4. Clear cache & cookies
```

### Lupa Password?
```
1. Buka Supabase Dashboard
2. Authentication → Users
3. Cari user Anda
4. Klik "..." → "Reset Password"
5. Set password baru
6. Login dengan password baru
```

---

## 🚨 Laporan Tidak Muncul di Dashboard

### Cek:
1. **Refresh Halaman** - Data baru perlu reload
2. **Filter Status** - Mungkin filter aktif
3. **Kategori** - Cek filter kategori
4. **Console Error** - F12 untuk debug

### Solusi:
```
1. Hard refresh: Ctrl+Shift+R (Windows) / Cmd+Shift+R (Mac)
2. Clear filter status dan kategori
3. Logout dan login kembali
4. Cek Supabase Edge Functions logs
```

---

## 🚨 Logo Tidak Muncul / Broken Image

### Penyebab:
- Base64 string corrupt
- File terlalu besar
- Browser cache issue

### Solusi:
```
1. Upload logo lagi dengan file yang lebih kecil
2. Hard refresh: Ctrl+Shift+R
3. Clear browser cache
4. Coba browser lain
```

---

## 🚨 Dashboard Display Tidak Auto-Refresh

### Expected Behavior:
Dashboard Display refresh setiap 30 detik

### Jika Tidak Refresh:
```
1. Cek console untuk error
2. Refresh manual (F5)
3. Logout dan login kembali
4. Cek network tab untuk failed requests
```

---

## 🚨 Cannot Access /admin/* Pages

### Penyebab:
1. Belum login
2. Login sebagai Display (bukan Admin)
3. Session expired

### Solusi:
```
1. Login di /login
2. Pastikan role = "admin"
3. Check Supabase Dashboard → User Metadata
```

---

## 🚨 CORS Error

### Error Message:
```
Access to fetch at '...' from origin '...' has been blocked by CORS policy
```

### Penyebab:
Server CORS configuration issue (shouldn't happen!)

### Solusi:
```
1. Refresh halaman
2. Clear cache
3. Check Supabase Edge Functions logs
4. Contact system administrator
```

---

## 🚨 500 Internal Server Error

### Penyebab:
Server error di backend

### Debug:
```
1. Buka Supabase Dashboard
2. Edge Functions → make-server-7bc260f6 → Logs
3. Lihat error detail
4. Screenshot dan laporkan
```

### Immediate Fix:
```
1. Refresh halaman
2. Coba lagi dalam 1-2 menit
3. Jika persisten, hubungi admin
```

---

## 🚨 Network Request Failed

### Penyebab:
1. Internet connection loss
2. Supabase down (rare)
3. Request timeout

### Solusi:
```
1. Cek koneksi internet
2. Refresh halaman
3. Coba lagi dalam beberapa menit
4. Check status.supabase.com
```

---

## 🔍 How to Debug Like a Pro

### 1. Browser Console (F12)
```
1. Tekan F12
2. Tab Console
3. Look for red errors
4. Screenshot error message
```

### 2. Network Tab
```
1. F12 → Network tab
2. Reproduce error
3. Look for failed requests (red)
4. Click failed request → Preview/Response
5. Screenshot error response
```

### 3. Supabase Logs
```
1. Supabase Dashboard
2. Edge Functions → Logs
3. Filter by time (last hour)
4. Look for errors
```

### 4. Check Session
```
1. Console → Type:
   localStorage.getItem('supabase.auth.token')
2. Check if token exists
3. If null → Login again
```

---

## 📞 Kapan Harus Hubungi Support?

Hubungi system administrator jika:
- ✅ Sudah coba semua solusi di atas
- ✅ Error persisten > 1 jam
- ✅ Multiple users mengalami masalah sama
- ✅ Data corruption / data loss
- ✅ Security issues

---

## 🎯 Prevention Tips

### Untuk Admin:
1. **Logout jika tidak digunakan** - Security
2. **Jangan share credentials** - Risk
3. **Backup data berkala** - Safety
4. **Monitor logs** - Early detection
5. **Update password 3-6 bulan** - Security

### Untuk Sistem:
1. **Regular monitoring** - Check logs
2. **Test di staging** - Before production
3. **Documentation** - Keep updated
4. **Backup strategy** - KV store export

---

## 🆘 Emergency Contacts

### System Administrator
- Email: (sesuai instansi)
- Phone: (sesuai instansi)

### Supabase Support
- Dashboard: https://supabase.com/dashboard
- Docs: https://supabase.com/docs
- Status: https://status.supabase.com

---

## 📚 Helpful Resources

### Documentation
- [PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md) - User manual
- [QUICK_START.md](./QUICK_START.md) - Developer guide
- [TECHNICAL_NOTES.md](./TECHNICAL_NOTES.md) - Technical details

### External Resources
- Supabase Docs: https://supabase.com/docs
- React Docs: https://react.dev
- Tailwind CSS: https://tailwindcss.com

---

**🎉 Masih ada masalah? Jangan ragu hubungi administrator sistem!**

---

**Last Updated:** October 3, 2025  
**Version:** 2.1.2