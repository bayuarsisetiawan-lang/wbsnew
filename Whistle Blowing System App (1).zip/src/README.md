# 🚨 Whistle Blowing System (WBS)

Sistem Pengaduan Digital untuk **Dinas PMPTSP Kabupaten Tegal**

[![Status](https://img.shields.io/badge/status-siap%20pakai-brightgreen)]()
[![Tech](https://img.shields.io/badge/tech-React%20%2B%20Supabase-blue)]()

---

## ✨ Fitur Lengkap

✅ **Formulir pengaduan publik** dengan sistem tiket otomatis  
✅ **Tracking status** laporan real-time  
✅ **Dashboard admin** dengan statistik & grafik  
✅ **Dashboard display** untuk layar monitoring publik  
✅ **Manajemen kategori** pengaduan yang fleksibel  
✅ **Manajemen users** (Admin & Display)  
✅ **Customization** logo, nama instansi, kontak  
✅ **Keamanan** identitas pelapor terjamin  
✅ **Upload file** bukti pendukung (JPG, PNG, PDF)  
✅ **Laporan anonim** tersedia  

---

## 🚀 Langsung Pakai dalam 2 Menit! (Super Mudah)

Aplikasi ini **TIDAK PERLU SETUP DATABASE** yang rumit. Semua data otomatis tersimpan di KV Store Supabase. 

### ⚡ Setup dalam 3 Langkah:

```
1️⃣ Buka /setup
2️⃣ Isi form (nama, email, password)
3️⃣ Klik "Buat Admin Pertama"
✅ SELESAI!
```

**Detail Setup Admin Pertama:**

1. **Buka aplikasi** di browser
2. **Kunjungi halaman** `/setup` 
   - Sistem otomatis redirect jika belum ada admin
   - Jika sudah ada admin, redirect ke `/login`
3. **Isi formulir** setup admin:
   ```
   Nama Lengkap:     Administrator PMPTSP Kab. Tegal
   Email:            admin@tegalkab.go.id
   Password:         (password aman, minimal 6 karakter)
   Konfirmasi:       (ketik ulang password)
   ```
4. **Klik** "Buat Admin Pertama"
5. **Otomatis redirect** ke halaman login
6. **Login** dengan email & password yang baru dibuat
7. **🎉 SELESAI!** Dashboard admin siap digunakan

### 🔐 Contoh Kredensial

**Testing/Development:**
```
Email:    admin@tegalkab.go.id
Password: admin123
```

**Production (Gunakan Password Kuat!):**
```
Email:    admin@pmptsp.tegalkab.go.id
Password: Tegal@PMPTSP2025!
```

> ⚠️ **PENTING:** Tidak ada default username/password untuk keamanan.
> Admin pertama HARUS dibuat manual via `/setup` atau Supabase Dashboard.

---

## 📱 Halaman Utama

| Path | Deskripsi | Akses |
|------|-----------|-------|
| `/` | Homepage | Public |
| `/buat-aduan` | Formulir pengaduan | Public |
| `/pantau-aduan` | Cek status laporan | Public |
| `/login` | Login admin/display | Public |
| `/admin/dashboard` | Dashboard admin | Admin only |
| `/admin/pengaduan` | Kelola pengaduan | Admin only |
| `/admin/kategori` | Kelola kategori | Admin only |
| `/admin/users` | Kelola users | Admin only |
| `/admin/settings` | Pengaturan sistem | Admin only |
| `/display/dashboard` | Layar monitoring | Display only |

---

## 🎯 Quick Start Guide

### Untuk Masyarakat (Pelapor)
1. Kunjungi website
2. Klik **Buat Aduan**
3. Isi formulir (bisa anonim)
4. Upload bukti (opsional)
5. Dapatkan nomor tiket
6. Pantau status di **Pantau Aduan**

### Untuk Admin
1. Login di `/login`
2. Dashboard otomatis muncul
3. Kelola laporan masuk
4. Update status laporan
5. Manage kategori & users

### Untuk Display (Layar Publik)
1. Login dengan akun display
2. Dashboard monitoring muncul
3. Auto-refresh setiap 30 detik
4. Cocok untuk TV/layar besar

---

## 🛠️ Tech Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS v4
- **UI Components**: Shadcn/ui
- **Backend**: Supabase (Auth, KV Store)
- **Charts**: Recharts
- **Icons**: Lucide React
- **Routing**: React Router v6
- **Forms**: React Hook Form + Zod

---

## 🔐 Keamanan

- ✅ Authentication dengan Supabase Auth
- ✅ Role-based access control (Admin, Display, Public)
- ✅ Identitas pelapor terenkripsi
- ✅ File upload validation (ukuran & tipe)
- ✅ Protected routes
- ✅ HTTPS only in production

---

## 📖 Dokumentasi Lengkap

### 🎯 Mulai dari Mana?
- **[DAFTAR_ISI.md](./DAFTAR_ISI.md)** - 📑 Index semua dokumentasi (mulai di sini!)
- **[JAWABAN_SINGKAT.md](./JAWABAN_SINGKAT.md)** - ⚡ FAQ dengan jawaban super singkat

### 🚀 Quick Start
- **[MULAI_DI_SINI.md](./MULAI_DI_SINI.md)** - 🎯 Panduan 3 langkah untuk pemula (RECOMMENDED!)
- **[QUICK_START.md](./QUICK_START.md)** - 💻 Quick reference untuk developer/IT
- **[INFO_LOGIN.txt](./INFO_LOGIN.txt)** - 🔐 Informasi kredensial (text format)

### 📚 Panduan Lengkap
- **[PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md)** - 📖 Tutorial lengkap semua fitur
- **[KREDENSIAL_DEFAULT.md](./KREDENSIAL_DEFAULT.md)** - 🔒 Panduan setup admin & keamanan

### 📝 Informasi Tambahan
- **[README.md](./README.md)** - 📄 Overview & quick start (file ini)
- **[TROUBLESHOOTING.md](./TROUBLESHOOTING.md)** - 🔧 Panduan mengatasi error (PENTING!)
- **[CHANGELOG.md](./CHANGELOG.md)** - 🔄 Riwayat perubahan sistem
- **[TECHNICAL_NOTES.md](./TECHNICAL_NOTES.md)** - 💻 Catatan teknis & design decisions
- **[Attributions.md](./Attributions.md)** - 🙏 Credits & acknowledgments

---

### 💡 Rekomendasi Baca:

**Jika Anda baru pertama kali:**
1. Baca [MULAI_DI_SINI.md](./MULAI_DI_SINI.md) (2 menit)
2. Baca [INFO_LOGIN.txt](./INFO_LOGIN.txt) (1 menit)
3. Langsung praktek setup!

**Jika butuh jawaban cepat:**
→ Buka [JAWABAN_SINGKAT.md](./JAWABAN_SINGKAT.md)

**Jika butuh tutorial detail:**
→ Buka [PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md)

**Jika developer/IT:**
→ Buka [QUICK_START.md](./QUICK_START.md)

---

## 🎨 Customization

Sistem ini dapat disesuaikan tanpa coding:

1. **Logo**: Upload di `/admin/settings`
2. **Nama Instansi**: Edit di `/admin/settings`
3. **Kontak**: Edit di `/admin/settings`
4. **Kategori**: Tambah/edit di `/admin/kategori`
5. **Warna**: Sudah menggunakan skema warna default Indonesia

---

## 📞 Support & Maintenance

Untuk bantuan teknis atau pertanyaan:
- Hubungi administrator sistem
- Lihat console browser untuk error logs
- Check Supabase dashboard untuk monitoring

---

## 📄 License

Dibuat khusus untuk **Dinas PMPTSP Kabupaten Tegal**  
© 2025 - All Rights Reserved

---

## 🙏 Credits

Dibangun dengan:
- React Team
- Supabase Team
- Shadcn/ui
- Tailwind Labs
- Dan banyak open source libraries lainnya

---

**🎉 Happy Reporting! Bersama kita ciptakan pemerintahan yang bersih dan transparan.**