# 🚀 PANDUAN DEPLOY STEP-BY-STEP ULTRA DETAIL

## 📱 STEP 1: PERSIAPAN AWAL (5 menit)

### Yang Anda Butuhkan:
- Komputer/laptop dengan internet
- Email aktif
- Uang Rp 50-80k untuk domain
- Semua file project WBS (sudah ada)

### Download Semua File Project:
1. **Pastikan semua file project ada di satu folder**
2. **Buat folder baru bernama**: `wbs-dinas-pmptsp-tegal`
3. **Copy semua file ini ke dalam folder**:
   ```
   ├── App.tsx
   ├── package.json
   ├── vite.config.ts
   ├── netlify.toml
   ├── components/ (folder lengkap)
   ├── pages/ (folder lengkap)
   ├── styles/ (folder lengkap)
   ├── utils/ (folder lengkap)
   ├── public/ (folder lengkap)
   └── semua file lainnya
   ```

---

## 🐙 STEP 2: BUAT AKUN GITHUB (10 menit)

### 2.1 Daftar GitHub:
1. **Buka browser**, ketik: `github.com`
2. **Klik tombol hijau "Sign up"**
3. **Isi form pendaftaran**:
   - Username: `dinas-pmptsp-tegal` (atau sesuai keinginan)
   - Email: email aktif Anda
   - Password: buat password kuat
4. **Verifikasi robot** (pilih gambar sesuai petunjuk)
5. **Klik "Create account"**
6. **Cek email** → klik link verifikasi
7. **Pilih "Free plan"** (gratis)

### 2.2 Buat Repository (Tempat Code):
1. **Setelah login GitHub**, cari tombol hijau **"New"**
2. **Isi form repository**:
   - Repository name: `wbs-dinas-pmptsp-tegal`
   - Description: `Website Whistle Blowing System Dinas PMPTSP Kab.Tegal`
   - Pilih: **Public** (gratis)
   - ✅ Centang: "Add a README file"
3. **Klik "Create repository"**

### 2.3 Upload File Project:
**CARA MUDAH (Upload Manual):**
1. **Di halaman repository**, klik **"uploading an existing file"**
2. **Drag semua file dan folder** dari komputer ke browser
3. **Tunggu upload selesai** (2-5 menit tergantung internet)
4. **Scroll ke bawah**, tulis commit message:
   ```
   Initial upload - WBS Dinas PMPTSP Kab.Tegal
   ```
5. **Klik "Commit changes"**

**✅ BERHASIL!** Code sudah di GitHub!

---

## 🚀 STEP 3: DEPLOY KE NETLIFY (15 menit)

### 3.1 Daftar Netlify:
1. **Buka tab baru**, ketik: `netlify.com`
2. **Klik "Sign up"**
3. **Pilih "Sign up with GitHub"** (lebih mudah!)
4. **Authorize Netlify** → klik "Authorize netlify"

### 3.2 Deploy Website:
1. **Di dashboard Netlify**, klik **"New site from Git"**
2. **Pilih "GitHub"**
3. **Cari repository**: `wbs-dinas-pmptsp-tegal`
4. **Klik repository tersebut**
5. **Setting build** (PENTING!):
   ```
   Build command: npm run build
   Publish directory: dist
   ```
6. **Klik "Deploy site"**

### 3.3 Tunggu Build Process:
- **Loading sekitar 3-5 menit**
- **Lihat progress** di "Site deploys"
- **Jika SUCCESS** → dapat URL: `https://nama-random.netlify.app`
- **Jika FAILED** → lihat error log (akan saya bantu troubleshoot)

**✅ BERHASIL!** Website sudah live di internet!

---

## 🌐 STEP 4: BELI DOMAIN .COM (10 menit + Rp 50-80k)

### 4.1 Pilih Provider Domain:
**REKOMENDASI TERMURAH:**
- **Niagahoster**: Rp 50.000/tahun
- **Dewaweb**: Rp 55.000/tahun  
- **IDCloudHost**: Rp 60.000/tahun

### 4.2 Proses Pembelian (Contoh: Niagahoster):
1. **Buka**: `niagahoster.co.id`
2. **Klik "Domain"** di menu atas
3. **Ketik nama domain** yang diinginkan:
   - `wbspmptsp.com`
   - `pmptsp-tegal.com`
   - `wbs-tegal.com`
4. **Klik "Cari Domain"**
5. **Pilih domain yang available** → "Tambah ke Keranjang"
6. **Checkout** → isi data lengkap:
   - Data pribadi/dinas
   - Nomor telepon
   - Alamat lengkap
7. **Pilih pembayaran**: Transfer/E-wallet/Kartu kredit
8. **Bayar sesuai total**
9. **SIMPAN email konfirmasi** (berisi info DNS)

### 4.3 Catat Info Penting:
Setelah beli domain, catat:
- **Domain name**: contoh `wbspmptsp.com`
- **Login panel domain**: username + password
- **DNS Server**: biasanya `ns1.niagahoster.com`, `ns2.niagahoster.com`

---

## 🔗 STEP 5: HUBUNGKAN DOMAIN KE NETLIFY (20 menit)

### 5.1 Setting di Netlify:
1. **Login Netlify** → pilih site yang sudah di-deploy
2. **Klik "Domain settings"**
3. **Klik "Add custom domain"**
4. **Masukkan domain**: `wbspmptsp.com` (contoh)
5. **Klik "Verify"**
6. **Netlify akan memberikan DNS info**:
   ```
   Type: A Record
   Host: @
   Value: 75.2.60.5
   
   Type: CNAME
   Host: www
   Value: nama-site.netlify.app
   ```

### 5.2 Setting DNS di Provider Domain:
**CARA DI NIAGAHOSTER:**
1. **Login ke Member Area Niagahoster**
2. **Klik "Layanan Saya"** → pilih domain
3. **Klik "Kelola DNS"**
4. **Hapus record A dan CNAME yang lama**
5. **Tambah record baru**:
   - **Record A**:
     - Type: A
     - Host: @
     - Value: `75.2.60.5`
     - TTL: 14400
   - **Record CNAME**:
     - Type: CNAME  
     - Host: www
     - Value: `nama-site.netlify.app`
     - TTL: 14400
6. **Save Changes**

### 5.3 Aktivasi SSL (HTTPS):
1. **Kembali ke Netlify**
2. **Refresh halaman Domain settings**
3. **Tunggu "DNS verification" hijau** (5-60 menit)
4. **Otomatis dapat SSL certificate**
5. **Website jadi**: `https://wbspmptsp.com`

---

## ⚙️ STEP 6: KONFIGURASI FINAL (15 menit)

### 6.1 Environment Variables di Netlify:
1. **Di dashboard Netlify**, klik site
2. **Site settings** → **Environment variables**
3. **Add variable**:
   ```
   NODE_ENV = production
   VITE_APP_NAME = WBS Dinas PMPTSP Kab.Tegal
   ```
4. **Save**

### 6.2 Buat File Redirect:
1. **Buka folder project**
2. **Di dalam folder `public/`**, buat file baru: `_redirects`
3. **Isi file**:
   ```
   /*    /index.html   200
   ```
4. **Upload file ini ke GitHub** (cara sama seperti step 2.3)

### 6.3 Re-deploy Otomatis:
- **Netlify otomatis re-build** saat ada perubahan di GitHub
- **Tunggu 2-3 menit**
- **Website update otomatis**

---

## 🎨 STEP 7: CUSTOMIZATION (10 menit)

### 7.1 Akses Admin Panel:
1. **Buka**: `https://domain-anda.com/login`
2. **Login dengan**:
   - Username: `admin`
   - Password: `admin123`

### 7.2 Ganti Password (WAJIB!):
1. **Masuk dashboard admin**
2. **Settings** → **Users**
3. **Edit user admin**
4. **Ganti password baru yang kuat**
5. **Save**

### 7.3 Upload Logo Dinas:
1. **Siapkan logo PNG** (ukuran 200x60px)
2. **Settings** → **Pengaturan Tampilan**
3. **Upload logo**
4. **Save settings**

### 7.4 Update Info Kontak:
1. **Settings** → **Informasi Instansi**
2. **Update**:
   - Nama: "Dinas PMPTSP Kabupaten Tegal"
   - Alamat lengkap
   - No. telepon
   - Email resmi
3. **Save**

---

## 🧪 STEP 8: TESTING FINAL (10 menit)

### Cek List Testing:
- [ ] **Buka website** di browser desktop
- [ ] **Test mobile** (buka di HP)
- [ ] **Coba buat pengaduan** sebagai masyarakat
- [ ] **Login admin** dengan password baru
- [ ] **Cek dashboard** admin lengkap
- [ ] **Test display dashboard**
- [ ] **Cek semua menu** navigation
- [ ] **Upload file** test
- [ ] **HTTPS aktif** (ada gembok hijau)

---

## 🎉 STEP 9: GO LIVE! (5 menit)

### 9.1 Announcement:
1. **Screenshot website** untuk dokumentasi
2. **Buat pengumuman** internal di dinas
3. **Share URL** ke stakeholder
4. **Test terakhir** semua fitur

### 9.2 Monitoring Setup:
1. **Bookmark URL admin**: `https://domain-anda.com/login`
2. **Set reminder** backup rutin (monthly)
3. **Monitor performance** via Netlify dashboard
4. **Save credential** di tempat aman

---

## 💰 RINGKASAN BIAYA FINAL:

- **Domain .com**: Rp 50.000 - 80.000/tahun
- **Hosting Netlify**: Rp 0 (GRATIS selamanya!)
- **SSL Certificate**: Rp 0 (GRATIS)
- **Bandwidth**: 100GB/bulan (GRATIS)
- **Build minutes**: 300 menit/bulan (GRATIS)
- **Total tahun pertama**: Rp 50-80k saja!

---

## 🆘 TROUBLESHOOTING CEPAT:

### Website tidak bisa diakses:
1. **Tunggu 24 jam** (DNS propagasi)
2. **Cek di**: `dnschecker.org`
3. **Clear cache browser**: Ctrl+F5

### Build failed di Netlify:
1. **Cek build log** untuk error
2. **Pastikan file `package.json` ada**
3. **Re-deploy** manual

### Domain tidak connect:
1. **Cek DNS record** di provider
2. **Tunggu propagasi** 1-24 jam
3. **Contact support** provider domain

---

## 📞 BANTUAN DARURAT:

**Jika stuck di step manapun:**
1. **Screenshot error** yang muncul
2. **Catat step mana** yang bermasalah  
3. **Hubungi saya** dengan detail error
4. **Jangan panic** - semua bisa diperbaiki!

---

## ✨ HASIL AKHIR:

🎯 **Website WBS profesional**: `https://domain-anda.com`  
🔐 **Admin dashboard**: `https://domain-anda.com/login`  
📊 **Display dashboard**: `https://domain-anda.com/display/dashboard`  
📱 **Mobile responsive**: ✅  
🔒 **HTTPS secure**: ✅  
💾 **Auto backup**: ✅  
💰 **Budget hemat**: ✅ (di bawah 100rb!)  

**SELAMAT! Website WBS Dinas PMPTSP Kab.Tegal sudah LIVE! 🚀**