# 🚀 PANDUAN DEPLOYMENT WBS DINAS PMPTSP KAB.TEGAL

## 📋 CHECKLIST PRE-DEPLOYMENT

### ✅ 1. Persiapan Environment

#### A. Supabase Setup
- [ ] Buat project Supabase baru di [supabase.com](https://supabase.com)
- [ ] Salin URL dan ANON KEY dari Settings > API
- [ ] Setup custom domain (opsional tapi direkomendasikan)
- [ ] Konfigurasi CORS untuk domain production
- [ ] Enable Row Level Security (RLS)

#### B. Environment Variables
```bash
# .env.production
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
VITE_ENABLE_ANALYTICS=true
VITE_ENABLE_ERROR_REPORTING=true
VITE_ENABLE_PERFORMANCE=true
VITE_GA_MEASUREMENT_ID=G-XXXXXXXXXX
NODE_ENV=production
```

### ✅ 2. Domain & SSL
- [ ] Beli domain (.com, .id, atau .go.id)
- [ ] Setup DNS records
- [ ] Konfigurasi SSL certificate (auto via Vercel/Netlify)

### ✅ 3. Monitoring & Analytics
- [ ] Setup Google Analytics 4
- [ ] Setup error monitoring (Sentry - opsional)
- [ ] Setup uptime monitoring

---

## 🔧 DEPLOYMENT STEPS

### Opsi 1: Deployment ke Vercel (Recommended)

#### Step 1: Persiapan Repository
```bash
# 1. Push code ke GitHub
git init
git add .
git commit -m "Initial commit - WBS Production Ready"
git branch -M main
git remote add origin https://github.com/username/wbs-pmptsp-tegal.git
git push -u origin main
```

#### Step 2: Deploy ke Vercel
1. Login ke [vercel.com](https://vercel.com)
2. Import GitHub repository
3. Configure environment variables:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `VITE_ENABLE_ANALYTICS=true`
   - `VITE_GA_MEASUREMENT_ID` (jika ada)
4. Deploy!

#### Step 3: Custom Domain
1. Di Vercel dashboard > Settings > Domains
2. Add custom domain (misal: wbs.tegalkab.go.id)
3. Update DNS records sesuai instruksi Vercel

### Opsi 2: Deployment ke Netlify

#### Step 1: Build Setup
```bash
# netlify.toml
[build]
  publish = "build"
  command = "npm run build"

[build.environment]
  NODE_VERSION = "18"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

#### Step 2: Deploy
1. Login ke [netlify.com](https://netlify.com)
2. Drag & drop build folder atau connect GitHub
3. Configure environment variables
4. Deploy!

---

## ⚙️ KONFIGURASI PRODUCTION

### 1. Supabase Production Setup

#### A. Database Policies (sudah ada di migrations)
```sql
-- Jalankan migrations yang sudah ada:
-- 001_initial_schema.sql
-- 002_security_policies.sql  
-- 003_indexes_triggers.sql
-- 004_storage_setup.sql
```

#### B. Storage Configuration
```sql
-- Di Supabase SQL Editor
INSERT INTO storage.buckets (id, name, public) 
VALUES ('report-files', 'report-files', false);

-- Set storage policies (sudah ada di migration 004)
```

#### C. Auth Configuration
- Email confirmation: Enabled
- Sign up: Disabled (admin only)
- Session timeout: 8 hours
- JWT expiry: 1 hour

### 2. Security Hardening

#### A. Supabase Security
- [ ] Enable RLS pada semua tabel
- [ ] Review dan test semua policies
- [ ] Disable direct API access untuk production
- [ ] Setup CORS untuk domain specific
- [ ] Enable audit logging

#### B. Application Security
- [ ] Content Security Policy headers
- [ ] XSS protection headers
- [ ] HTTPS enforcement
- [ ] File upload validation
- [ ] Rate limiting (via Supabase)

---

## 📊 MONITORING & MAINTENANCE

### 1. Analytics Setup

#### Google Analytics 4
```javascript
// Sudah terintegrasi di utils/analytics.tsx
// Cukup set REACT_APP_GA_MEASUREMENT_ID
```

#### Custom Events Tracking
- Report submissions
- User logins/logouts
- File uploads
- Error occurrences
- Performance metrics

### 2. Error Monitoring

#### Setup Sentry (Opsional)
```bash
npm install @sentry/react @sentry/tracing
```

```javascript
// Di App.tsx tambahkan:
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: "YOUR_SENTRY_DSN",
  environment: process.env.NODE_ENV,
});
```

### 3. Performance Monitoring
- [ ] Core Web Vitals tracking
- [ ] Load time monitoring
- [ ] Error rate monitoring
- [ ] Uptime monitoring (UptimeRobot/Pingdom)

---

## 🔄 BACKUP & RECOVERY

### 1. Database Backup
```bash
# Automatic Supabase backups (7 days free plan, 30 days pro plan)
# Manual backup via Supabase Dashboard > Settings > Database > Backups
```

### 2. Application Backup
- [ ] Code repository (GitHub)
- [ ] Environment variables (secure storage)
- [ ] Supabase project configuration
- [ ] Domain/DNS configuration

### 3. Recovery Plan
1. **Database Recovery**: Restore dari Supabase backup
2. **Application Recovery**: Re-deploy dari GitHub
3. **Domain Recovery**: Update DNS records
4. **RTO**: < 1 hour untuk full recovery

---

## 🚀 GO-LIVE CHECKLIST

### Pre-Launch Testing
- [ ] Test semua fitur di staging environment
- [ ] Test dengan data real (sample)
- [ ] Test performance dengan load
- [ ] Test di berbagai browser/device
- [ ] Test backup & recovery procedures

### Launch Day
- [ ] Deploy ke production
- [ ] Update DNS records
- [ ] Test production environment
- [ ] Setup monitoring alerts
- [ ] Notify stakeholders
- [ ] Create admin accounts
- [ ] Import initial data (categories, users)

### Post-Launch
- [ ] Monitor error rates
- [ ] Monitor performance
- [ ] Monitor user feedback
- [ ] Setup regular maintenance schedule
- [ ] Train end users

---

## 👥 USER MANAGEMENT

### 1. Admin Account Setup
```bash
# Akses /setup untuk membuat Super Admin pertama
# Atau via Supabase Dashboard > Authentication > Users
```

### 2. User Roles
- **Super Admin**: Full control + customization
- **Admin**: Manage reports + users
- **Display**: View only dashboard

### 3. User Training
- [ ] Admin training documentation
- [ ] User manual untuk public
- [ ] Video tutorials (opsional)

---

## 🆘 TROUBLESHOOTING

### Common Issues
1. **Build Errors**: Check environment variables
2. **Database Connection**: Verify Supabase credentials
3. **CORS Errors**: Check Supabase CORS settings
4. **File Upload Issues**: Check storage policies
5. **Authentication Issues**: Check Auth settings

### Support Contacts
- **Developer**: [Your contact info]
- **Hosting**: Vercel/Netlify support
- **Database**: Supabase support
- **Domain**: Domain registrar support

---

## 📞 PRODUCTION CONTACTS

### Emergency Contacts
- **Technical Lead**: [Email/Phone]
- **System Admin**: [Email/Phone]
- **Business Owner**: [Email/Phone]

### Service Providers
- **Hosting**: Vercel/Netlify
- **Database**: Supabase
- **Domain**: [Domain registrar]
- **Analytics**: Google Analytics
- **Monitoring**: [Monitoring service]

---

## 📋 MAINTENANCE SCHEDULE

### Daily
- [ ] Check error logs
- [ ] Monitor uptime
- [ ] Review user reports

### Weekly  
- [ ] Review analytics data
- [ ] Check performance metrics
- [ ] Update documentation

### Monthly
- [ ] Security audit
- [ ] Backup verification
- [ ] Performance optimization
- [ ] User feedback review

### Quarterly
- [ ] Full system review
- [ ] Disaster recovery test
- [ ] Security penetration test
- [ ] Feature usage analysis

---

## 🎯 SUCCESS METRICS

### Technical KPIs
- **Uptime**: > 99.9%
- **Load Time**: < 2 seconds
- **Error Rate**: < 0.1%
- **User Satisfaction**: > 4.5/5

### Business KPIs
- **Report Submissions**: Track monthly
- **Resolution Time**: Track average
- **User Adoption**: Track registrations
- **System Usage**: Track daily active users

---

*Dokumen ini akan di-update sesuai kebutuhan deployment dan feedback dari production environment.*