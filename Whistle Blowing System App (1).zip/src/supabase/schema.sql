-- WBS DPMPTSP Kab. Tegal Database Schema
-- =====================================
-- 
-- File ini berisi semua table dan setup yang diperlukan untuk aplikasi WBS
-- Jalankan SQL ini di Supabase SQL Editor untuk membuat database schema

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =====================================================
-- 1. CATEGORIES TABLE
-- =====================================================
-- Tabel untuk kategori pengaduan (Korupsi, Fraud, dll)

CREATE TABLE IF NOT EXISTS public.categories (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Insert default categories
INSERT INTO public.categories (name, description) VALUES
('Korupsi', 'Dugaan tindak pidana korupsi'),
('Penyalahgunaan Wewenang', 'Penyalahgunaan jabatan atau wewenang'),
('Pelanggaran Disiplin', 'Pelanggaran disiplin pegawai'),
('Pelanggaran Kode Etik', 'Pelanggaran kode etik dan perilaku'),
('Diskriminasi', 'Tindakan diskriminasi dalam pelayanan'),
('Fraud', 'Kecurangan dalam proses atau transaksi'),
('Pungutan Liar', 'Pungutan tidak resmi atau illegal'),
('Lainnya', 'Kategori lain yang tidak tercantum di atas')
ON CONFLICT DO NOTHING;

-- =====================================================
-- 2. REPORTS TABLE  
-- =====================================================
-- Tabel utama untuk menyimpan data pengaduan

CREATE TABLE IF NOT EXISTS public.reports (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    ticket_number VARCHAR(50) UNIQUE NOT NULL,
    reporter_name VARCHAR(255),
    reporter_contact VARCHAR(255),
    reporter_anonymous BOOLEAN DEFAULT false NOT NULL,
    reported_entity VARCHAR(255),
    category_id UUID NOT NULL REFERENCES public.categories(id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    location VARCHAR(500),
    incident_date DATE,
    file_urls TEXT[], -- Array of file URLs
    status VARCHAR(20) DEFAULT 'baru' NOT NULL CHECK (status IN ('baru', 'diproses', 'selesai', 'ditolak')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- =====================================================
-- 3. REPORT STATUS LOGS TABLE
-- =====================================================
-- Tabel untuk tracking perubahan status pengaduan

CREATE TABLE IF NOT EXISTS public.report_status_logs (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    report_id UUID NOT NULL REFERENCES public.reports(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL CHECK (status IN ('baru', 'diproses', 'selesai', 'ditolak')),
    comment TEXT,
    updated_by VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- =====================================================
-- 4. SETTINGS TABLE
-- =====================================================
-- Tabel untuk menyimpan pengaturan aplikasi (logo, info instansi, dll)

CREATE TABLE IF NOT EXISTS public.settings (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    key VARCHAR(255) UNIQUE NOT NULL,
    value TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Insert default settings
INSERT INTO public.settings (key, value) VALUES
('logo_url', NULL),
('institution_name', 'Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Tegal'),
('institution_short_name', 'DPMPTSP Kab. Tegal'),
('institution_address', 'Jl. Yos Sudarso No. 1, Slawi, Kabupaten Tegal, Jawa Tengah 52411'),
('institution_phone', '(0283) 491234'),
('institution_email', 'dpmptsp@tegalkab.go.id'),
('institution_website', 'https://dpmptsp.tegalkab.go.id'),
('homepage_title', 'Whistle Blowing System DPMPTSP Kab. Tegal'),
('homepage_subtitle', 'Laporkan dugaan pelanggaran, gratifikasi, atau penyimpangan yang terjadi di lingkungan DPMPTSP Kabupaten Tegal. Identitas Anda akan kami jaga kerahasiaannya.'),
('footer_text', '© 2025 Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Tegal')
ON CONFLICT (key) DO NOTHING;

-- =====================================================
-- 5. INDEXES FOR PERFORMANCE
-- =====================================================
-- Index untuk meningkatkan performa query

-- Reports indexes
CREATE INDEX IF NOT EXISTS idx_reports_status ON public.reports(status);
CREATE INDEX IF NOT EXISTS idx_reports_category_id ON public.reports(category_id);
CREATE INDEX IF NOT EXISTS idx_reports_created_at ON public.reports(created_at);
CREATE INDEX IF NOT EXISTS idx_reports_ticket_number ON public.reports(ticket_number);

-- Report status logs indexes  
CREATE INDEX IF NOT EXISTS idx_report_status_logs_report_id ON public.report_status_logs(report_id);
CREATE INDEX IF NOT EXISTS idx_report_status_logs_created_at ON public.report_status_logs(created_at);

-- =====================================================
-- 6. ROW LEVEL SECURITY (RLS)
-- =====================================================
-- Setup keamanan akses data

-- Enable RLS on all tables
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.report_status_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;

-- Categories: Allow read for everyone, write for authenticated users only
DO $ BEGIN
    CREATE POLICY "Categories are viewable by everyone" ON public.categories
        FOR SELECT USING (true);
EXCEPTION WHEN duplicate_object THEN null;
END $;

DO $ BEGIN
    CREATE POLICY "Categories can be managed by authenticated users" ON public.categories
        FOR ALL USING (auth.role() = 'authenticated');
EXCEPTION WHEN duplicate_object THEN null;
END $;

-- Reports: Allow insert for everyone (anonymous reports), read/update for authenticated admin users
DO $ BEGIN
    CREATE POLICY "Reports can be created by anyone" ON public.reports
        FOR INSERT WITH CHECK (true);
EXCEPTION WHEN duplicate_object THEN null;
END $;

DO $ BEGIN
    CREATE POLICY "Reports are viewable by authenticated users" ON public.reports
        FOR SELECT USING (auth.role() = 'authenticated');
EXCEPTION WHEN duplicate_object THEN null;
END $;

DO $ BEGIN
    CREATE POLICY "Reports can be updated by authenticated users" ON public.reports
        FOR UPDATE USING (auth.role() = 'authenticated');
EXCEPTION WHEN duplicate_object THEN null;
END $;

DO $ BEGIN
    CREATE POLICY "Reports can be deleted by authenticated users" ON public.reports
        FOR DELETE USING (auth.role() = 'authenticated');
EXCEPTION WHEN duplicate_object THEN null;
END $;

-- Report Status Logs: Only authenticated users can manage
DO $ BEGIN
    CREATE POLICY "Status logs can be managed by authenticated users" ON public.report_status_logs
        FOR ALL USING (auth.role() = 'authenticated');
EXCEPTION WHEN duplicate_object THEN null;
END $;

-- Settings: Read for everyone, write for authenticated users only
DO $ BEGIN
    CREATE POLICY "Settings are viewable by everyone" ON public.settings
        FOR SELECT USING (true);
EXCEPTION WHEN duplicate_object THEN null;
END $;

DO $ BEGIN
    CREATE POLICY "Settings can be managed by authenticated users" ON public.settings
        FOR ALL USING (auth.role() = 'authenticated');
EXCEPTION WHEN duplicate_object THEN null;
END $;

-- =====================================================
-- 7. FUNCTIONS AND TRIGGERS
-- =====================================================

-- Function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc'::text, now());
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger for reports table
DROP TRIGGER IF EXISTS update_reports_updated_at ON public.reports;
CREATE TRIGGER update_reports_updated_at 
    BEFORE UPDATE ON public.reports 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Trigger for settings table
DROP TRIGGER IF EXISTS update_settings_updated_at ON public.settings;
CREATE TRIGGER update_settings_updated_at 
    BEFORE UPDATE ON public.settings 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- 8. STORAGE BUCKETS FOR FILES
-- =====================================================
-- Create storage buckets for file uploads

-- Bucket untuk file pengaduan (bukti pendukung)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('wbs-files', 'wbs-files', true, 5242880, ARRAY['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'])
ON CONFLICT (id) DO NOTHING;

-- Bucket untuk logo instansi
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('wbs-logos', 'wbs-logos', true, 2097152, ARRAY['image/jpeg', 'image/png', 'image/jpg', 'image/svg+xml'])
ON CONFLICT (id) DO NOTHING;

-- Storage policies untuk WBS files
CREATE POLICY IF NOT EXISTS "WBS files are publicly accessible" ON storage.objects
    FOR SELECT USING (bucket_id = 'wbs-files');

CREATE POLICY IF NOT EXISTS "Anyone can upload WBS files" ON storage.objects
    FOR INSERT WITH CHECK (bucket_id = 'wbs-files');

CREATE POLICY IF NOT EXISTS "Authenticated users can update WBS files" ON storage.objects
    FOR UPDATE USING (auth.role() = 'authenticated' AND bucket_id = 'wbs-files');

CREATE POLICY IF NOT EXISTS "Authenticated users can delete WBS files" ON storage.objects
    FOR DELETE USING (auth.role() = 'authenticated' AND bucket_id = 'wbs-files');

-- Storage policies untuk logos
CREATE POLICY IF NOT EXISTS "Logo files are publicly accessible" ON storage.objects
    FOR SELECT USING (bucket_id = 'wbs-logos');

CREATE POLICY IF NOT EXISTS "Authenticated users can upload logos" ON storage.objects
    FOR INSERT WITH CHECK (auth.role() = 'authenticated' AND bucket_id = 'wbs-logos');

CREATE POLICY IF NOT EXISTS "Authenticated users can update logos" ON storage.objects
    FOR UPDATE USING (auth.role() = 'authenticated' AND bucket_id = 'wbs-logos');

CREATE POLICY IF NOT EXISTS "Authenticated users can delete logos" ON storage.objects
    FOR DELETE USING (auth.role() = 'authenticated' AND bucket_id = 'wbs-logos');

-- =====================================================
-- SETUP COMPLETE!
-- =====================================================
-- 
-- Setelah menjalankan script ini, database WBS siap digunakan:
-- 
-- ✅ Tabel categories dengan data default
-- ✅ Tabel reports untuk pengaduan
-- ✅ Tabel report_status_logs untuk tracking
-- ✅ Tabel settings untuk konfigurasi
-- ✅ Row Level Security (RLS) aktif
-- ✅ Indexes untuk performa
-- ✅ Storage bucket untuk file uploads
-- ✅ Triggers untuk auto-update timestamps
-- 
-- Langkah selanjutnya:
-- 1. Buat user admin di /setup atau via Supabase Auth
-- 2. Test aplikasi dengan mengakses /
-- 3. Login admin di /login
-- 4. Upload logo dan atur settings di /admin/settings
--
-- Selamat! Database WBS DPMPTSP Kab. Tegal siap digunakan! 🎉