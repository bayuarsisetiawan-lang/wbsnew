-- Migration: Storage Setup
-- Created: 2025-01-XX
-- Description: Setup storage buckets and policies for file uploads

-- Create storage bucket for WBS files
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('wbs-files', 'wbs-files', true, 5242880, ARRAY['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'])
ON CONFLICT (id) DO NOTHING;

-- Create storage bucket for logos
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('wbs-logos', 'wbs-logos', true, 2097152, ARRAY['image/jpeg', 'image/png', 'image/jpg', 'image/svg+xml'])
ON CONFLICT (id) DO NOTHING;

-- Storage policies for WBS files
CREATE POLICY IF NOT EXISTS "WBS files are publicly accessible" ON storage.objects
    FOR SELECT USING (bucket_id = 'wbs-files');

CREATE POLICY IF NOT EXISTS "Anyone can upload WBS files" ON storage.objects
    FOR INSERT WITH CHECK (bucket_id = 'wbs-files');

CREATE POLICY IF NOT EXISTS "Authenticated users can update WBS files" ON storage.objects
    FOR UPDATE USING (auth.role() = 'authenticated' AND bucket_id = 'wbs-files');

CREATE POLICY IF NOT EXISTS "Authenticated users can delete WBS files" ON storage.objects
    FOR DELETE USING (auth.role() = 'authenticated' AND bucket_id = 'wbs-files');

-- Storage policies for logos
CREATE POLICY IF NOT EXISTS "Logo files are publicly accessible" ON storage.objects
    FOR SELECT USING (bucket_id = 'wbs-logos');

CREATE POLICY IF NOT EXISTS "Authenticated users can upload logos" ON storage.objects
    FOR INSERT WITH CHECK (auth.role() = 'authenticated' AND bucket_id = 'wbs-logos');

CREATE POLICY IF NOT EXISTS "Authenticated users can update logos" ON storage.objects
    FOR UPDATE USING (auth.role() = 'authenticated' AND bucket_id = 'wbs-logos');

CREATE POLICY IF NOT EXISTS "Authenticated users can delete logos" ON storage.objects
    FOR DELETE USING (auth.role() = 'authenticated' AND bucket_id = 'wbs-logos');