-- Migration: Security Policies and RLS
-- Created: 2025-01-XX
-- Description: Setup Row Level Security and access policies

-- Enable RLS on all tables
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.report_status_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;

-- Categories policies
CREATE POLICY "Categories are viewable by everyone" ON public.categories
    FOR SELECT USING (true);

CREATE POLICY "Categories can be managed by authenticated users" ON public.categories
    FOR ALL USING (auth.role() = 'authenticated');

-- Reports policies
CREATE POLICY "Reports can be created by anyone" ON public.reports
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Reports are viewable by authenticated users" ON public.reports
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Reports can be updated by authenticated users" ON public.reports
    FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Reports can be deleted by authenticated users" ON public.reports
    FOR DELETE USING (auth.role() = 'authenticated');

-- Report status logs policies
CREATE POLICY "Status logs can be managed by authenticated users" ON public.report_status_logs
    FOR ALL USING (auth.role() = 'authenticated');

-- Settings policies
CREATE POLICY "Settings are viewable by everyone" ON public.settings
    FOR SELECT USING (true);

CREATE POLICY "Settings can be managed by authenticated users" ON public.settings
    FOR ALL USING (auth.role() = 'authenticated');