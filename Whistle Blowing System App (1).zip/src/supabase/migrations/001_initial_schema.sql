-- Migration: Initial WBS Schema
-- Created: 2025-01-XX
-- Description: Create all tables and initial data for WBS DPMPTSP Kab. Tegal

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Categories table
CREATE TABLE IF NOT EXISTS public.categories (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Reports table
CREATE TABLE IF NOT EXISTS public.reports (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    ticket_number VARCHAR(50) UNIQUE NOT NULL,
    reporter_name VARCHAR(255),
    reporter_contact VARCHAR(255),
    reporter_anonymous BOOLEAN DEFAULT false NOT NULL,
    reported_entity VARCHAR(255),
    category_id UUID NOT NULL REFERENCES public.categories(id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    location VARCHAR(500),
    incident_date DATE,
    file_urls TEXT[],
    status VARCHAR(20) DEFAULT 'baru' NOT NULL CHECK (status IN ('baru', 'diproses', 'selesai', 'ditolak')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Report status logs table
CREATE TABLE IF NOT EXISTS public.report_status_logs (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    report_id UUID NOT NULL REFERENCES public.reports(id) ON DELETE CASCADE,
    status VARCHAR(20) NOT NULL CHECK (status IN ('baru', 'diproses', 'selesai', 'ditolak')),
    comment TEXT,
    updated_by VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Settings table
CREATE TABLE IF NOT EXISTS public.settings (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    key VARCHAR(255) UNIQUE NOT NULL,
    value TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Insert default categories
INSERT INTO public.categories (name, description) VALUES
('Korupsi', 'Dugaan tindak pidana korupsi'),
('Penyalahgunaan Wewenang', 'Penyalahgunaan jabatan atau wewenang'),
('Pelanggaran Disiplin', 'Pelanggaran disiplin pegawai'),
('Pelanggaran Kode Etik', 'Pelanggaran kode etik dan perilaku'),
('Diskriminasi', 'Tindakan diskriminasi dalam pelayanan'),
('Fraud', 'Kecurangan dalam proses atau transaksi'),
('Pungutan Liar', 'Pungutan tidak resmi atau illegal'),
('Lainnya', 'Kategori lain yang tidak tercantum di atas')
ON CONFLICT DO NOTHING;

-- Insert default settings
INSERT INTO public.settings (key, value) VALUES
('logo_url', NULL),
('institution_name', 'Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Tegal'),
('institution_short_name', 'DPMPTSP Kab. Tegal'),
('institution_address', 'Jl. Yos Sudarso No. 1, Slawi, Kabupaten Tegal, Jawa Tengah 52411'),
('institution_phone', '(0283) 491234'),
('institution_email', 'dpmptsp@tegalkab.go.id'),
('institution_website', 'https://dpmptsp.tegalkab.go.id'),
('homepage_title', 'Whistle Blowing System DPMPTSP Kab. Tegal'),
('homepage_subtitle', 'Laporkan dugaan pelanggaran, gratifikasi, atau penyimpangan yang terjadi di lingkungan DPMPTSP Kabupaten Tegal. Identitas Anda akan kami jaga kerahasiaannya.'),
('footer_text', '© 2025 Dinas Penanaman Modal dan Pelayanan Terpadu Satu Pintu Kabupaten Tegal')
ON CONFLICT (key) DO NOTHING;