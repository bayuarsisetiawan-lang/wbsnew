import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

app.use('*', logger(console.log));

// Initialize Supabase admin client
const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// ============================================
// HELPER FUNCTIONS
// ============================================

function generateTicketNumber(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const random = Math.floor(Math.random() + 10000).toString().padStart(4, '0');
  
  return `WBS-${year}${month}${day}-${random}`;
}

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

function getDefaultCategories() {
  return [
    { id: '1', name: 'Korupsi', description: 'Tindakan korupsi, gratifikasi, atau penyalahgunaan dana' },
    { id: '2', name: 'Penyalahgunaan Wewenang', description: 'Penyalahgunaan jabatan atau kewenangan' },
    { id: '3', name: 'Pelanggaran Disiplin', description: 'Pelanggaran disiplin pegawai atau aturan internal' },
    { id: '4', name: 'Pelanggaran Kode Etik', description: 'Pelanggaran kode etik dan norma perilaku' },
    { id: '5', name: 'Diskriminasi', description: 'Tindakan diskriminasi atau pelecehan' },
    { id: '6', name: 'Fraud', description: 'Penipuan atau kecurangan dalam proses kerja' },
    { id: '7', name: 'Lainnya', description: 'Pengaduan lainnya yang tidak termasuk kategori di atas' },
  ];
}

// Initialize default categories on startup
async function initializeData() {
  try {
    const categories = await kv.get('categories');
    if (!categories) {
      console.log('Initializing default categories...');
      await kv.set('categories', getDefaultCategories());
    }
    
    const reports = await kv.get('reports:all');
    if (!reports) {
      console.log('Initializing empty reports list...');
      await kv.set('reports:all', []);
    }
    
    console.log('Data store initialized successfully');
  } catch (error) {
    console.error('Failed to initialize data:', error);
  }
}

initializeData();

// ============================================
// ROUTES
// ============================================

app.get('/make-server-7bc260f6/health', (c) => {
  return c.json({ status: 'ok', message: 'WBS Server is running' });
});

// ============================================
// CATEGORIES
// ============================================

app.get('/make-server-7bc260f6/categories', async (c) => {
  try {
    let categories = await kv.get('categories');
    
    if (!categories || categories.length === 0) {
      categories = getDefaultCategories();
      await kv.set('categories', categories);
    }
    
    return c.json({ categories });
  } catch (error) {
    console.error('Get categories error:', error);
    return c.json({ categories: getDefaultCategories() });
  }
});

app.post('/make-server-7bc260f6/categories', async (c) => {
  try {
    const { name, description } = await c.req.json();
    
    if (!name) {
      return c.json({ error: 'Category name is required' }, 400);
    }
    
    const categories = await kv.get('categories') || getDefaultCategories();
    const newCategory = {
      id: generateId(),
      name,
      description: description || '',
    };
    
    categories.push(newCategory);
    await kv.set('categories', categories);
    
    return c.json({ category: newCategory });
  } catch (error) {
    console.error('Create category error:', error);
    return c.json({ error: 'Failed to create category' }, 500);
  }
});

app.put('/make-server-7bc260f6/categories/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const { name, description } = await c.req.json();
    
    const categories = await kv.get('categories') || [];
    const index = categories.findIndex((cat: any) => cat.id === id);
    
    if (index === -1) {
      return c.json({ error: 'Category not found' }, 404);
    }
    
    categories[index] = {
      ...categories[index],
      name: name || categories[index].name,
      description: description !== undefined ? description : categories[index].description,
    };
    
    await kv.set('categories', categories);
    
    return c.json({ category: categories[index] });
  } catch (error) {
    console.error('Update category error:', error);
    return c.json({ error: 'Failed to update category' }, 500);
  }
});

app.delete('/make-server-7bc260f6/categories/:id', async (c) => {
  try {
    const id = c.req.param('id');
    
    const categories = await kv.get('categories') || [];
    const filtered = categories.filter((cat: any) => cat.id !== id);
    
    await kv.set('categories', filtered);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Delete category error:', error);
    return c.json({ error: 'Failed to delete category' }, 500);
  }
});

// ============================================
// REPORTS
// ============================================

app.post('/make-server-7bc260f6/reports', async (c) => {
  try {
    const data = await c.req.json();
    
    if (!data.category_id || !data.description) {
      return c.json({ error: 'Missing required fields' }, 400);
    }
    
    const ticketNumber = generateTicketNumber();
    const categories = await kv.get('categories') || getDefaultCategories();
    const category = categories.find((cat: any) => cat.id === data.category_id);
    
    const report = {
      id: generateId(),
      ticket_number: ticketNumber,
      reporter_name: data.reporter_name || null,
      reporter_contact: data.reporter_contact || null,
      reporter_anonymous: data.reporter_anonymous || false,
      reported_entity: data.reported_entity || null,
      category_id: data.category_id,
      category_name: category?.name || 'Unknown',
      description: data.description,
      location: data.location || null,
      incident_date: data.incident_date || null,
      file_urls: data.file_urls || null,
      status: 'baru',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      status_history: [
        {
          status: 'baru',
          comment: 'Laporan diterima',
          updated_by: 'System',
          timestamp: new Date().toISOString(),
        },
      ],
    };
    
    // Save individual report
    await kv.set(`report:${ticketNumber}`, report);
    
    // Add to reports list
    const allReports = await kv.get('reports:all') || [];
    allReports.unshift(ticketNumber);
    await kv.set('reports:all', allReports);
    
    return c.json({ report });
  } catch (error) {
    console.error('Create report error:', error);
    return c.json({ error: 'Failed to create report' }, 500);
  }
});

app.get('/make-server-7bc260f6/reports', async (c) => {
  try {
    const status = c.req.query('status');
    const limit = c.req.query('limit');
    const category_id = c.req.query('category_id');
    
    const allTickets = await kv.get('reports:all') || [];
    const reports = [];
    
    for (const ticket of allTickets) {
      const report = await kv.get(`report:${ticket}`);
      if (report) {
        // Apply filters
        if (status && report.status !== status) continue;
        if (category_id && report.category_id !== category_id) continue;
        
        reports.push(report);
        
        if (limit && reports.length >= parseInt(limit)) break;
      }
    }
    
    return c.json({ reports });
  } catch (error) {
    console.error('Get reports error:', error);
    return c.json({ reports: [] });
  }
});

app.get('/make-server-7bc260f6/reports/stats', async (c) => {
  try {
    const allTickets = await kv.get('reports:all') || [];
    const stats = {
      total: 0,
      baru: 0,
      diproses: 0,
      selesai: 0,
      ditolak: 0,
    };
    
    for (const ticket of allTickets) {
      const report = await kv.get(`report:${ticket}`);
      if (report) {
        stats.total++;
        if (report.status === 'baru') stats.baru++;
        else if (report.status === 'diproses') stats.diproses++;
        else if (report.status === 'selesai') stats.selesai++;
        else if (report.status === 'ditolak') stats.ditolak++;
      }
    }
    
    return c.json({ stats });
  } catch (error) {
    console.error('Get stats error:', error);
    return c.json({ stats: { total: 0, baru: 0, diproses: 0, selesai: 0, ditolak: 0 } });
  }
});

app.get('/make-server-7bc260f6/reports/:ticket', async (c) => {
  try {
    const ticket = c.req.param('ticket');
    const report = await kv.get(`report:${ticket}`);
    
    if (!report) {
      return c.json({ error: 'Report not found' }, 404);
    }
    
    return c.json({ report });
  } catch (error) {
    console.error('Get report error:', error);
    return c.json({ error: 'Failed to get report' }, 500);
  }
});

app.put('/make-server-7bc260f6/reports/:ticket/status', async (c) => {
  try {
    const ticket = c.req.param('ticket');
    const { status, comment, updated_by } = await c.req.json();
    
    const report = await kv.get(`report:${ticket}`);
    
    if (!report) {
      return c.json({ error: 'Report not found' }, 404);
    }
    
    report.status = status;
    report.updated_at = new Date().toISOString();
    report.status_history = report.status_history || [];
    report.status_history.unshift({
      status,
      comment: comment || '',
      updated_by: updated_by || 'Admin',
      timestamp: new Date().toISOString(),
    });
    
    await kv.set(`report:${ticket}`, report);
    
    return c.json({ report });
  } catch (error) {
    console.error('Update report status error:', error);
    return c.json({ error: 'Failed to update report status' }, 500);
  }
});

app.delete('/make-server-7bc260f6/reports/:ticket', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userRole = user.user_metadata?.role;
    if (userRole !== 'admin') {
      return c.json({ error: 'Forbidden' }, 403);
    }
    
    const ticket = c.req.param('ticket');
    
    // Remove from reports list
    const allTickets = await kv.get('reports:all') || [];
    const filtered = allTickets.filter((t: string) => t !== ticket);
    await kv.set('reports:all', filtered);
    
    // Delete report data
    await kv.del(`report:${ticket}`);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Delete report error:', error);
    return c.json({ error: 'Failed to delete report' }, 500);
  }
});

// ============================================
// AUTH
// ============================================

// Check if any admin exists
app.get('/make-server-7bc260f6/auth/check-admin', async (c) => {
  try {
    const { data: { users }, error } = await supabase.auth.admin.listUsers();
    
    if (error) {
      console.error('Check admin error:', error);
      return c.json({ error: error.message }, 400);
    }
    
    const adminExists = users.some(u => u.user_metadata?.role === 'admin');
    
    return c.json({ adminExists });
  } catch (error) {
    console.error('Check admin error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Setup first admin (only works if no admin exists)
app.post('/make-server-7bc260f6/auth/setup-admin', async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    if (!email || !password || !name) {
      return c.json({ error: 'Email, password, dan nama wajib diisi' }, 400);
    }
    
    // Check if admin already exists
    const { data: { users }, error: listError } = await supabase.auth.admin.listUsers();
    
    if (listError) {
      console.error('List users error:', listError);
      return c.json({ error: listError.message }, 400);
    }
    
    const adminExists = users.some(u => u.user_metadata?.role === 'admin');
    
    if (adminExists) {
      return c.json({ error: 'Admin sudah ada, gunakan halaman login' }, 403);
    }
    
    // Create first admin
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role: 'admin' },
      email_confirm: true,
    });

    if (error) {
      console.error('Setup admin error:', error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ 
      success: true, 
      message: 'Admin pertama berhasil dibuat! Silakan login.',
      user: {
        id: data.user.id,
        email: data.user.email,
        name,
        role: 'admin',
      }
    });
  } catch (error) {
    console.error('Setup admin error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

app.post('/make-server-7bc260f6/auth/signup', async (c) => {
  try {
    const { email, password, name, role } = await c.req.json();
    
    if (!email || !password || !name || !role) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    if (!['admin', 'display'].includes(role)) {
      return c.json({ error: 'Invalid role' }, 400);
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role },
      email_confirm: true,
    });

    if (error) {
      console.error('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ 
      success: true, 
      message: 'User created successfully',
      user: {
        id: data.user.id,
        email: data.user.email,
        name,
        role,
      }
    });
  } catch (error) {
    console.error('Signup error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

app.get('/make-server-7bc260f6/auth/users', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userRole = user.user_metadata?.role;
    if (userRole !== 'admin') {
      return c.json({ error: 'Forbidden' }, 403);
    }

    const { data: { users }, error } = await supabase.auth.admin.listUsers();

    if (error) {
      console.error('List users error:', error);
      return c.json({ error: error.message }, 400);
    }

    const formattedUsers = users.map(u => ({
      id: u.id,
      email: u.email,
      name: u.user_metadata?.name,
      role: u.user_metadata?.role,
      created_at: u.created_at,
    }));

    return c.json({ users: formattedUsers });
  } catch (error) {
    console.error('List users error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

app.delete('/make-server-7bc260f6/auth/users/:userId', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userRole = user.user_metadata?.role;
    if (userRole !== 'admin') {
      return c.json({ error: 'Forbidden' }, 403);
    }

    const userId = c.req.param('userId');
    
    const { error } = await supabase.auth.admin.deleteUser(userId);

    if (error) {
      console.error('Delete user error:', error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ success: true, message: 'User deleted successfully' });
  } catch (error) {
    console.error('Delete user error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Note: Logo stored as base64 in settings, no storage bucket needed

// ============================================
// SETTINGS
// ============================================

app.get('/make-server-7bc260f6/settings', async (c) => {
  try {
    const settings = await kv.get('app_settings');
    
    return c.json({ settings: settings || {} });
  } catch (error) {
    console.error('Get settings error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

app.post('/make-server-7bc260f6/settings', async (c) => {
  try {
    console.log('Settings update request received');
    
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      console.error('Settings update failed: No access token provided');
      return c.json({ error: 'Tidak ada access token. Silakan login kembali.' }, 401);
    }

    console.log('Verifying user authentication...');
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (authError) {
      console.error('Settings update failed: Auth error:', authError);
      return c.json({ error: 'Sesi login tidak valid. Silakan login kembali.' }, 401);
    }
    
    if (!user) {
      console.error('Settings update failed: No user found');
      return c.json({ error: 'User tidak ditemukan. Silakan login kembali.' }, 401);
    }

    console.log('User authenticated:', user.email);

    const userRole = user.user_metadata?.role;
    console.log('User role:', userRole);
    
    if (userRole !== 'admin') {
      console.error('Settings update failed: User is not admin. Role:', userRole);
      return c.json({ error: 'Hanya admin yang dapat mengubah pengaturan.' }, 403);
    }

    const body = await c.req.json();
    console.log('Request body received:', Object.keys(body));
    
    const { settings } = body;
    
    if (!settings) {
      console.error('Settings update failed: No settings data in body');
      return c.json({ error: 'Data pengaturan tidak valid' }, 400);
    }

    console.log('Saving settings to KV store...');
    await kv.set('app_settings', settings);
    console.log('Settings saved successfully');
    
    return c.json({ 
      success: true, 
      message: 'Pengaturan berhasil disimpan' 
    });
  } catch (error) {
    console.error('Update settings error:', error);
    return c.json({ 
      error: `Gagal menyimpan pengaturan: ${error.message || 'Internal server error'}` 
    }, 500);
  }
});

Deno.serve(app.fetch);