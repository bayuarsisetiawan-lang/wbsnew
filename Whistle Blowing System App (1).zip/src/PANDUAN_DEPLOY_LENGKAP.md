# 🚀 PANDUAN DEPLOY WEBSITE WBS - BUDGET 100RB

## 💰 BREAKDOWN BIAYA
- **Domain .com**: Rp 50.000 - 80.000/tahun
- **Hosting**: GRATIS (menggunakan Netlify)
- **Total**: Rp 50.000 - 80.000 (sisanya buat jajan 😊)

## 📋 PERSIAPAN SEBELUM DEPLOY

### 1. Buat Akun GitHub (GRATIS)
1. Buka https://github.com
2. Klik "Sign up" 
3. Isi username, email, password
4. Verifikasi email

### 2. Upload Project ke GitHub
1. Login ke GitHub
2. Klik tombol hijau "New" atau "Create repository"
3. Nama repository: `wbs-dinas-pmptsp-tegal`
4. Centang "Add a README file"
5. Klik "Create repository"

## 🌐 CARA UPLOAD CODE KE GITHUB

### Opsi 1: Upload Manual (Paling Mudah untuk Pemula)
1. Download semua file project sebagai ZIP
2. Extract file ZIP
3. Di halaman GitHub repository, klik "uploading an existing file"
4. Drag and drop semua folder dan file
5. Scroll ke bawah, tulis commit message: "Initial upload WBS system"
6. Klik "Commit changes"

### Opsi 2: GitHub Desktop (Lebih Profesional)
1. Download GitHub Desktop dari https://desktop.github.com
2. Install dan login dengan akun GitHub
3. Clone repository yang sudah dibuat
4. Copy paste semua file project ke folder repository
5. Commit dan push

## 🚀 DEPLOY KE NETLIFY (GRATIS)

### 1. Buat Akun Netlify
1. Buka https://netlify.com
2. Klik "Sign up"
3. Pilih "Sign up with GitHub" (lebih mudah)
4. Authorize Netlify mengakses GitHub

### 2. Deploy dari GitHub
1. Di dashboard Netlify, klik "New site from Git"
2. Pilih "GitHub"
3. Cari dan pilih repository `wbs-dinas-pmptsp-tegal`
4. **Build settings:**
   - Build command: `npm run build`
   - Publish directory: `dist`
5. Klik "Deploy site"

### 3. Tunggu Proses Build
- Proses build sekitar 2-5 menit
- Jika berhasil, akan dapat URL seperti: `https://random-name-123456.netlify.app`
- Jika gagal, lihat error log di bagian "Deploys"

## 🎯 BELI DOMAIN .COM

### Rekomendasi Provider Domain Murah:
1. **Niagahoster** (Rp 50.000/tahun untuk .com)
2. **Dewaweb** (Rp 55.000/tahun)
3. **IDCloudHost** (Rp 60.000/tahun)
4. **Hostinger** (Rp 65.000/tahun)

### Langkah Beli Domain:
1. Pilih salah satu provider di atas
2. Cek ketersediaan domain (contoh: `wbs-pmptsp-tegal.com`)
3. Tambahkan ke keranjang
4. Checkout dan bayar
5. **PENTING**: Catat informasi DNS/Nameserver

## 🔗 HUBUNGKAN DOMAIN KE NETLIFY

### 1. Tambah Custom Domain di Netlify
1. Di dashboard Netlify, pilih site yang sudah di-deploy
2. Klik "Domain settings"
3. Klik "Add custom domain"
4. Masukkan domain yang sudah dibeli (contoh: `wbs-pmptsp-tegal.com`)
5. Klik "Verify"

### 2. Setting DNS di Provider Domain
1. Login ke control panel provider domain
2. Cari menu "DNS Management" atau "Nameserver"
3. Ganti DNS record dengan:
   ```
   Type: A
   Host: @
   Value: 75.2.60.5

   Type: CNAME  
   Host: www
   Value: [nama-site].netlify.app
   ```
4. Save perubahan

### 3. Aktivasi HTTPS di Netlify
1. Kembali ke Netlify dashboard
2. Di "Domain settings", scroll ke "HTTPS"
3. Klik "Verify DNS configuration"
4. Tunggu proses verifikasi (15-60 menit)
5. Setelah terverifikasi, SSL akan aktif otomatis

## ⚙️ KONFIGURASI KHUSUS WBS

### 1. Environment Variables di Netlify
1. Di dashboard Netlify, pilih site
2. Klik "Site settings" → "Environment variables"
3. Tambahkan variable berikut:
   ```
   NODE_ENV = production
   VITE_APP_NAME = WBS Dinas PMPTSP Kab.Tegal
   VITE_SUPABASE_URL = [URL_SUPABASE]
   VITE_SUPABASE_ANON_KEY = [KEY_SUPABASE]
   ```

### 2. Redirect Rules
1. Buat file `_redirects` di folder `public`:
   ```
   /*    /index.html   200
   ```

### 3. Headers untuk Security
1. Buat file `_headers` di folder `public`:
   ```
   /*
     X-Frame-Options: DENY
     X-Content-Type-Options: nosniff
     X-XSS-Protection: 1; mode=block
     Referrer-Policy: strict-origin-when-cross-origin
   ```

## 🎨 CUSTOMIZATION LOGO & BRANDING

### Upload Logo Dinas
1. Siapkan logo dalam format PNG (ukuran 200x60px)
2. Upload via admin panel WBS:
   - Login sebagai Super Admin
   - Menu Settings → Pengaturan Tampilan
   - Upload logo baru
   - Save settings

### Ganti Informasi Kontak
1. Login admin panel
2. Settings → Informasi Kontak
3. Update:
   - Nama instansi: "Dinas PMPTSP Kabupaten Tegal"
   - Alamat lengkap
   - Nomor telepon
   - Email resmi
   - Website resmi

## 🔒 KEAMANAN PRODUCTION

### 1. Ganti Password Default
- Super Admin: Login dan ganti password
- Admin dan Display: Buat user baru, hapus default

### 2. Backup Rutin
1. Setup auto-backup di Netlify:
   - Site settings → Build & deploy
   - Build hooks → Add build hook
   - Trigger rebuild setiap minggu

### 3. Monitoring
1. Setup Google Analytics (opsional)
2. Monitoring uptime dengan UptimeRobot (gratis)

## 📱 TESTING SEBELUM GO-LIVE

### Checklist Testing:
- [ ] Buka website di browser desktop
- [ ] Test di mobile (responsive)
- [ ] Coba buat pengaduan sebagai public
- [ ] Test login admin
- [ ] Test dashboard display
- [ ] Cek semua link navigation
- [ ] Test upload file
- [ ] Cek notifikasi email (jika ada)

## 🚀 GO-LIVE CHECKLIST

- [ ] Domain sudah pointing ke Netlify
- [ ] SSL certificate aktif (https://)
- [ ] Environment variables sudah diset
- [ ] Password default sudah diganti
- [ ] Logo dan branding sudah diupdate
- [ ] Contact information sudah diupdate
- [ ] Testing lengkap sudah selesai
- [ ] Backup system sudah disetup

## 🆘 TROUBLESHOOTING UMUM

### Website tidak bisa diakses:
1. Cek DNS propagation di https://dnschecker.org
2. Tunggu 24-48 jam untuk propagasi penuh
3. Clear cache browser (Ctrl+F5)

### Build gagal di Netlify:
1. Cek build log untuk error detail
2. Pastikan semua dependencies terinstall
3. Cek environment variables

### Domain tidak connect:
1. Pastikan DNS record sudah benar
2. Cek di provider domain apakah sudah save
3. Tunggu propagasi DNS

## 📞 SUPPORT

Jika ada masalah:
1. Cek error log di Netlify dashboard
2. Screenshot error untuk troubleshooting
3. Hubungi support provider domain jika DNS bermasalah

---

**🎉 SELAMAT! Website WBS Anda sudah live di domain .com dengan budget di bawah 100rb!**

### Akses Website:
- **Public**: https://wbs-pmptsp-tegal.com
- **Admin**: https://wbs-pmptsp-tegal.com/login
- **Display**: https://wbs-pmptsp-tegal.com/display/dashboard

### Credential Default (GANTI SEGERA):
- **Super Admin**: admin / admin123
- **Display**: display / display123