# 🎯 DEPLOY DRAG & DROP - TUTORIAL VISUAL

## ⚡ **PALING SIMPLE: NETLIFY DROP**

**Cuma 3 langkah:**
1. Build project
2. Drag & drop folder
3. Website LIVE!

---

## 🔨 **STEP 1: BUILD PROJECT**

### Buka Terminal/Command Prompt:
**Windows**: Win+R → ketik `cmd` → Enter  
**Mac**: Cmd+Space → ketik `terminal` → Enter

### Masuk ke Folder Project:
```bash
cd path/to/wbs-project
```

### Install & Build:
```bash
# Install dependencies (1x doang)
npm install

# Build website untuk production
npm run build
```

**✅ HASIL**: Folder `dist/` terbuat berisi website siap deploy

---

## 🚀 **STEP 2: DRAG & DROP DEPLOY**

### 2.1 Buka Netlify Drop:
1. **Browser baru** → ketik: `drop.netlify.com`
2. **Enter** → halaman drag drop terbuka
3. **Terlihat kotak besar** bertulisan "Drag and drop your site output folder here"

### 2.2 Siapkan Folder:
1. **Buka Windows Explorer/Finder**
2. **Navigate** ke folder project WBS
3. **Cari folder `dist/`** (hasil build tadi)
4. **Buka folder `dist/`** → pastikan ada file `index.html`

### 2.3 Drag & Drop:
1. **Select folder `dist/`** (klik sekali)
2. **Drag** folder `dist/` ke browser Netlify
3. **Drop** di area kotak drag & drop
4. **Upload otomatis** mulai (progress bar muncul)

### 2.4 Tunggu Deploy:
- **Upload**: 30 detik - 2 menit
- **Build**: 30 detik
- **Deploy**: 10 detik
- **✅ SUCCESS**: URL website muncul!

**CONTOH URL**: `https://wonderful-cupcake-123456.netlify.app`

---

## 🌐 **STEP 3: TEST WEBSITE**

### 3.1 Akses Website:
1. **Klik URL** yang muncul di Netlify
2. **Website WBS terbuka** di tab baru
3. **Test navigasi** - semua menu jalan

### 3.2 Test Fitur:
- **Home page**: ✅ loading
- **Buat Aduan**: ✅ form bisa diisi
- **Admin Login**: `/login` → username: `admin`, password: `admin123`
- **Dashboard**: ✅ statistik muncul
- **Mobile**: buka di HP → ✅ responsive

**✅ WEBSITE SUDAH LIVE & BERFUNGSI!**

---

## 💎 **STEP 4: CUSTOM DOMAIN (OPTIONAL)**

### 4.1 Beli Domain:
1. **Niagahoster.co.id**
2. **Cari domain**: `wbs-tegal.com` 
3. **Bayar**: Rp 50k/tahun

### 4.2 Connect Domain:
1. **Di halaman Netlify website**, klik **"Domain settings"**
2. **"Add custom domain"** → masukkan: `wbs-tegal.com`
3. **"Verify"** → Netlify kasih DNS info
4. **Login Niagahoster** → setting DNS sesuai instruksi
5. **Tunggu 1-24 jam** → website live di domain sendiri!

---

## 🔄 **UPDATE WEBSITE (KALAU ADA PERUBAHAN)**

### Cara Update Simple:
1. **Edit code** di project
2. **Build ulang**: `npm run build`
3. **Drag drop folder `dist/` baru** ke Netlify drop
4. **Website update otomatis!**

### Auto-Deploy Setup:
1. **Netlify dashboard** → site settings
2. **"Deploy settings"** → "Deploy key"
3. **Copy URL deploy hook**
4. **Bookmark** untuk update cepat

---

## 📊 **ALTERNATIF DRAG & DROP LAIN:**

### **VERCEL** (vercel.com):
1. **Login** dengan Google/GitHub
2. **"Import Project"** → **"Browse"**
3. **Upload folder `dist/`**
4. **Deploy** → LIVE!

### **FIREBASE** (console.firebase.google.com):
1. **Create project**
2. **Hosting** → **"Get started"**
3. **Upload files** → folder `dist/`
4. **Deploy** → LIVE!

### **SURGE.SH** (Terminal):
```bash
npm install -g surge
cd dist/
surge
```

---

## 🎯 **TIPS & TRICKS:**

### Optimize Build:
```bash
# Build dengan optimization
npm run build -- --mode production

# Cek ukuran file hasil build
ls -la dist/
```

### Compress Files:
- **Netlify otomatis** compress files
- **GZIP enable** by default
- **Assets optimization** automatic

### Performance:
- **CDN global** dari Netlify
- **HTTPS** otomatis aktif
- **Caching** optimal setup

---

## 🚨 **TROUBLESHOOTING DRAG & DROP:**

### Build Gagal:
```bash
# Force clean install
rm -rf node_modules package-lock.json
npm install
npm run build
```

### Upload Gagal:
- **Internet slow**: Coba wifi/koneksi lain
- **File besar**: Build hasilnya >500MB? Ada yang salah
- **Browser**: Coba Chrome/Firefox terbaru

### Website Blank:
- **Cek file `dist/index.html`** ada isi atau kosong
- **Console browser**: F12 → Console → ada error apa
- **Re-build**: `npm run build` lagi

### Domain Not Working:
- **DNS propagation**: tunggu 1-24 jam
- **Clear browser cache**: Ctrl+Shift+Delete
- **Test DNS**: `nslookup domain-anda.com`

---

## ✅ **FINAL CHECKLIST:**

**Build Success:**
- [ ] `npm install` no error
- [ ] `npm run build` success  
- [ ] Folder `dist/` ada & berisi files
- [ ] File `dist/index.html` ada

**Deploy Success:**
- [ ] `drop.netlify.com` terbuka
- [ ] Drag & drop berhasil
- [ ] Upload complete 100%
- [ ] URL website dikasih Netlify

**Website Working:**
- [ ] URL bisa diakses
- [ ] Home page loading
- [ ] Navigation working
- [ ] Login admin bisa
- [ ] Mobile responsive

**Domain (Optional):**
- [ ] Domain dibeli
- [ ] DNS setting done
- [ ] Website live di domain sendiri

---

## 🎉 **SELAMAT! WEBSITE LIVE!**

**🌐 Public URL**: Website WBS live di internet  
**🔐 Admin Panel**: `/login` untuk kelola pengaduan  
**📱 Mobile Ready**: Responsive di semua device  
**🔒 Secure**: HTTPS aktif otomatis  
**💰 Budget**: Cuma Rp 50k untuk domain  

**TOTAL WAKTU: 15-30 MENIT MAKSIMAL!**

**Website profesional WBS Dinas PMPTSP Kab.Tegal sudah siap melayani masyarakat! 🚀**