# 📚 Daftar Isi Dokumentasi WBS

Selamat datang di sistem Whistle Blowing System (WBS) untuk Dinas PMPTSP Kabupaten Tegal!

---

## 🎯 Mulai dari Mana?

### Jika Anda USER BARU (Belum pernah setup):
→ Baca **[MULAI_DI_SINI.md](./MULAI_DI_SINI.md)** (3 langkah mudah)

### Jika Anda DEVELOPER/IT:
→ Baca **[QUICK_START.md](./QUICK_START.md)** (technical quick reference)

### Jika Anda Butuh KREDENSIAL/INFO LOGIN:
→ Baca **[INFO_LOGIN.txt](./INFO_LOGIN.txt)** atau **[KREDENSIAL_DEFAULT.md](./KREDENSIAL_DEFAULT.md)**

### Jika Anda Ingin TUTORIAL LENGKAP:
→ Baca **[PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md)**

---

## 📖 Semua Dokumentasi

### 🚀 Getting Started (Mulai Di Sini!)

| File | Deskripsi | Untuk Siapa | Estimasi Waktu |
|------|-----------|-------------|-----------------|
| **[MULAI_DI_SINI.md](./MULAI_DI_SINI.md)** | Panduan super cepat 3 langkah | User baru, non-teknis | 2 menit |
| **[INFO_LOGIN.txt](./INFO_LOGIN.txt)** | Informasi kredensial & login (text format) | Semua user | 1 menit |
| **[QUICK_START.md](./QUICK_START.md)** | Quick reference untuk developer | Developer, IT Admin | 5 menit |

### 📚 Panduan Lengkap

| File | Deskripsi | Isi Utama |
|------|-----------|-----------|
| **[README.md](./README.md)** | Overview sistem & quick start | Fitur, tech stack, setup |
| **[PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md)** | Manual lengkap semua fitur | Tutorial detail, FAQ, troubleshooting |
| **[KREDENSIAL_DEFAULT.md](./KREDENSIAL_DEFAULT.md)** | Panduan kredensial & keamanan | Setup admin, security best practices |

### 📝 Informasi Tambahan

| File | Deskripsi | Kapan Dibaca |
|------|-----------|--------------|
| **[TROUBLESHOOTING.md](./TROUBLESHOOTING.md)** | 🔧 Panduan mengatasi error | Saat ada masalah/error ⚠️ |
| **[CHANGELOG.md](./CHANGELOG.md)** | Riwayat perubahan sistem | Ingin tahu update terbaru |
| **[TECHNICAL_NOTES.md](./TECHNICAL_NOTES.md)** | Catatan teknis & design decisions | Developer yang ingin detail implementasi |
| **[Attributions.md](./Attributions.md)** | Credits & acknowledgments | Info library & dependencies |

---

## 🗺️ Roadmap Belajar

### Level 1: Pemula (Setup Awal)
1. ✅ Baca [MULAI_DI_SINI.md](./MULAI_DI_SINI.md)
2. ✅ Setup admin di `/setup`
3. ✅ Login pertama kali
4. ✅ Lihat-lihat dashboard

### Level 2: Intermediate (Kustomisasi)
1. ✅ Baca bagian "Customization" di [PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md)
2. ✅ Upload logo instansi
3. ✅ Ubah nama & kontak instansi
4. ✅ Tambah kategori custom

### Level 3: Advanced (Kelola Sistem)
1. ✅ Buat user display untuk monitoring
2. ✅ Kelola pengaduan masuk
3. ✅ Export data (future feature)
4. ✅ Monitoring & maintenance

---

## 📋 Checklist Setup

Gunakan checklist ini untuk memastikan sistem sudah siap:

- [ ] **Baca** MULAI_DI_SINI.md atau QUICK_START.md
- [ ] **Buka** aplikasi di browser
- [ ] **Kunjungi** `/setup` untuk buat admin pertama
- [ ] **Isi** form dengan data admin (nama, email, password)
- [ ] **Submit** form dan tunggu redirect ke login
- [ ] **Login** dengan kredensial yang baru dibuat
- [ ] **Verifikasi** masuk ke dashboard admin
- [ ] **(Opsional)** Upload logo di `/admin/settings`
- [ ] **(Opsional)** Ubah nama instansi di `/admin/settings`
- [ ] **(Opsional)** Update kontak di `/admin/settings`
- [ ] **(Opsional)** Tambah kategori di `/admin/kategori`
- [ ] **(Opsional)** Buat user display di `/admin/users`
- [ ] **Tes** buat aduan dari halaman publik `/buat-aduan`
- [ ] **Tes** pantau aduan di `/pantau-aduan`
- [ ] **Tes** kelola aduan dari dashboard admin
- [ ] **Share** link website ke masyarakat
- [ ] **Selesai!** Sistem siap digunakan 🎉

---

## 🔍 Cari Informasi Spesifik

### Setup & Instalasi
- Cara buat admin pertama → [MULAI_DI_SINI.md](./MULAI_DI_SINI.md#langkah-1-buat-admin-pertama)
- Kredensial default → [INFO_LOGIN.txt](./INFO_LOGIN.txt)
- Setup teknis → [QUICK_START.md](./QUICK_START.md)

### Penggunaan Sistem
- Buat pengaduan → [PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md#membuat-laporan-baru)
- Pantau status → [PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md#memantau-status-laporan)
- Dashboard admin → [PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md#dashboard-admin)

### Kustomisasi
- Upload logo → [MULAI_DI_SINI.md](./MULAI_DI_SINI.md#upload-logo-instansi)
- Ubah nama instansi → [MULAI_DI_SINI.md](./MULAI_DI_SINI.md#ubah-nama-instansi)
- Kelola kategori → [PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md#kelola-kategori)

### User Management
- Buat user display → [KREDENSIAL_DEFAULT.md](./KREDENSIAL_DEFAULT.md#membuat-user-display)
- Role & permissions → [PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md#role--permissions)

### Troubleshooting
- Lupa password → [KREDENSIAL_DEFAULT.md](./KREDENSIAL_DEFAULT.md#lupa-password-admin)
- Tidak bisa login → [PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md#tidak-bisa-login)
- Error & debugging → [QUICK_START.md](./QUICK_START.md#troubleshooting)

### Keamanan
- Password policy → [KREDENSIAL_DEFAULT.md](./KREDENSIAL_DEFAULT.md#password-policy)
- Best practices → [KREDENSIAL_DEFAULT.md](./KREDENSIAL_DEFAULT.md#best-practices)

### Informasi Teknis
- Tech stack → [README.md](./README.md#tech-stack)
- API endpoints → [QUICK_START.md](./QUICK_START.md#api-endpoints)
- Project structure → [QUICK_START.md](./QUICK_START.md#project-structure)

---

## 🆘 Bantuan & Support

### Jika Mengalami Masalah:

1. **Cek dokumentasi** yang relevan dari daftar di atas
2. **Lihat console browser** (tekan F12) untuk error logs
3. **Cek Supabase Dashboard** untuk monitoring backend
4. **Baca bagian Troubleshooting** di [PANDUAN_PENGGUNAAN.md](./PANDUAN_PENGGUNAAN.md)
5. **Hubungi administrator** sistem jika masih bermasalah

### FAQ Cepat:

**Q: Bagaimana cara membuat admin pertama?**  
A: Kunjungi `/setup`, isi form, submit. Lihat [MULAI_DI_SINI.md](./MULAI_DI_SINI.md)

**Q: Apa username dan password default?**  
A: Tidak ada default. Harus dibuat manual via `/setup`. Lihat [INFO_LOGIN.txt](./INFO_LOGIN.txt)

**Q: Apakah perlu setup database?**  
A: TIDAK! Sistem menggunakan KV Store yang otomatis ada.

**Q: Bagaimana cara customize logo?**  
A: Login admin → `/admin/settings` → Upload logo. Lihat [MULAI_DI_SINI.md](./MULAI_DI_SINI.md#upload-logo-instansi)

**Q: Lupa password admin?**  
A: Reset via Supabase Dashboard. Lihat [KREDENSIAL_DEFAULT.md](./KREDENSIAL_DEFAULT.md#lupa-password-admin)

---

## 📞 Kontak & Support

- **Email**: support@pmptsp.tegalkab.go.id (contoh)
- **Telepon**: (0283) xxx-xxxx (contoh)
- **Supabase Dashboard**: https://supabase.com/dashboard
- **Documentation Hub**: File-file .md di folder root project

---

## 🎯 Next Steps

Setelah membaca dokumentasi:

1. ✅ **Setup** admin pertama via `/setup`
2. ✅ **Customize** branding & kontak
3. ✅ **Test** sistem dengan buat aduan
4. ✅ **Share** link ke masyarakat
5. ✅ **Monitor** pengaduan masuk
6. ✅ **Maintain** sistem secara berkala

---

**🎉 Selamat menggunakan Whistle Blowing System!**

Bersama kita ciptakan pemerintahan yang bersih, transparan, dan akuntabel.

---

© 2025 Dinas PMPTSP Kabupaten Tegal  
Whistle Blowing System - Powered by React + Supabase
