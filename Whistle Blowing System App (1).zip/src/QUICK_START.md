# ⚡ Quick Start - WBS Setup dalam 2 Menit

## Untuk User Non-Teknis

```
1. Buka aplikasi
2. Kunjungi /setup
3. Isi: 
   - Email: admin@tegalkab.go.id
   - Password: (password Anda)
   - Nama: Administrator
4. Klik "Buat Admin Pertama"
5. Login di /login
6. SELESAI! 🎉
```

---

## Untuk Developer/IT

### System Requirements
✅ Tidak ada! Sistem ready-to-use dengan Supabase backend.

### Environment Variables (Sudah di-set)
```bash
SUPABASE_URL=***
SUPABASE_ANON_KEY=***
SUPABASE_SERVICE_ROLE_KEY=***
SUPABASE_DB_URL=***
```

### Database Setup
✅ Tidak perlu! Menggunakan KV Store yang otomatis ada.

### Deployment
```bash
# Sudah deployed dan running
# Akses via browser langsung
```

---

## Default Credentials

**⚠️ TIDAK ADA DEFAULT CREDENTIALS**  
Untuk keamanan, admin pertama harus dibuat manual via `/setup`

### Contoh untuk Testing:
```
Email:    admin@tegalkab.go.id
Password: admin123
Nama:     Administrator Test
```

### Untuk Production:
```
Email:    admin@pmptsp.tegalkab.go.id  
Password: (gunakan password kuat!)
Nama:     Administrator PMPTSP Kab. Tegal
```

---

## API Endpoints

Base URL: `https://{projectId}.supabase.co/functions/v1/make-server-7bc260f6`

### Public Endpoints
```
GET  /health                    - Health check
GET  /categories                - List categories
POST /reports                   - Create report
GET  /reports/:ticket           - Get report by ticket
GET  /reports/stats             - Get statistics
```

### Setup Endpoint (No Auth Required)
```
GET  /auth/check-admin          - Check if admin exists
POST /auth/setup-admin          - Setup first admin (only works once)
     Body: { email, password, name }
```

### Protected Endpoints (Require Auth)
```
POST   /auth/signup             - Create user (admin only)
GET    /auth/users              - List users (admin only)
DELETE /auth/users/:id          - Delete user (admin only)
GET    /settings                - Get settings
POST   /settings                - Update settings (admin only)
PUT    /reports/:ticket/status  - Update report status
DELETE /reports/:ticket         - Delete report (admin only)
POST   /categories              - Create category
PUT    /categories/:id          - Update category
DELETE /categories/:id          - Delete category
```

---

## Tech Stack

- **Frontend**: React 18 + TypeScript + Tailwind CSS v4
- **UI Components**: Shadcn/ui
- **Backend**: Supabase Edge Functions (Hono)
- **Database**: KV Store (Key-Value)
- **Auth**: Supabase Auth
- **Charts**: Recharts
- **Icons**: Lucide React
- **Routing**: React Router v6
- **Forms**: React Hook Form + Zod

---

## Project Structure

```
/
├── pages/              # React pages
│   ├── Home.tsx
│   ├── BuatAduan.tsx
│   ├── PantauAduan.tsx
│   ├── Login.tsx
│   ├── Setup.tsx       # ← NEW! Setup admin page
│   ├── admin/          # Admin pages
│   └── display/        # Display pages
├── components/         # React components
├── utils/              # Utilities
│   ├── auth.tsx        # Auth helpers
│   ├── dataStore.tsx   # API wrapper
│   └── settings.tsx    # Settings context
├── supabase/
│   └── functions/
│       └── server/
│           └── index.tsx   # API server
└── styles/
    └── globals.css
```

---

## Key Features

✅ **No Database Setup** - Uses KV Store  
✅ **Easy Admin Setup** - Web-based setup page  
✅ **Role-Based Access** - Admin & Display roles  
✅ **Anonymous Reports** - Optional anonymity  
✅ **File Upload** - Support for evidence files  
✅ **Real-time Tracking** - Ticket-based tracking  
✅ **Customizable** - Logo, name, contact info  
✅ **Secure** - Supabase Auth + RBAC  

---

## Common Tasks

### Add New Category
```typescript
// Via UI: /admin/kategori
// Via API:
POST /categories
Body: { name: "Kategori Baru", description: "Deskripsi" }
Header: Authorization: Bearer {accessToken}
```

### Create Display User
```typescript
// Via UI: /admin/users → Tambah User → Role: Display
// Via API:
POST /auth/signup
Body: { email, password, name, role: "display" }
Header: Authorization: Bearer {accessToken}
```

### Update Settings
```typescript
// Via UI: /admin/settings
// Via API:
POST /settings
Body: { 
  settings: { 
    logoUrl: "data:image/png;base64,...",  // base64 string
    institutionName: "...",
    institutionShortName: "...",
    // etc
  } 
}
Header: Authorization: Bearer {accessToken}
```

**Note:** Logo stored as base64 string in settings (no storage bucket needed)

---

## Security Notes

- ✅ SERVICE_ROLE_KEY only used in server-side
- ✅ ANON_KEY used in client-side (safe to expose)
- ✅ Protected routes require valid JWT token
- ✅ RBAC implemented via user metadata
- ✅ File upload validation on server
- ✅ CORS properly configured

---

## Monitoring

### Check System Health
```bash
curl https://{projectId}.supabase.co/functions/v1/make-server-7bc260f6/health
```

### Check Admin Exists
```bash
curl https://{projectId}.supabase.co/functions/v1/make-server-7bc260f6/auth/check-admin
```

### View Logs
- Supabase Dashboard → Edge Functions → Logs
- Browser DevTools → Console (F12)

---

## Troubleshooting

### Admin Setup Failed
→ Check Supabase Auth is enabled  
→ Check environment variables are set  
→ Check console for detailed error  

### Login Failed
→ Verify email/password correct  
→ Check user exists in Supabase Auth  
→ Verify user has role in metadata  

### Settings Update Failed
→ Most common: Session expired → Logout & login again  
→ Check user is admin (not display)  
→ Check Supabase Edge Functions logs  
→ Verify access token in browser console  

### API Errors
→ Check server logs in Supabase Dashboard  
→ Verify Authorization header format  
→ Check CORS configuration  
→ Ensure session is valid (not expired)  

---

## Performance Tips

- KV Store is fast (in-memory)
- Reports cached by ticket number
- Categories cached globally
- Use pagination for large lists
- Images lazy-loaded

---

## Next Steps

1. ✅ Setup admin via `/setup`
2. ✅ Customize branding via `/admin/settings`
3. ✅ Add custom categories if needed
4. ✅ Create display user if needed
5. ✅ Share website URL to public
6. ✅ Monitor via `/admin/dashboard`

---

📚 **Full Documentation**: See `MULAI_DI_SINI.md` for detailed guide

🔐 **Security Guide**: See `KREDENSIAL_DEFAULT.md` for admin setup details

📝 **User Manual**: See `PANDUAN_PENGGUNAAN.md` for complete features

---

**Ready to use in 2 minutes! No complex setup required.** 🚀
